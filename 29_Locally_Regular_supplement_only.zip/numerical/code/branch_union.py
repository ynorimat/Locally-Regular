"""Reanalyze every saved path using a prespecified likelihood-screened union.

Only NumPy and the standard library are needed. No optimizer or simulator is
imported. Likelihoods and standard errors are reconstructed independently of
the saved objective and standard-error columns, using the submission auditor.
"""
from pathlib import Path
from statistics import NormalDist
import csv
import hashlib
import json
import time
import numpy as np
from verify_submission import observed, fisher_standard_error

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'results/branch_union'


def wilson(count, total):
    p = count / total
    z = NormalDist().inv_cdf(.975)
    center = (p + z*z/(2*total))/(1+z*z/total)
    half = z*np.sqrt(p*(1-p)/total+z*z/(4*total*total))/(1+z*z/total)
    return center-half, center+half


def union_metrics(intervals, target):
    if not intervals:
        return False, False, False, False, True, 0., 0.
    merged=[]
    for lo,hi in sorted(intervals):
        if merged and lo <= merged[-1][1]:
            merged[-1][1]=max(merged[-1][1],hi)
        else:
            merged.append([lo,hi])
    covered=any(lo <= target <= hi for lo,hi in merged)
    lo,hi=merged[0][0],merged[-1][1]
    both=lo < 0 < hi
    declare=lo>0 or hi<0
    wrong=lo>0 if target<0 else hi<0
    return covered,both,declare,wrong,False,hi-lo,sum(b-a for a,b in merged)


def analyze():
    started=time.perf_counter()
    protocol=json.loads((BASE/'branch_union_protocol.json').read_text())
    z=NormalDist().inv_cdf(1-protocol['alpha_interval']/2)
    critical=NormalDist().inv_cdf(1-protocol['alpha_screen']/2)**2
    zsel=NormalDist().inv_cdf(.975)
    records=[]; summaries=[]; hashes={}; max_obj=0.; max_se=0.; min_lr=float('inf')
    folders=[('principal','unknown_B_raw',18),('nonrotation','nonrotation_mc/raw',4)]
    for experiment,folder,expected in folders:
        paths=sorted((BASE/'results'/folder).glob('*.npz'))
        assert len(paths)==expected
        for path in paths:
            hashes[str(path.relative_to(BASE)).replace('\\','/')]=hashlib.sha256(path.read_bytes()).hexdigest()
            with np.load(path,allow_pickle=False) as data:
                fit=data['fits']; n=int(data['n']); truth=int(data['truth']); regime=str(data['regime'])
                xx,yx,yy=[data[key] for key in ['s00','s10','s11']]
            reps=len(fit); target=-.5 if truth==2 else .25
            parameters=fit[:,:,[6,7,0,8,9,10]].reshape(-1,6)
            a,d,_,b,q=observed(parameters)
            rx,ry,rz=[np.repeat(v,3,axis=0) for v in (xx,yx,yy)]
            res=rz-b@ry.transpose(0,2,1)-ry@b.transpose(0,2,1)+b@rx@b.transpose(0,2,1)
            obj=(.5*(np.linalg.slogdet(q)[1]+np.trace(np.linalg.solve(q,res),axis1=1,axis2=2))).reshape(reps,3)
            se=fisher_standard_error(parameters,n).reshape(reps,3)
            max_obj=max(max_obj,float(np.max(abs(obj-fit[:,:,2]))))
            max_se=max(max_se,float(np.max(abs(se-fit[:,:,1]))))
            bh=np.linalg.solve(xx,yx.transpose(0,2,1)).transpose(0,2,1)
            qh=yy-bh@yx.transpose(0,2,1)
            qh=(qh+qh.transpose(0,2,1))/2
            unrestricted=.5*(np.linalg.slogdet(qh)[1]+2)
            lr=2*n*(obj-unrestricted[:,None])
            min_lr=min(min_lr,float(lr.min()))
            assert lr.min()>-1e-7
            keep=lr<=critical
            lo=fit[:,:,0]-z*se; hi=fit[:,:,0]+z*se
            fail=(~np.all(fit[:,:,5]==1,axis=1)) | (np.linalg.eigvalsh(qh).min(axis=1)<=0)
            local=[]
            for i in range(reps):
                selected=int(obj[i].argmin())
                selected_covered=bool(abs(fit[i,selected,0]-target)<=zsel*se[i,selected])
                for method,mask in [('screened_union',keep[i]),('all_branch_union',np.ones(3,dtype=bool))]:
                    intervals=[(float(lo[i,j]),float(hi[i,j])) for j in range(3) if mask[j]]
                    if fail[i]: intervals=[(-float('inf'),float('inf'))]
                    cov,both,decl,wrong,empty,diam,length=union_metrics(intervals,target)
                    row=dict(experiment=experiment,source_file=path.name,record=i,n=n,truth=truth,regime=regime,method=method,
                             covered=int(cov),both=int(both),declared=int(decl),wrong=int(wrong),empty=int(empty),
                             diameter=diam,total_length=length,branches=int(mask.sum()),fallback=int(fail[i]),
                             true_retained=int(mask[truth] or fail[i]),selected_covered=int(selected_covered))
                    for j in range(3): row.update({f'lr{j}':float(lr[i,j]),f'lower{j}':float(lo[i,j]),f'upper{j}':float(hi[i,j]),f'keep{j}':int(mask[j])})
                    local.append(row); records.append(row)
            for method in ['screened_union','all_branch_union']:
                rows=[r for r in local if r['method']==method]
                result=dict(experiment=experiment,regime=regime,n=n,truth=truth,method=method,reps=reps)
                for metric in ['covered','both','declared','wrong','empty','fallback','true_retained']:
                    count=sum(r[metric] for r in rows); result[metric+'_count']=count; result[metric+'_rate']=count/reps
                result['coverage_lo'],result['coverage_hi']=wilson(result['covered_count'],reps)
                result['median_diameter']=float(np.median([r['diameter'] for r in rows]))
                result['median_total_length']=float(np.median([r['total_length'] for r in rows]))
                result['mean_branches']=float(np.mean([r['branches'] for r in rows]))
                paired=np.array([r['covered']-r['selected_covered'] for r in rows],float)
                result['selected_coverage']=float(np.mean([r['selected_covered'] for r in rows]))
                result['paired_coverage_gain']=float(paired.mean())
                result['paired_gain_mcse']=float(paired.std(ddof=1)/np.sqrt(reps))
                summaries.append(result)
    assert len(records)==40000 and len(summaries)==44
    assert max_obj<1e-11 and max_se<1e-9
    OUT.mkdir(parents=True,exist_ok=True)
    for name,rows in [('records.csv',records),('summary.csv',summaries)]:
        with (OUT/name).open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    report=dict(status='passed',paths=20000,records=len(records),summary_rows=len(summaries),alpha_screen=protocol['alpha_screen'],alpha_interval=protocol['alpha_interval'],
                lr_critical=critical,interval_z=z,max_objective_error=max_obj,max_se_error=max_se,minimum_lr=min_lr,input_sha256=hashes,
                protocol_sha256=hashlib.sha256((BASE/'branch_union_protocol.json').read_bytes()).hexdigest(),elapsed_seconds=time.perf_counter()-started,
                scope='Prespecified saved-record reanalysis; no new samples or optimizer runs.')
    (OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    for r in summaries:
        if r['method']=='screened_union':
            print(r['experiment'],r['regime'],r['n'],r['truth'],'coverage',r['covered_rate'],'wrong',r['wrong_rate'],'both',r['both_rate'],'diam',r['median_diameter'],'branches',r['mean_branches'])
    print('PASS',len(records),'records;',len(summaries),'summary rows; critical',critical,'z',z)


if __name__=='__main__':
    analyze()
