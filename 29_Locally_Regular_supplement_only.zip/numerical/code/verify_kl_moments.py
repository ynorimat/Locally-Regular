"""Independent checks of KL expansions and likelihood-ratio moments.

Checks exact symbolic perturbation coefficients (including conditional-mean KL),
exact general fixed-root LLR moments under both hypotheses, and high-precision
full-path KL expansions. Does not solve the unrestricted nearest-model problem.
"""
from pathlib import Path
import json
import numpy as np
import sympy as sp
import mpmath as mp
from rotation_family import RotationFamily
from fixed_root_moments import llr_moments
BASE=Path(__file__).resolve().parents[1]


def main():
    symbolic={}
    def check(name, expr):
        ok = sp.simplify(expr) == 0
        symbolic[name]=bool(ok)
        if not ok: raise AssertionError((name, sp.simplify(expr)))
    sr=sp.sqrt(3); I=sp.eye(2); E=sp.diag(1,-1)
    A0=sp.Matrix([[sr/4,-sp.Rational(1,4)],[sp.Rational(1,4),sr/4]])
    A2=sp.Matrix([[0,sp.Rational(1,2)],[-sp.Rational(1,2),0]])
    H=sp.Matrix([[-17*sr,-63],[-63,17*sr]])/720
    c=sp.Rational(21,16); g=sp.Rational(4,3)
    def derivatives(A, da, dd):
        p=I; dp=sp.zeros(2); dq=sp.zeros(2)
        for _ in range(3):
            dq+=dp*p.T+p*dd*p.T+p*dp.T
            dp,p=dp*A+p*da,p*A
        x,y,z=sp.symbols('x y z'); X=sp.Matrix([[x,y],[y,z]])
        rhs=dd+g*(da*A.T+A*da.T)
        sol=sp.solve(list(X-A*X*A.T-rhs),(x,y,z))
        return tuple(sp.simplify(v) for v in (dp,dq,X.subs(sol)))
    bp,qp,gp=derivatives(A0,H,sp.Rational(7,10)*E)
    bm,qm,gm=derivatives(A2,sp.zeros(2),E)
    norm2=lambda m: sp.trace(m*m.T)
    init=sp.simplify(norm2(gp-gm)/(4*g*g))
    qc=sp.simplify(norm2(qp-qm)/(4*c*c))
    bc=sp.simplify(g*norm2(bp-bm)/(2*c))
    check('initial coefficient',init-sp.Rational(1,1350))
    check('conditional covariance coefficient',qc-sp.Rational(13,12150))
    check('conditional mean coefficient',bc-sp.Rational(403,170100))
    check('total transition coefficient',qc+bc-sp.Rational(13,3780))
    check('effect derivative',H[1,0]+sp.Rational(7,80))
    check('sampled-transition derivative', norm2(bp-H/2))
    x=sp.symbols('x',nonnegative=True)
    check('positive-law quadratic variance',
          2/(1-x)**2-3/(1-x)+1-x*(1+x)/(1-x)**2)
    ep=sp.symbols('ep',real=True)
    w0=(14+2*sp.I*sr)/13; w2=sp.Rational(4,5)
    beta=sp.simplify(sp.re(w2*sp.conjugate(w0))/(w0*sp.conjugate(w0)))
    check('beta twenty', beta-sp.Rational(7,10))
    res=sp.simplify(w2**2-beta**2*w0*sp.conjugate(w0))
    v=sp.simplify(beta**2*w0*sp.conjugate(w0)); aa=sp.Rational(65,64)**2
    xg=sp.simplify(res*ep**2/(g*g-v*ep**2))
    xq=sp.simplify(aa*res*ep**2/(c*c-aa*v*ep**2))
    check('exact initial variance',xg-27*ep**2/(1300-441*ep**2))
    check('exact transition variance',xq-39*ep**2/(1764-637*ep**2))
    check('j example',aa*res/(2*c*c)-sp.Rational(13,1176))
    if not (init<sp.Rational(27,2600) and qc+bc<sp.Rational(13,1176)):
        raise AssertionError('strict coefficient comparison failed')
    symbolic['both coefficients strictly improve']=True

    # Independently evaluate Gaussian quadratic-form moments using matrix traces.
    def component_moments(s0,s1):
        inv0=np.linalg.inv(s0); inv1=np.linalg.inv(s1); M=inv1-inv0
        const=-.5*(np.linalg.slogdet(s1)[1]-np.linalg.slogdet(s0)[1])
        return np.array([const-.5*np.trace(M@s0), .5*np.trace(M@s0@M@s0),
                         const-.5*np.trace(M@s1), .5*np.trace(M@s1@M@s1)])
    rng=np.random.default_rng(20260925)
    errors=[]; margins=[]; rows=[]
    for k in (3,5,7,9):
        for rep in range(50):
            fam=RotationFamily(k,float(rng.uniform(.25,.8)),float(rng.uniform(-np.pi,np.pi)))
            src,tar=rng.choice(k,2,replace=False)
            beta=fam.beta(int(src),int(tar))
            epsilon=float(rng.uniform(.08,.65)/max(1,abs(beta)))
            epsilon*=int(rng.choice([-1,1])); n=int(rng.choice([1,7,500,2000]))
            g0,q0=fam.covariance(int(src),epsilon)
            g1,q1=fam.covariance(int(tar),beta*epsilon)
            actual=component_moments(g0,g1)+n*component_moments(q0,q1)
            expected=llr_moments(fam,epsilon,n,int(src),int(tar))
            ev=np.array([expected[z] for z in ('mean_source','variance_source','mean_target','variance_target')])
            err=float(np.max(abs(actual-ev))); errors.append(err)
            np.testing.assert_allclose(actual,ev,atol=2e-9,rtol=2e-8)
            # Both trace constraints underlying the exact moments, independent of formulas.
            margins.extend([abs(np.trace(np.linalg.solve(g1,g0))-2),abs(np.trace(np.linalg.solve(q1,q0))-2)])
            total,_,_=fam.profile_kl(epsilon,n,int(src),int(tar))
            np.testing.assert_allclose(ev[0],-total,rtol=1e-11,atol=5e-11)
            rows.append([k,fam.r,fam.theta,int(src),int(tar),epsilon,n,err,expected['j']])
    np.savetxt(BASE/'results'/'general_moment_checks.csv',np.asarray(rows),delimiter=',',
               header='k,r,theta,source,target,epsilon,n,max_abs_moment_error,j',comments='')

    # Exact Gaussian path KL, at high precision, including a moving conditional mean.
    mp.mp.dps=65
    A0m=mp.matrix([[mp.sqrt(3)/4,-mp.mpf(1)/4],[mp.mpf(1)/4,mp.sqrt(3)/4]])
    A2m=mp.matrix([[0,mp.mpf(1)/2],[-mp.mpf(1)/2,0]])
    Hm=mp.matrix([[-17*mp.sqrt(3),-63],[-63,17*mp.sqrt(3)]])/720
    def tr(m): return m[0,0]+m[1,1]
    def full(A,d):
        X=[]; C=[]
        for basis in (mp.matrix([[1,0],[0,0]]),mp.matrix([[0,1],[1,0]]),mp.matrix([[0,0],[0,1]])):
            t=basis-A*basis*A.T
            C.append([t[0,0],t[0,1],t[1,1]])
        mat=mp.matrix([[C[j][i] for j in range(3)] for i in range(3)])
        sol=mp.lu_solve(mat,mp.matrix([d[0,0],d[0,1],d[1,1]]))
        G=mp.matrix([[sol[0],sol[1]],[sol[1],sol[2]]])
        P=mp.eye(2); Q=mp.zeros(2)
        for _ in range(3): Q+=P*d*P.T; P=P*A
        return P,Q,G
    def K(s0,s1): return (tr(s1**-1*s0)-2+mp.log(mp.det(s1)/mp.det(s0)))/2
    hp=[]
    for estr in ('0.02','0.005','0.001','0.0001'):
        e=mp.mpf(estr); d=mp.diag([1+e,1-e]); dt=mp.diag([1+7*e/10,1-7*e/10])
        b0,q0,g0=full(A2m,d); b1,q1,g1=full(A0m+e*Hm,dt)
        ki=K(g0,g1); kq=K(q0,q1); kb=tr(q1**-1*(b1-b0)*g0*(b1-b0).T)/2
        fixed_i=mp.log((1300-441*e*e)/(1300-468*e*e))/2
        fixed_q=mp.log((1764-637*e*e)/(1764-676*e*e))/2
        assert ki<fixed_i and kq+kb<fixed_q
        hp.append(dict(epsilon=estr,initial_over_epsilon2=str(ki/e**2),
                       transition_over_epsilon2=str((kq+kb)/e**2),
                       fixed_initial_over_epsilon2=str(fixed_i/e**2),
                       fixed_transition_over_epsilon2=str(fixed_q/e**2)))
    if abs(mp.mpf(hp[-1]['initial_over_epsilon2'])-mp.mpf(1)/1350)>mp.mpf('1e-6'):
        raise AssertionError('initial KL Taylor check failed')
    if abs(mp.mpf(hp[-1]['transition_over_epsilon2'])-mp.mpf(13)/3780)>mp.mpf('1e-6'):
        raise AssertionError('transition KL Taylor check failed')
    result={'symbolic_checks':symbolic,'symbolic_count':len(symbolic),
            'general_moment_cases':len(rows),'max_abs_moment_error':max(errors),
            'max_trace_constraint_error':max(margins),'high_precision_digits':mp.mp.dps,
            'moving_transition_checks':hp,
            'scope':'Algebraic and independent numerical checks; not formal proof verification, no unrestricted minimizer claim, no new Monte Carlo.'}
    (BASE/'results'/'verification_kl_moments.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='moving_transition_checks'},indent=2))
    print('First and last moving-transition KL checks:',hp[0],hp[-1])

if __name__=='__main__': main()
