"""Independently verify exported both-source table against integer CSV counts."""
from pathlib import Path
import csv
import json
import re
BASE=Path(__file__).resolve().parents[1]

def read(name):
    with (BASE/'results'/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))

def main():
    structural=read('unknown_B_summary.csv');grid=read('grid_contrast/summary.csv')
    def row(data,regime,truth,method):
        selected=[r for r in data if r['regime']==regime and int(r['truth'])==truth and int(r['n'])==32000 and r['method']==method]
        assert len(selected)==1
        return selected[0]
    text=(BASE/'results/grid_contrast/two_source_summary.tex').read_text(encoding='utf-8')
    mapping={r'$1/n$':'inverse_n',r'$4/\sqrt n$':'local_c4',r'$.2$':'fixed_e02'}
    checked=0;seen=set()
    for line in text.splitlines():
        fields=[x.strip() for x in line.removesuffix('\\\\').split('&')]
        if len(fields)!=6 or fields[0] not in mapping:continue
        regime=mapping[fields[0]];truth={'Negative':2,'Positive':0}[fields[1]]
        assert (regime,truth) not in seen;seen.add((regime,truth))
        s=row(structural,regime,truth,'selected');o=row(structural,regime,truth,'true_branch_oracle');g=row(grid,regime,truth,'ols_on_grid')
        expected=[100*int(r[key])/int(r['completed']) for r,key in [(s,'coverage_count'),(o,'coverage_count'),(g,'coverage_count'),(s,'wrong_count')]]
        assert fields[2:]==[f'{v:.1f}' for v in expected]
        checked+=4
    assert checked==24 and len(seen)==6
    paths=['unknown_B_main_text.tex','grid_contrast/main_text.tex','grid_contrast/two_source_summary.tex','grid_contrast/table.tex']
    assert all('@@' not in (BASE/'results'/p).read_text(encoding='utf-8') for p in paths)
    result={'status':'passed','source':'integer counts in bundled summary CSVs','rows':6,'checked_values':24,'unresolved_template_tokens':0}
    (BASE/'results/manuscript_export_verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
