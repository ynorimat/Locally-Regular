"""Independently reconstruct selection/coverage counts and the worked example."""
from collections import Counter
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import norm, binomtest

BASE = Path(__file__).resolve().parents[1]
OUT = BASE/'results/selection_diagnostics'


def main():
    paths = pd.read_csv(OUT/'selection_coverage_records.csv')
    cells = pd.read_csv(OUT/'selection_coverage_cells.csv')
    original = pd.read_csv(BASE/'results/unknown_B_summary.csv')
    example = pd.read_csv(OUT/'worked_path.csv')
    critical = norm.isf(.025)
    counts = Counter(); covered_counts = Counter()
    total = 0; maximum_interval_error = 0.; maximum_likelihood_error = 0.
    for file in sorted((BASE/'results/unknown_B_raw').glob('*.npz')):
        with np.load(file) as raw:
            f = raw['fits']; n = int(raw['n']); truth = int(raw['truth']); regime = str(raw['regime'])
            good = np.flatnonzero(np.all(f[:, :, 5] == 1, axis=1))
            saved = paths[paths.source_file == file.name].sort_values('original_index')
            assert saved.original_index.tolist() == good.tolist()
            target = -.5 if truth == 2 else .25
            for saved_row, index in zip(saved.itertuples(), good):
                b = min(range(3), key=lambda j: f[index, j, 2])
                fit = f[index, b]
                low, high = fit[0]-critical*fit[1], fit[0]+critical*fit[1]
                cover = low <= target <= high
                oracle = f[index, truth]
                oracle_cover = oracle[0]-critical*oracle[1] <= target <= oracle[0]+critical*oracle[1]
                assert saved_row.selected_branch == b and saved_row.covered == cover
                assert saved_row.correct_branch == (b == truth)
                assert saved_row.oracle_covered == oracle_cover
                key = regime, n, truth, b
                counts[key] += 1; covered_counts[key] += int(cover)
                total += 1
            for method, column in [('selected','covered'),('true_branch_oracle','oracle_covered')]:
                old = original[(original.regime == regime)&(original.n == n)&(original.truth == truth)&(original.method == method)].iloc[0]
                assert int(saved[column].sum()) == int(old.coverage_count)
            if file.name == 'inverse_n_n32000_truth2.npz':
                direct = []
                for branch in range(3):
                    fit = f[0, branch]
                    a = np.array([[fit[6],fit[7]],[fit[0],fit[8]]])
                    d = np.diag(fit[9:11]); p = np.eye(2); q = np.zeros((2,2))
                    for _ in range(3):
                        q += p@d@p.T; p = p@a
                    residual = raw['s11'][0]-p@raw['s10'][0].T-raw['s10'][0]@p.T+p@raw['s00'][0]@p.T
                    direct.append(.5*n*(np.linalg.slogdet(q)[1]+np.trace(np.linalg.solve(q,residual))))
                    item = example[example.branch == branch].iloc[0]
                    assert item.original_index == 0 and item.source_file == file.name
                    maximum_interval_error = max(maximum_interval_error,
                        abs(item.lower-(fit[0]-critical*fit[1])),
                        abs(item.upper-(fit[0]+critical*fit[1])),abs(item.estimate-fit[0]))
                for branch, value in enumerate(direct):
                    item = example[example.branch == branch].iloc[0]
                    maximum_likelihood_error = max(maximum_likelihood_error,abs(item.loglik_loss-(value-min(direct))))
                    assert bool(item.selected) == (branch == int(np.argmin(direct)))
    for row in cells.itertuples():
        key = row.regime, row.n, row.truth, row.selected_branch
        assert row.selected_count == counts[key] and row.covered_count == covered_counts[key]
        assert row.completed == 1000 and row.failures == 0 and row.attempted == 1000
        assert abs(row.unconditional_coverage_contribution-covered_counts[key]/1000)<1e-14
        if counts[key]:
            assert abs(row.conditional_coverage-covered_counts[key]/counts[key])<1e-14
            ci = binomtest(covered_counts[key], counts[key]).proportion_ci(.95, method='wilson')
            assert abs(ci.low-row.conditional_coverage_lo)<1e-13
            assert abs(ci.high-row.conditional_coverage_hi)<1e-13
        else:
            assert np.isnan(row.conditional_coverage)
    assert total == 18000 and len(cells) == 54
    assert maximum_interval_error < 1e-13 and maximum_likelihood_error < 1e-8
    result = dict(paths_verified=total, cell_branch_summaries_verified=len(cells),
                  original_coverage_summaries_matched=36, conditional_intervals='Independent scipy Wilson calculation',
                  worked_example_record=0, direct_worked_example_likelihoods=3,
                  maximum_interval_error=maximum_interval_error,
                  maximum_direct_total_loglik_error=maximum_likelihood_error,
                  status='all checks passed')
    (OUT/'verification.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
