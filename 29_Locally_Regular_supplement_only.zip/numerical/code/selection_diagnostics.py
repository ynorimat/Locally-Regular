"""Selection/coverage cross-tabulations from the unchanged saved fits.

No simulation, optimization, or outcome-based choice of an illustrative path.
The worked example is record 0 in the inverse_n/n=32000/negative-source cell.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import norm

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'results/selection_diagnostics'
Z = float(norm.ppf(.975))


def wilson(successes, total):
    if total == 0:
        return np.nan, np.nan
    p = successes / total
    denominator = 1 + Z*Z/total
    center = (p + Z*Z/(2*total))/denominator
    half = Z*np.sqrt(p*(1-p)/total + Z*Z/(4*total*total))/denominator
    return center-half, center+half


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    records, summaries, example = [], [], []
    source = None
    for path in sorted((BASE/'results/unknown_B_raw').glob('*.npz')):
        with np.load(path) as raw:
            fits = raw['fits']; n = int(raw['n']); truth = int(raw['truth'])
            regime = str(raw['regime']); epsilon = float(raw['epsilon'])
        indices = np.flatnonzero(np.all(fits[:, :, 5] == 1, axis=1))
        f = fits[indices]
        chosen = np.argmin(f[:, :, 2], axis=1)
        effect = -.5 if truth == 2 else .25
        covered = abs(f[:, :, 0]-effect) <= Z*f[:, :, 1]
        lower = f[:, :, 0]-Z*f[:, :, 1]
        upper = f[:, :, 0]+Z*f[:, :, 1]
        for j, original in enumerate(indices):
            pick = int(chosen[j])
            records.append(dict(source_file=path.name, regime=regime, n=n, truth=truth,
                                original_index=int(original), selected_branch=pick,
                                correct_branch=pick == truth,
                                covered=bool(covered[j, pick]),
                                oracle_covered=bool(covered[j, truth])))
        for branch in range(3):
            selected = chosen == branch
            count = int(selected.sum()); success = int(covered[selected, branch].sum())
            lo, hi = wilson(success, count)
            summaries.append(dict(regime=regime, n=n, truth=truth, epsilon=epsilon,
                                  attempted=len(fits), completed=len(indices),
                                  failures=len(fits)-len(indices), selected_branch=branch,
                                  selected_count=count, covered_count=success,
                                  conditional_coverage=success/count if count else np.nan,
                                  conditional_coverage_lo=lo, conditional_coverage_hi=hi,
                                  unconditional_coverage_contribution=success/len(indices)))
        if regime == 'inverse_n' and n == 32000 and truth == 2:
            assert 0 in indices
            source = path.name
            for branch in range(3):
                row = fits[0, branch]
                example.append(dict(source_file=path.name, original_index=0, branch=branch,
                                    estimate=float(row[0]), standard_error=float(row[1]),
                                    lower=float(lower[np.flatnonzero(indices == 0)[0], branch]),
                                    upper=float(upper[np.flatnonzero(indices == 0)[0], branch]),
                                    loglik_loss=float(n*(row[2]-fits[0, :, 2].min())),
                                    selected=branch == int(fits[0, :, 2].argmin())))
    cells = pd.DataFrame(summaries)
    paths = pd.DataFrame(records)
    worked = pd.DataFrame(example)
    assert len(paths) == 18000 and len(cells) == 54 and len(worked) == 3
    cells.to_csv(OUT/'selection_coverage_cells.csv', index=False)
    paths.to_csv(OUT/'selection_coverage_records.csv', index=False)
    worked.to_csv(OUT/'worked_path.csv', index=False)
    labels = {'inverse_n':r'$1/n$', 'local_c4':r'$4/\sqrt n$', 'fixed_e02':r'$.2$'}
    rows = [r'\begin{table}[htbp]', r'\centering\small',
            r'\caption{Selection and coverage under the negative source at $n=32000$ (1,000 paths per regime). Conditional coverage divides the covered count by the selected count. The last column divides by all 1,000 paths; its sum is selected-interval coverage. These are descriptive selection-conditional rates, not selective-coverage guarantees.}',
            r'\label{tab:selection_coverage}', r'\begin{tabular}{llrrrr}',r'\toprule',
            r'$\varepsilon$ & Selected branch & Selected & Covered & Conditional (\%) & Contribution (\%) \\',r'\midrule']
    for regime, label in labels.items():
        subset = cells[(cells.regime == regime)&(cells.n == 32000)&(cells.truth == 2)]
        for row in subset.itertuples():
            value = '--' if not row.selected_count else f'{100*row.conditional_coverage:.1f}'
            rows.append(f'{label} & {row.selected_branch} & {row.selected_count} & {row.covered_count} & {value} & {100*row.unconditional_coverage_contribution:.1f} '+r'\\')
        rows.append(r'\addlinespace')
    rows.extend([r'\bottomrule', r'\end{tabular}', r'\end{table}'])
    (OUT/'selection_coverage_table.tex').write_text('\n'.join(rows)+'\n', encoding='utf-8')
    rows = [r'\begin{table}[htbp]',r'\centering\small',
            r'\caption{All three attained fits for record 0 in the negative-source $n=32000$, $\varepsilon=1/n$ cell. The record index is fixed without using fitted outcomes. The true effect is $-1/2$. $\ell_{\max}-\ell_b$ is a descriptive total conditional log-likelihood loss, with no critical-value or probability interpretation.}',
            r'\label{tab:worked_path}',r'\begin{tabular}{lrrrrl}',r'\toprule',
            r'Branch & $\widehat A_{21}$ & Local lower & Local upper & $\ell_{\max}-\ell_b$ & Selected \\',r'\midrule']
    for row in worked.itertuples():
        rows.append(f'{row.branch} & {row.estimate:.4f} & {row.lower:.4f} & {row.upper:.4f} & {row.loglik_loss:.4f} & '+('Yes' if row.selected else 'No')+r'\\')
    rows.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}'])
    (OUT/'worked_path_table.tex').write_text('\n'.join(rows)+'\n', encoding='utf-8')
    cell = cells[(cells.regime == 'inverse_n')&(cells.n == 32000)&(cells.truth == 2)&(cells.selected_branch == 2)].iloc[0]
    relevant = paths[(paths.regime == 'inverse_n')&(paths.n == 32000)&(paths.truth == 2)]
    text = (r'\paragraph{Selection also changes within-branch coverage.}'+'\n'+
            f'The true branch is selected on {cell.selected_count} of 1,000 negative-source paths at '+
            r'$n=32000$, $\varepsilon=1/n$; '+f'{cell.covered_count} of these intervals cover, giving '+
            f'{100*cell.conditional_coverage:.1f}'+r'\% conditional coverage. The '+
            f'{100*relevant.oracle_covered.mean():.1f}'+r'\% oracle coverage instead uses the true-branch fit on all paths. '+
            r'Thus selecting a branch changes the population of paths on which its local interval is evaluated. '+
            r'Branches 0 and 1 share the positive effect $1/4$, so effect coverage differs from recovering the generating branch. Their limiting local widths at this $n$ are $.0288$, versus $.0648$ on branch 2 (Appendix Table~\ref{tab:branch_width}). '+
            r'Appendix Table~\ref{tab:selection_coverage} separates branch-selection errors from coverage within a selected branch; Table~\ref{tab:worked_path} displays all fits for a fixed record.'+'\n')
    (OUT/'selection_interpretation.tex').write_text(text, encoding='utf-8')
    metadata = dict(paths=len(paths), cells=18, branch_rows=len(cells),
                    no_new_simulation=True, no_refitting=True,
                    illustrative_record=dict(source_file=source, original_index=0,
                                             selection_rule='Fixed original index 0; no outcome filtering.'),
                    selected_true_branch_count=int(cell.selected_count),
                    selected_true_branch_covered=int(cell.covered_count),
                    conditional_coverage=float(cell.conditional_coverage),
                    oracle_coverage=float(relevant.oracle_covered.mean()))
    (OUT/'metadata.json').write_text(json.dumps(metadata, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(metadata, indent=2))
    print(worked.to_string(index=False))


if __name__ == '__main__':
    main()
