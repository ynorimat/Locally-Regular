"""Independent numerical identities and complete saved-fit audit for robustness."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.linalg import solve_discrete_lyapunov
from scipy.stats import norm
from rotation_family import RotationFamily,coarsen,derivatives
from robustness_experiments import objective,model,starts,SETTINGS,PROTOCOL
from unknown_transition import objective as original_objective
BASE=Path(__file__).resolve().parents[1]


def x_from_fit(f):return np.array([f[6],f[7],f[0],f[8],np.log(f[9]),np.log(f[10])])


def independent_se(x,n,k):
    a=x[:4].reshape(2,2);d=np.diag(np.exp(x[4:]));eta=np.r_[a.ravel(),np.diag(d)];db=[];dq=[]
    for e in np.eye(6):
        plus=eta+1e-5*e;minus=eta-1e-5*e
        bp,qp=coarsen(plus[:4].reshape(2,2),np.diag(plus[4:]),k)
        bm,qm=coarsen(minus[:4].reshape(2,2),np.diag(minus[4:]),k)
        db.append((bp-bm)/2e-5);dq.append((qp-qm)/2e-5)
    gamma=solve_discrete_lyapunov(a,d);qi=np.linalg.inv(coarsen(a,d,k)[1])
    info=np.array([[np.trace(qi@db[i]@gamma@db[j].T)+.5*np.trace(qi@dq[i]@qi@dq[j]) for j in range(6)] for i in range(6)])
    return np.sqrt(np.linalg.inv(info)[2,2]/n)


def main():
    out=BASE/'results/robustness';rng=np.random.default_rng(202609303)
    maxgradient=maxderivative=maxoriginal=maxobjective=maxscore=maxse=maxroot=0.
    for s in SETTINGS:
        fam=RotationFamily(s['k'],s['r'],s['theta'])
        for _ in range(10):
            g,q=fam.covariance(s['negative'],.2);b=fam.B
            x=np.r_[fam.roots[s['negative']].ravel(),np.log([1.2,.8])]+rng.normal(scale=.03,size=6)
            value,grad=objective(x,g,b@g,g,fam.k)
            fd=np.array([(objective(x+1e-5*e,g,b@g,g,fam.k)[0]-objective(x-1e-5*e,g,b@g,g,fam.k)[0])/2e-5 for e in np.eye(6)])
            maxgradient=max(maxgradient,float(np.max(abs(fd-grad))))
            _,_,db,dq=model(x,fam.k);a=x[:4].reshape(2,2);d=np.diag(np.exp(x[4:]));db0,dq0=derivatives(a,d,fam.k)
            db0[4:]*=np.diag(d)[:,None,None];dq0[4:]*=np.diag(d)[:,None,None]
            maxderivative=max(maxderivative,float(np.max(abs(db-db0))),float(np.max(abs(dq-dq0))))
            if fam.k==3:
                f0,g0=original_objective(x,g,b@g,g)
                maxoriginal=max(maxoriginal,abs(value-f0),float(np.max(abs(grad-g0))))
            for xx in starts(g,b@g,g,fam.k):
                maxroot=max(maxroot,float(np.max(abs(np.linalg.matrix_power(xx[:4].reshape(2,2),fam.k)-b))))
    assert maxgradient<1e-7 and maxderivative<1e-12 and maxoriginal<1e-12 and maxroot<1e-12
    # Recreate the stratified selection, which was committed before fitting.
    selection=json.loads((out/'audit_selection.json').read_text());rng=np.random.default_rng(PROTOCOL['audit_seed'])
    audited=0;se_audits=0
    for item in selection:
        with np.load(BASE/'results/unknown_B_raw'/item['file']) as original:
            expected=sorted(rng.choice(len(original['fits']),20,replace=False).tolist())
            assert expected==item['indices']
            with np.load(out/('audit_'+item['file'])) as z:
                for key in ('s00','s10','s11'):assert np.array_equal(z[key],original[key][expected])
                assert np.array_equal(z['original'],original['fits'][expected])
                n=int(z['n'])
                for name in ('jitter_fits','alternate_fits'):
                    for i,group in enumerate(z[name]):
                        for f in group:
                            x=x_from_fit(f);obj,gradient=objective(x,z['s00'][i],z['s10'][i],z['s11'][i],3)
                            maxobjective=max(maxobjective,abs(obj-f[2]));maxscore=max(maxscore,abs(np.linalg.norm(gradient,ord=np.inf)-f[3]));audited+=1
    summary=pd.read_csv(out/'sensitivity_summary.csv');paths=fits_checked=migrations=0
    for path in sorted((out/'sensitivity_raw').glob('*.npz')):
        with np.load(path) as z:
            fits=z['fits'];k=int(z['k']);n=int(z['n']);truth=int(z['truth']);fam=RotationFamily(k,float(z['r']),float(z['theta']))
            setting=str(z['setting']);regime=str(z['regime']);paths+=len(fits)
            for i,group in enumerate(fits):
                for j,f in enumerate(group):
                    if not np.isfinite(f[2]):continue
                    x=x_from_fit(f);obj,gradient=objective(x,z['s00'][i],z['s10'][i],z['s11'][i],k)
                    maxobjective=max(maxobjective,abs(obj-f[2]));maxscore=max(maxscore,abs(np.linalg.norm(gradient,ord=np.inf)-f[3]));fits_checked+=1
                    branch=np.argmin(np.linalg.norm(fam.roots-x[:4].reshape(2,2),axis=(1,2)))
                    migrations+=int(branch!=j)
                    if i<2 and f[5]==1:
                        maxse=max(maxse,abs(independent_se(x,n,k)-f[1]));se_audits+=1
            complete=np.all(fits[:,:,5]==1,axis=1);valid=fits[complete];R=len(valid)
            target=fam.roots[truth,1,0];choice=np.argmin(valid[:,:,2],axis=1)
            for method,index in [('selected',choice),('true_branch_oracle',np.full(R,truth))]:
                f=valid[np.arange(R),index];lo=f[:,0]-norm.ppf(.975)*f[:,1];hi=f[:,0]+norm.ppf(.975)*f[:,1]
                row=summary[(summary.setting==setting)&(summary.regime==regime)&(summary.n==n)&(summary.truth==truth)&(summary.method==method)].iloc[0]
                assert row.attempted==len(fits) and row.completed==R and row.failures==len(fits)-R
                assert abs(row.median_width-np.median(hi-lo))<1e-12
                for name,events in [('coverage',(lo<=target)&(target<=hi)),
                                    ('wrong',(lo>0) if target<0 else (hi<0)),
                                    ('declare',(lo>0)|(hi<0))]:
                    count=int(events.sum());rate=count/R;z95=norm.ppf(.975)
                    center=(rate+z95*z95/(2*R))/(1+z95*z95/R)
                    radius=z95*np.sqrt(rate*(1-rate)/R+z95*z95/(4*R*R))/(1+z95*z95/R)
                    assert row[name+'_count']==count and abs(row[name+'_rate']-rate)<1e-12
                    assert abs(row[name+'_lo']-max(0.,center-radius))<1e-12
                    assert abs(row[name+'_hi']-min(1.,center+radius))<1e-12
    assert maxobjective<1e-11 and maxscore<1e-10 and maxse<1e-8
    result=dict(gradient_max_error=maxgradient,structural_derivative_max_error=maxderivative,
                original_k3_agreement_max_error=maxoriginal,cube_root_max_error=maxroot,
                saved_objective_max_error=maxobjective,saved_score_max_error=maxscore,
                independent_standard_error_max_error=maxse,standard_error_audits=se_audits,
                extra_optimization_fits_verified=audited,sensitivity_paths_verified=paths,
                sensitivity_fits_verified=fits_checked,branch_migrations=migrations,
                stratified_selection_verified=True,summary_rows_verified=len(summary),status='all checks passed')
    (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))


if __name__=='__main__':main()
