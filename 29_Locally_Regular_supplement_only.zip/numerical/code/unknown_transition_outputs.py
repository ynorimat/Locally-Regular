"""Build manuscript material from the saved unknown-transition experiment."""
from pathlib import Path
import numpy as np
import pandas as pd
from manuscript_text import unknown_text
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=Path(__file__).resolve().parents[1]


def main():
    df=pd.read_csv(BASE/'results/unknown_B_summary.csv')
    assert len(df)==36 and (df.completed==1000).all() and (df.failures==0).all()
    def row(regime,n,truth,method='selected'):
        return df[(df.regime==regime)&(df.n==n)&(df.truth==truth)&(df.method==method)].iloc[0]
    text=unknown_text(BASE)
    (BASE/'results/unknown_B_main_text.tex').write_text(text,encoding='utf-8')
    rows=[r'\begin{table}[!ht]',r'\centering\small',
          r'\caption{Unknown-transition diagnostic: 1,000 completed paths per row; no fit failures. Coverage and wrong-sign declarations are percentages. Oracle coverage uses the generating branch. Width is the median selected-interval width. Full Monte Carlo intervals and declaration counts are in \texttt{unknown\_B\_summary.csv}.}',
          r'\label{tab:unknownB}',r'\begin{tabular}{llrrrrr}',r'\toprule',
          r'$\varepsilon$ & True branch & $n$ & Selected coverage & Oracle coverage & Wrong/all & Width \\',r'\midrule']
    names={'inverse_n':r'$1/n$','local_c4':r'$4/\sqrt n$','fixed_e02':r'$.2$'}
    for regime in names:
        for truth in (0,2):
            for n in (2000,8000,32000):
                s=row(regime,n,truth);o=row(regime,n,truth,'true_branch_oracle')
                rows.append(f'{names[regime]} & {truth} & {n} & {100*s.coverage_rate:.1f} & {100*o.coverage_rate:.1f} & {100*s.wrong_rate:.1f} & {s.median_width:.3f} '+r'\\')
        rows.append(r'\addlinespace')
    rows.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}'])
    (BASE/'results/unknown_B_appendix_table.tex').write_text('\n'.join(rows)+'\n')
    plt.rcParams.update({'font.family':'serif','font.size':10,'axes.labelsize':10,
                         'pdf.fonttype':42,'ps.fonttype':42})
    fig,axes=plt.subplots(1,2,figsize=(7.0,2.8))
    colors={'inverse_n':'#28649d','fixed_e02':'#b35523'}
    for regime in colors:
        for method,style in [('selected','-'),('true_branch_oracle','--')]:
            s=df[(df.truth==2)&(df.regime==regime)&(df.method==method)].sort_values('n')
            label=('Selected' if method=='selected' else 'True-branch oracle')+', '+('$1/n$' if regime=='inverse_n' else '$\\varepsilon=.2$')
            axes[0].errorbar(s.n,s.coverage_rate,yerr=np.array([s.coverage_rate-s.coverage_lo,s.coverage_hi-s.coverage_rate]),
                             color=colors[regime],linestyle=style,marker='o',markersize=3,capsize=2,label=label)
            axes[1].plot(s.n,s.median_width,color=colors[regime],linestyle=style,marker='o',markersize=3)
    axes[0].axhline(.95,color='.4',linestyle=':',linewidth=1)
    axes[0].set(ylabel='Effect coverage',ylim=(0,1.04))
    axes[1].set(ylabel='Median interval width',ylim=(0,None))
    for ax in axes:
        ax.set_xscale('log');ax.set_xticks([2000,8000,32000],['2,000','8,000','32,000'])
        ax.set_xlabel('Observed transitions');ax.grid(alpha=.18)
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=2,frameon=False,fontsize=9)
    fig.tight_layout(rect=(0,.19,1,1),pad=.6)
    fig.savefig(BASE/'figures/unknown_B_wald.pdf')
    fig.savefig(BASE/'figures/unknown_B_wald.png',dpi=180)
    plt.close(fig)
    print(text)


if __name__=='__main__':main()
