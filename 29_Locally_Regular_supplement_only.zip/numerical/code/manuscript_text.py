"""Export descriptive text and tables from bundled summary CSVs."""
from pathlib import Path
import csv
import re

BASE=Path(__file__).resolve().parents[1]
TEMPLATES=Path(__file__).resolve().parent/'templates'
REGIMES={'inverse_n':r'$1/n$','local_c4':r'$4/\sqrt n$','fixed_e02':r'$.2$'}

def load(base,name):
    with (base/'results'/name).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))

def cell(rows,regime,n,truth,method):
    found=[r for r in rows if (r['regime'],int(r['n']),int(r['truth']),r['method'])==(regime,n,truth,method)]
    if len(found)!=1:raise ValueError((regime,n,truth,method,len(found)))
    return found[0]

def fill(name,values):
    text=(TEMPLATES/name).read_text(encoding='utf-8')
    return re.sub(r'@@([a-z_]+)@@',lambda m:values[m.group(1)],text)

def unknown_text(base=BASE):
    rows=load(base,'unknown_B_summary.csv')
    get=lambda regime,n,truth:cell(rows,regime,n,truth,'selected')
    percent=lambda row:f"{100*float(row['coverage_rate']):.1f}"
    width=lambda row:f"{float(row['median_width']):.3f}"
    return fill('unknown_B_main_text.tex.in',dict(
        local_negative_cover=percent(get('inverse_n',32000,2)),
        local_positive_cover=percent(get('inverse_n',32000,0)),
        small_negative_width=width(get('inverse_n',2000,2)),
        large_negative_width=width(get('inverse_n',32000,2)),
        small_fixed_negative_cover=percent(get('fixed_e02',2000,2)),
        large_fixed_negative_cover=percent(get('fixed_e02',32000,2)),
        small_fixed_positive_cover=percent(get('fixed_e02',2000,0)),
        large_fixed_positive_cover=percent(get('fixed_e02',32000,0))))

def grid_text(base=BASE):
    rows=load(base,'grid_contrast/summary.csv')
    get=lambda n,truth:cell(rows,'inverse_n',n,truth,'ols_on_grid')
    rates=[100*float(r['coverage_rate']) for r in rows if r['method']=='ols_on_grid']
    return fill('grid_main_text.tex.in',dict(
        negative_cover=f"{100*float(get(32000,2)['coverage_rate']):.1f}",
        positive_cover=f"{100*float(get(32000,0)['coverage_rate']):.1f}",
        small_width=f"{float(get(2000,2)['median_width']):.3f}",
        large_width=f"{float(get(32000,2)['median_width']):.3f}",
        minimum_cover=f'{min(rates):.1f}',maximum_cover=f'{max(rates):.1f}'))

def write_outputs(base=BASE):
    structural=load(base,'unknown_B_summary.csv')
    grid=load(base,'grid_contrast/summary.csv')
    assert len(structural)==36 and len(grid)==54
    assert all(int(r['completed'])==1000 and int(r['failures'])==0 for r in structural+grid)
    out=base/'results/grid_contrast';out.mkdir(parents=True,exist_ok=True)
    (base/'results/unknown_B_main_text.tex').write_text(unknown_text(base),encoding='utf-8',newline='\n')
    (out/'main_text.tex').write_text(grid_text(base),encoding='utf-8',newline='\n')
    rows=[]
    for regime,label in REGIMES.items():
        for truth,sign in [(2,'Negative'),(0,'Positive')]:
            s=cell(structural,regime,32000,truth,'selected')
            o=cell(structural,regime,32000,truth,'true_branch_oracle')
            g=cell(grid,regime,32000,truth,'ols_on_grid')
            rows.append(f"{label} & {sign} & {100*float(s['coverage_rate']):.1f} & {100*float(o['coverage_rate']):.1f} & {100*float(g['coverage_rate']):.1f} & {100*float(s['wrong_rate']):.1f}"+r'\\')
    (out/'two_source_summary.tex').write_text(fill('summary.tex.in',{'rows':'\n'.join(rows)}),encoding='utf-8',newline='\n')
    rows=[]
    for regime,label in REGIMES.items():
        for truth in [0,2]:
            for n in [2000,8000,32000]:
                off=cell(grid,regime,n,truth,'selected_off_grid')
                on=cell(grid,regime,n,truth,'ols_on_grid')
                rows.append(f"{label} & {truth} & {n} & {100*float(off['coverage_rate']):.1f} & {100*float(on['coverage_rate']):.1f} & {float(off['median_width']):.3f} & {float(on['median_width']):.3f} "+r'\\')
        rows.append(r'\addlinespace')
    (out/'table.tex').write_text(fill('grid_table.tex.in',{'rows':'\n'.join(rows)}),encoding='utf-8',newline='\n')

if __name__=='__main__':
    write_outputs()
    print('Exported descriptive text, both-source summary, and on/off-grid appendix table from CSVs.')
