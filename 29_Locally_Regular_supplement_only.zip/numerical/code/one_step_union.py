"""One Fisher-scoring update from observed-VAR roots; NumPy only.

The public confidence_set function uses only observed moments, n and k.
It does not import an optimizer or accept a population branch label.
Coordinates: A11,A12,A21,A22,d1,d2, with untransformed variances.
The guarantee is asymptotic on the compact families in the manuscript.
"""
from statistics import NormalDist
import numpy as np
from gaussian_var import observed, stationary, tangent


def objective_score_information(p, xx, yx, yy, k):
    a, d, _, b, q = observed(p, k)
    qi = np.linalg.inv(q)
    gamma = stationary(a, d)
    residual = yy-b@yx.transpose(0,2,1)-yx@b.transpose(0,2,1)+b@xx@b.transpose(0,2,1)
    objective = .5*(np.linalg.slogdet(q)[1]+np.trace(qi@residual, axis1=1, axis2=2))
    db, dq = tangent(p, k)
    bg = qi@(b@xx-yx)
    qg = .5*(qi-qi@residual@qi)
    gradient = np.column_stack([np.sum(bg*db[j]+qg*dq[j], axis=(1,2)) for j in range(6)])
    information = np.empty((len(p),6,6))
    for i in range(6):
        mean = qi@db[i]@gamma
        covariance = qi@dq[i]@qi
        for j in range(6):
            information[:,i,j] = np.sum(mean*db[j],axis=(1,2))+.5*np.sum(covariance*dq[j],axis=(1,2))
    information = (information+information.transpose(0,2,1))/2
    return objective, gradient, information


def initialize(xx, yx, yy, k):
    if np.linalg.eigvalsh(xx).min() <= 0:
        raise ValueError('Singular observed design')
    bh = np.linalg.solve(xx,yx.transpose(0,2,1)).transpose(0,2,1)
    qh = yy-bh@yx.transpose(0,2,1)
    qh = (qh+qh.transpose(0,2,1))/2
    eigen = np.linalg.eigvals(bh)
    if abs(eigen).max() >= 1 or np.min(abs(eigen.imag)) <= 0 or np.linalg.eigvalsh(qh).min() <= 0:
        raise ValueError('Unusable observed VAR')
    u = np.trace(bh,axis1=1,axis2=2)/2
    v = np.sqrt(np.linalg.det(bh)-u*u)
    jmat = (bh-u[:,None,None]*np.eye(2))/v[:,None,None]
    rho = np.hypot(u,v)**(1/k)
    angles = (np.arctan2(v,u)[:,None]+2*np.pi*np.arange(k)[None,:])/k
    roots = rho[:,None,None,None]*(np.cos(angles)[:,:,None,None]*np.eye(2)+np.sin(angles)[:,:,None,None]*jmat[:,None])
    gh = stationary(bh,qh)
    rawd = gh[:,None]-roots@gh[:,None]@roots.transpose(0,1,3,2)
    variances = np.diagonal(rawd,axis1=2,axis2=3).copy()
    variances[variances<=0] = 1.
    p = np.concatenate([roots.reshape(len(xx),k,4),variances],axis=2)
    return p, bh, qh


def fit_batch(xx, yx, yy, n, k):
    """Vectorized computation for valid observed starts; admissibility per path."""
    xx,yx,yy = [np.asarray(s,float) for s in (xx,yx,yy)]
    p0,bh,qh = initialize(xx,yx,yy,k)
    reps = len(xx)
    rx,ry,rz = [np.repeat(s,k,axis=0) for s in (xx,yx,yy)]
    p0flat = p0.reshape(-1,6)
    _, gradient, info = objective_score_information(p0flat,rx,ry,rz,k)
    if np.linalg.eigvalsh(info).min() <= 0:
        raise ValueError('Nonpositive starting information')
    update = np.linalg.solve(info,gradient[:,:,None])[:,:,0]
    p1 = p0flat-update
    valid = np.isfinite(p1).all(axis=1)&(p1[:,4:].min(axis=1)>0)
    finite = np.isfinite(p1[:,:4]).all(axis=1)
    stable = np.zeros(len(p1),dtype=bool)
    stable[finite] = abs(np.linalg.eigvals(p1[finite,:4].reshape(-1,2,2))).max(axis=1)<1
    valid &= stable
    objective = np.full(len(p1),np.nan)
    se = np.full(len(p1),np.nan)
    index = np.flatnonzero(valid)
    if len(index):
        obj,_,i1 = objective_score_information(p1[index],rx[index],ry[index],rz[index],k)
        good = np.isfinite(obj)&np.isfinite(i1).all(axis=(1,2))&(np.linalg.eigvalsh(i1).min(axis=1)>0)
        valid[index[~good]]=False
        index=index[good]; i1=i1[good]
        objective[index]=obj[good]
        se[index]=np.sqrt(np.linalg.inv(i1)[:,2,2]/n)
    unrestricted=.5*(np.linalg.slogdet(qh)[1]+2)
    lr=2*n*(objective.reshape(reps,k)-unrestricted[:,None])
    valid=valid.reshape(reps,k)&np.isfinite(se.reshape(reps,k))&(se.reshape(reps,k)>0)&(lr>=-1e-7)
    return dict(parameters=p1.reshape(reps,k,6),start=p0,standard_error=se.reshape(reps,k),
                statistics=lr,fallback=~valid.all(axis=1))


def confidence_set(s00,s10,s11,n,k=3,alpha_screen=.025,alpha_interval=.025):
    """Return disconnected component intervals, or R on a detected failure."""
    if not isinstance(k,(int,np.integer)) or k<3 or k%2==0:
        raise ValueError('Known odd k>=3 is required')
    if not (0<alpha_screen<1 and 0<alpha_interval<1 and alpha_screen+alpha_interval<1):
        raise ValueError('Positive error allocations must sum to less than one')
    fallback=dict(intervals=[[-float('inf'),float('inf')]],retained=None,statistics=None,fallback=True)
    try:
        ss=[np.asarray(s,float) for s in (s00,s10,s11)]
        if n<=0 or any(s.shape!=(2,2) or not np.isfinite(s).all() for s in ss): return fallback
        if not np.allclose(ss[0],ss[0].T) or not np.allclose(ss[2],ss[2].T): return fallback
        result=fit_batch(*(s[None] for s in ss),n,k)
        if result['fallback'][0]: return fallback
        stat=result['statistics'][0]
        critical=NormalDist().inv_cdf(1-alpha_screen/2)**2
        z=NormalDist().inv_cdf(1-alpha_interval/2)
        keep=np.flatnonzero(stat<=critical).tolist()
        effect=result['parameters'][0,:,2]; se=result['standard_error'][0]
        intervals=sorted([[float(effect[j]-z*se[j]),float(effect[j]+z*se[j])] for j in keep])
        return dict(intervals=intervals,retained=keep,statistics=stat.tolist(),fallback=False)
    except (np.linalg.LinAlgError,ValueError,FloatingPointError,AssertionError):
        return fallback
