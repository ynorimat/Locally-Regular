"""Paired on/off-grid inference from all 18,000 saved unknown-B records.

The on-grid estimator uses only S00, S10, S11, n. It fits an unrestricted
zero-mean observed VAR by OLS, with Q also estimated. Its Wald calibration
is asymptotic, not an exact finite-sample guarantee. No empirical simulation
or structural refitting is performed.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from manuscript_text import grid_text, write_outputs
from scipy.stats import norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[1]
OUT = BASE/'results/grid_contrast'
Z = float(norm.ppf(.975))


def wilson(count, total):
    p = count/total
    den = 1+Z*Z/total
    center = (p+Z*Z/(2*total))/den
    half = Z*np.sqrt(p*(1-p)/total+Z*Z/(4*total*total))/den
    return center-half, center+half


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    paths, cells, sources = [], [], {}
    for source in sorted((BASE/'results/unknown_B_raw').glob('*.npz')):
        sources[source.name] = hashlib.sha256(source.read_bytes()).hexdigest()
        with np.load(source) as raw:
            s00, s10, s11 = raw['s00'], raw['s10'], raw['s11']
            fits = raw['fits']; n = int(raw['n']); truth = int(raw['truth'])
            regime = str(raw['regime']); epsilon = float(raw['epsilon'])
        inverse = np.linalg.inv(s00)
        bhat = s10 @ inverse
        qhat = s11-bhat @ s10.transpose(0,2,1)
        qhat = (qhat+qhat.transpose(0,2,1))/2
        variance = qhat[:,1,1]*inverse[:,0,0]/n
        good = (np.isfinite(variance)&(variance>0)&
                (np.linalg.eigvalsh(qhat).min(axis=1)>0))
        structural_good = np.all(fits[:,:,5]==1,axis=1)
        # Retain attempted/valid indicators for every original record.
        selected = np.argmin(fits[:,:,2],axis=1)
        idx = np.arange(len(fits))
        off_target = -.5 if truth==2 else .25
        estimates = {'ols_on_grid':bhat[:,1,0],
                     'selected_off_grid':fits[idx,selected,0],
                     'oracle_off_grid':fits[:,truth,0]}
        ses = {'ols_on_grid':np.sqrt(variance),
               'selected_off_grid':fits[idx,selected,1],
               'oracle_off_grid':fits[:,truth,1]}
        row = dict(source_file=np.repeat(source.name,len(fits)),
                   original_index=idx, regime=np.repeat(regime,len(fits)),
                   n=np.repeat(n,len(fits)),truth=np.repeat(truth,len(fits)),
                   epsilon=np.repeat(epsilon,len(fits)),
                   on_grid_valid=good,off_grid_valid=structural_good,
                   selected_branch=selected)
        events = {}
        for method in estimates:
            target = .125 if method=='ols_on_grid' else off_target
            valid = good if method=='ols_on_grid' else structural_good
            low,high=estimates[method]-Z*ses[method],estimates[method]+Z*ses[method]
            covered=(low<=target)&(target<=high)
            events[method]=covered
            for key,value in [('estimate',estimates[method]),('se',ses[method]),
                              ('lower',low),('upper',high),('covered',covered)]:
                row[method+'_'+key]=value
            count=int(covered[valid].sum()); total=int(valid.sum())
            lo,hi=wilson(count,total)
            cells.append(dict(source_file=source.name,regime=regime,n=n,truth=truth,
                              epsilon=epsilon,method=method,target=target,
                              attempted=len(fits),completed=total,failures=len(fits)-total,
                              coverage_count=count,coverage_rate=count/total,
                              coverage_lo=lo,coverage_hi=hi,
                              median_width=float(np.median((high-low)[valid]))))
        paths.append(pd.DataFrame(row))
    records=pd.concat(paths,ignore_index=True); summary=pd.DataFrame(cells)
    assert len(records)==18000 and len(summary)==54
    assert records.on_grid_valid.all() and records.off_grid_valid.all()
    records.to_csv(OUT/'records.csv',index=False)
    summary.to_csv(OUT/'summary.csv',index=False)
    paired=[]
    for (regime,n,truth),group in records.groupby(['regime','n','truth']):
        delta=(group.ols_on_grid_covered.astype(int)-group.selected_off_grid_covered.astype(int)).to_numpy()
        paired.append(dict(regime=regime,n=int(n),truth=int(truth),pairs=len(delta),
                           on_minus_off_coverage=float(delta.mean()),
                           paired_mc_se=float(delta.std(ddof=1)/np.sqrt(len(delta)))))
    pd.DataFrame(paired).to_csv(OUT/'paired_coverage.csv',index=False)
    def cell(regime,n,truth,method):
        return summary[(summary.regime==regime)&(summary.n==n)&
                       (summary.truth==truth)&(summary.method==method)].iloc[0]
    all_grid=summary[summary.method=='ols_on_grid']
    text=grid_text(BASE)
    (OUT/'main_text.tex').write_text(text,encoding='utf-8')
    names={'inverse_n':r'$1/n$','local_c4':r'$4/\sqrt n$','fixed_e02':r'$.2$'}
    rows=[r'\begin{table}[htbp]',r'\centering\small',
          r'\caption{Paired on/off-grid comparison on the same 18,000 saved paths. Each row uses 1,000 paths with no estimator failures. Coverage is in percent; widths are medians. Off-grid columns use the likelihood-selected structural Wald interval for $A_{21}$; on-grid columns use unrestricted OLS for $B_{21}=1/8$. Wilson intervals, paired Monte Carlo errors, and all per-path records are supplied in the supplement.}',
          r'\label{tab:grid_contrast}',r'\begin{tabular}{llrrrrr}',r'\toprule',
          r'$\varepsilon$ & True branch & $n$ & Off-grid cover & On-grid cover & Off-grid width & On-grid width \\',r'\midrule']
    for regime,label in names.items():
        for truth in (0,2):
            for n in (2000,8000,32000):
                o=cell(regime,n,truth,'selected_off_grid'); a=cell(regime,n,truth,'ols_on_grid')
                rows.append(f'{label} & {truth} & {n} & {100*o.coverage_rate:.1f} & {100*a.coverage_rate:.1f} & {o.median_width:.3f} & {a.median_width:.3f} '+r'\\')
        rows.append(r'\addlinespace')
    rows += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    (OUT/'table.tex').write_text('\n'.join(rows)+'\n',encoding='utf-8')
    plt.rcParams.update({'font.family':'serif','font.size':10,'pdf.fonttype':42,'ps.fonttype':42})
    fig,axes=plt.subplots(1,2,figsize=(7,2.8))
    styles=[('selected_off_grid','Off-grid: selected','#28649d','-'),
            ('oracle_off_grid','Off-grid: true-branch oracle','#b35523','--'),
            ('ols_on_grid','On-grid: OLS','#287a49','-.')]
    for method,label,color,style in styles:
        sub=summary[(summary.truth==2)&(summary.regime=='inverse_n')&(summary.method==method)].sort_values('n')
        axes[0].errorbar(sub.n,sub.coverage_rate,
                         yerr=np.array([sub.coverage_rate-sub.coverage_lo,sub.coverage_hi-sub.coverage_rate]),
                         label=label,color=color,linestyle=style,marker='o',markersize=3,capsize=2)
        axes[1].plot(sub.n,sub.median_width,color=color,linestyle=style,marker='o',markersize=3)
    axes[0].axhline(.95,color='.5',linestyle=':',linewidth=1)
    axes[0].set(ylabel='Effect coverage',ylim=(0,1.04))
    axes[1].set(ylabel='Median interval width',ylim=(0,None))
    for ax in axes:
        ax.set_xscale('log');ax.set_xticks([2000,8000,32000],['2,000','8,000','32,000'])
        ax.set_xlabel('Observed transitions');ax.grid(alpha=.18)
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=3,frameon=False,fontsize=8)
    fig.tight_layout(rect=(0,.13,1,1),pad=.6)
    fig.savefig(BASE/'figures/grid_contrast.pdf');fig.savefig(BASE/'figures/grid_contrast.png',dpi=180)
    plt.close(fig)
    metadata=dict(paths=len(records),conditions=18,summary_rows=54,
                  target='tau_3,21 = B_21 = 1/8',
                  estimator='Unrestricted zero-mean observed VAR OLS; B and Q estimated.',
                  standard_error='sqrt(Qhat[1,1] * inv(S00)[0,0] / n)',
                  calibration='Uniform asymptotic normal Wald on the fixed theorem family; not an exact finite-sample guarantee.',
                  empirical_simulations_added=0,structural_refits_added=0,
                  raw_input_sha256=sources)
    (OUT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
    write_outputs(BASE)
    print(text)
    print(all_grid[['regime','n','truth','coverage_rate','median_width']].to_string(index=False))


if __name__=='__main__': main()
