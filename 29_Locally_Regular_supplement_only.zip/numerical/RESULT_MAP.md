# Results and data files

Paths below are relative to numerical/results/. The companion PDF is docs/complete_results.pdf.

| Complete-results item | Numerical records |
|---|---|
| Corollary S1 and Figure S1 | Known-law formulas; `local_global_information.csv` |
| Table S1, nonrotation KL | `branch_diagnostics/nonrotation_distances.csv` |
| Table S2 | Procedure information and guarantee definitions |
| Table S3, all principal conditions | `unknown_B_summary.csv`, `grid_contrast/summary.csv` |
| Table S4, selection diagnostics | `branch_diagnostics/branch_cells.csv` |
| Table S5, worked path | `selection_diagnostics/worked_path.csv` |
| Table S6, sensitivity | `robustness/sensitivity_summary.csv` |
| Table S7, nonrotation | `nonrotation_mc/summary.csv` |
| Tables S8-S9, screened unions | `branch_union/summary.csv`, `branch_union/records.csv` |
| Tables S10-S11, sensitivity unions | `sensitivity_union/summary.csv`, `sensitivity_union/records.csv` |
| Tables S12-S13, paired comparisons | `method_comparisons/local_fit_comparison.csv` |
| Tables S14-S15, one-step estimates | `method_comparisons/one_step_summary.csv`, `method_comparisons/one_step_records.csv` |


Main-paper Table 2 uses branch_diagnostics/setting_distances.csv.
Table 3 uses branch_union/summary.csv and sensitivity_union/summary.csv.
Table 4 uses method_comparisons/local_fit_comparison.csv and method_comparisons/one_step_summary.csv.
The methods are paired by simulated path. The final row can be checked with verify_table4_medians.py.
The known-transition benchmarks in docs/additional_diagnostics.pdf use equal_information_summary.csv and the likelihood-ratio summaries in this directory.
