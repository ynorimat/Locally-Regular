"""Independent numerical and interval checks for the paired method comparisons."""
from pathlib import Path
from statistics import NormalDist
from itertools import combinations
import csv
import hashlib
import json
import numpy as np
from one_step_union import confidence_set, fit_batch, objective_score_information
from method_comparisons import cells

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'results/method_comparisons'


def read(path):
    with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))


def scalar_law(p,k):
    a=p[:4].reshape(2,2);d=np.diag(p[4:])
    b=np.linalg.matrix_power(a,k)
    q=sum(np.linalg.matrix_power(a,u)@d@np.linalg.matrix_power(a,u).T for u in range(k))
    gamma=np.linalg.solve(np.eye(4)-np.kron(a,a),d.ravel()).reshape(2,2)
    return b,q,gamma


def scalar_objective(p,xx,yx,yy,k):
    b,q,_=scalar_law(p,k)
    residual=yy-b@yx.T-yx@b.T+b@xx@b.T
    return .5*(np.linalg.slogdet(q)[1]+np.trace(np.linalg.solve(q,residual)))


def finite_difference(p,xx,yx,yy,k):
    step=2e-6
    b,q,gamma=scalar_law(p,k);qi=np.linalg.inv(q)
    pairs=[(scalar_law(p+step*e,k),scalar_law(p-step*e,k)) for e in np.eye(6)]
    db=[(a[0]-b[0])/(2*step) for a,b in pairs]
    dq=[(a[1]-b[1])/(2*step) for a,b in pairs]
    information=np.array([[np.trace(qi@db[i]@gamma@db[j].T)+.5*np.trace(qi@dq[i]@qi@dq[j]) for j in range(6)] for i in range(6)])
    gradient=np.array([(scalar_objective(p+step*e,xx,yx,yy,k)-scalar_objective(p-step*e,xx,yx,yy,k))/(2*step) for e in np.eye(6)])
    return gradient,information


def interval_events(intervals,target):
    if not intervals:return [0,0,0,0,1,0.,0.]
    left=min(v[0] for v in intervals);right=max(v[1] for v in intervals)
    length=0.
    for size in range(1,len(intervals)+1):
        for group in combinations(intervals,size):
            length+=(-1)**(size+1)*max(0.,min(v[1] for v in group)-max(v[0] for v in group))
    return [int(any(l<=target<=r for l,r in intervals)),int(left<0<right),int(left>0 or right<0),
            int(left>0 if target<0 else right<0),0,right-left,length]


def main():
    protocol=json.loads((BASE/'method_comparisons_protocol.json').read_text())
    z=NormalDist().inv_cdf(1-protocol['alpha_interval']/2)
    cutoff=NormalDist().inv_cdf(1-protocol['alpha_screen']/2)**2
    records=read(OUT/'one_step_records.csv');summaries=read(OUT/'one_step_summary.csv')
    assert len(records)==32000 and len(summaries)==46
    lookup={(r['source_file'],int(r['record'])):r for r in records}
    maximum=dict(score=0.,information=0.,update=0.,se=0.,api_statistic=0.)
    candidates=0;api_cases=0;groups={}
    computed=json.loads((OUT/'computation.json').read_text())
    for path,meta,ss in cells():
        assert hashlib.sha256(path.read_bytes()).hexdigest()==computed['input_sha256'][path.relative_to(BASE).as_posix()]
        n,k=meta['n'],meta['k'];reps=len(ss[0]);out=fit_batch(*ss,n,k)
        for i in range(reps):
            row=lookup[path.name,i]
            assert bool(int(row['fallback']))==bool(out['fallback'][i])
            for j in range(k):
                assert abs(float(row[f'lower{j}'])-(out['parameters'][i,j,2]-z*out['standard_error'][i,j]))<1e-12
                assert abs(float(row[f'upper{j}'])-(out['parameters'][i,j,2]+z*out['standard_error'][i,j]))<1e-12
                assert abs(float(row[f'lr{j}'])-out['statistics'][i,j])<1e-9
            iv=[(float(row[f'lower{j}']),float(row[f'upper{j}'])) for j in range(k) if float(row[f'lr{j}'])<=cutoff]
            if int(row['fallback']):iv=[(-np.inf,np.inf)]
            ev=interval_events(iv,meta['target'])
            for key,value in zip(['covered','both','declared','wrong','empty','diameter','total_length'],ev):
                assert abs(float(row[key])-value)<1e-9,(path.name,i,key)
            key=tuple(str(meta[v]) for v in ['setting','regime','n','truth'])
            groups.setdefault(key,[]).append(row)
        for i in [0,reps//2,reps-1]:
            xx,yx,yy=[s[i] for s in ss]
            # A separate eigendecomposition checks all initialized matrix roots.
            bh=yx@np.linalg.inv(xx);qh=yy-bh@yx.T;gh=np.linalg.solve(np.eye(4)-np.kron(bh,bh),qh.ravel()).reshape(2,2)
            eigen,vec=np.linalg.eig(bh);pos=np.argmax(eigen.imag)
            for j in range(k):
                roots=np.empty(2,complex);roots[pos]=abs(eigen[pos])**(1/k)*np.exp(1j*(np.angle(eigen[pos])+2*np.pi*j)/k);roots[1-pos]=np.conj(roots[pos])
                a=np.real(vec@np.diag(roots)@np.linalg.inv(vec))
                dv=np.diag(gh-a@gh@a.T).copy();dv[dv<=0]=1.
                p=np.r_[a.ravel(),dv]
                assert np.max(abs(p-out['start'][i,j]))<1e-10
                g,info=finite_difference(p,xx,yx,yy,k)
                _,ga,ia=objective_score_information(p[None],xx[None],yx[None],yy[None],k)
                updated=p-np.linalg.solve(info,g)
                for name,error in [('score',abs(g-ga[0]).max()),('information',abs(info-ia[0]).max()),('update',abs(updated-out['parameters'][i,j]).max())]:
                    maximum[name]=max(maximum[name],float(error))
                _,ipost=finite_difference(out['parameters'][i,j],xx,yx,yy,k)
                se=np.sqrt(np.linalg.inv(ipost)[2,2]/n)
                maximum['se']=max(maximum['se'],abs(float(se-out['standard_error'][i,j])))
                candidates+=1
            ans=confidence_set(xx,yx,yy,n,k)
            assert ans['fallback']==bool(out['fallback'][i])
            if not ans['fallback']:
                maximum['api_statistic']=max(maximum['api_statistic'],max(abs(np.array(ans['statistics'])-out['statistics'][i])))
                assert ans['retained']==np.flatnonzero(out['statistics'][i]<=cutoff).tolist()
            api_cases+=1
    assert candidates==462 and api_cases==138
    assert maximum['score']<1e-8 and maximum['information']<1e-7 and maximum['update']<1e-6 and maximum['se']<1e-7
    for s in summaries:
        rr=groups[tuple(s[v] for v in ['setting','regime','n','truth'])]
        count=sum(int(r['covered']) for r in rr);p=count/len(rr);zz=NormalDist().inv_cdf(.975)
        center=(p+zz*zz/(2*len(rr)))/(1+zz*zz/len(rr))
        half=zz*np.sqrt(p*(1-p)/len(rr)+zz*zz/(4*len(rr)**2))/(1+zz*zz/len(rr))
        assert int(s['covered_count'])==count and abs(float(s['coverage'])-p)<1e-12
        assert abs(float(s['coverage_lo'])-(center-half))<1e-12 and abs(float(s['coverage_hi'])-(center+half))<1e-12
        for key in ['declared','wrong','empty','fallback','true_retained']:
            assert int(s[key+'_count'])==sum(int(r[key]) for r in rr)
        for key in ['diameter','total_length']:
            assert abs(float(s['median_'+key])-np.median([float(r[key]) for r in rr]))<1e-10
    # Paired local-fit summaries agree with original independently audited records.
    original={}
    for folder in ['branch_union','sensitivity_union']:
        for r in read(BASE/f'results/{folder}/summary.csv'):
            setting=(r.get('setting') or ('Base' if r['experiment']=='principal' else 'Nonrotation')).title()
            original[(setting,r['regime'],r['n'],r['truth'],r['method'])]=r
    paired=read(OUT/'local_fit_comparison.csv');assert len(paired)==92
    for r in paired:
        s=original[tuple(r[v] for v in ['setting','regime','n','truth','method'])]
        for a,b in [('coverage','covered_rate'),('diameter','median_diameter'),('length','median_total_length'),('declared','declared_rate'),('wrong','wrong_rate')]:
            assert float(r[a])==float(s[b])
    # Defined failure behavior and empty-set behavior are exercised separately.
    assert confidence_set(np.zeros((2,2)),yx,yy,n,k)['fallback']
    assert confidence_set(np.eye(2),2*np.eye(2),5*np.eye(2),n,k)['fallback']
    assert confidence_set(np.eye(2),np.zeros((2,2)),np.eye(2),n,k)['fallback']
    assert confidence_set(np.eye(2),yx,np.full((2,2),np.nan),n,k)['fallback']
    empty=next(r for r in records if int(r['empty']))
    path=next(p for p,meta,ss in cells() if p.name==empty['source_file'])
    with np.load(path) as d:
        i=int(empty['record']);answer=confidence_set(*(d[v][i] for v in ['s00','s10','s11']),int(d['n']),int(d['k']) if 'k' in d else 3)
        assert not answer['fallback'] and answer['intervals']==[]
    report=dict(status='passed',records=32000,summary_cells=46,paired_summary_rows=92,finite_difference_candidates=candidates,
                api_cases=api_cases,failure_cases=4,empty_case=1,max_errors=maximum,
                scope='Independent finite-difference score/information/update audit on fixed records; all-path interval inclusion-exclusion and summary verification; no simulation or optimizer runs.')
    (OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))


if __name__=='__main__':main()
