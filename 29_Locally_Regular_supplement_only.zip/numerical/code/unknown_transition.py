"""Unknown-transition likelihood/Wald diagnostic; no uniform coverage claim.

The estimator receives only observed-path second moments and k=3. Three
data-derived real cube roots of the unrestricted OLS transition initialize
unrestricted six-coordinate conditional Gaussian likelihood fits. Selection
uses the largest attained likelihood, not knowledge of the generating branch.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.linalg import solve_discrete_lyapunov
from scipy.stats import norm
from example_model import A, coarsen
from rotation_family import local_information

BASE = Path(__file__).resolve().parents[1]
E = np.zeros((6, 2, 2))
for j in range(4):
    E[j].flat[j] = 1.


def model_derivatives(x):
    a = x[:4].reshape(2, 2)
    d = np.diag(np.exp(x[4:]))
    dd = np.zeros_like(E)
    dd[4, 0, 0], dd[5, 1, 1] = d[0, 0], d[1, 1]
    p = a @ a
    dp = E @ a + a @ E
    b = p @ a
    db = dp @ a + p @ E
    q = d + a @ d @ a.T + p @ d @ p.T
    dq = (dd + E @ d @ a.T + a @ dd @ a.T
          + a @ d @ E.transpose(0, 2, 1)
          + dp @ d @ p.T + p @ dd @ p.T
          + p @ d @ dp.transpose(0, 2, 1))
    return b, q, db, dq


def objective(x, s00, s10, s11):
    b, q, db, dq = model_derivatives(x)
    qi = np.linalg.inv(q)
    residual = s11 - b @ s10.T - s10 @ b.T + b @ s00 @ b.T
    value = .5 * (np.linalg.slogdet(q)[1] + np.trace(qi @ residual))
    qgrad = .5 * (qi - qi @ residual @ qi)
    bgrad = qi @ (b @ s00 - s10)
    gradient = (np.einsum('ij,kij->k', qgrad, dq)
                + np.einsum('ij,kij->k', bgrad, db))
    return float(value), gradient


def starting_points(s00, s10, s11):
    bhat = np.linalg.solve(s00, s10.T).T
    qhat = s11 - bhat @ s10.T
    u = np.trace(bhat) / 2
    v2 = np.linalg.det(bhat) - u*u
    if v2 <= 0:
        return []
    v = np.sqrt(v2)
    jmat = (bhat-u*np.eye(2))/v
    radius = np.hypot(u, v)**(1/3)
    phase = np.arctan2(v, u)
    starts = []
    for branch in range(3):
        phi = (phase+2*np.pi*branch)/3
        a = radius*(np.cos(phi)*np.eye(2)+np.sin(phi)*jmat)
        basis = np.stack([coarsen(a, np.diag([1., 0.]))[1].ravel(),
                          coarsen(a, np.diag([0., 1.]))[1].ravel()], axis=1)
        dv = np.maximum(np.linalg.lstsq(basis, qhat.ravel(), rcond=None)[0], .05)
        starts.append(np.r_[a.ravel(), np.log(dv)])
    return starts


def fit_record(task):
    s00, s10, s11, n = task
    starts = starting_points(s00, s10, s11)
    fits = np.full((3, 11), np.nan)
    # Columns: A21, SE, objective, score norm, stable, accepted, A11,A12,A22,d1,d2.
    for branch, x0 in enumerate(starts):
        result = minimize(objective, x0, args=(s00, s10, s11), jac=True,
                          method='BFGS', options={'gtol': 1e-8, 'maxiter': 250})
        score = np.linalg.norm(result.jac, ord=np.inf)
        if score > 1e-6:
            result = minimize(objective, result.x, args=(s00, s10, s11), jac=True,
                              method='BFGS', options={'gtol': 1e-9, 'maxiter': 500})
            score = np.linalg.norm(result.jac, ord=np.inf)
        a = result.x[:4].reshape(2, 2)
        d = np.diag(np.exp(result.x[4:]))
        stable = np.max(np.abs(np.linalg.eigvals(a))) < 1.
        se = np.nan
        if stable:
            info = local_information(a, d, 3)
            if np.linalg.eigvalsh(info).min() > 1e-10:
                se = np.sqrt(np.linalg.inv(info)[2, 2]/n)
        accepted = stable and score < 1e-6 and np.isfinite(se)
        fits[branch] = [a[1, 0], se, result.fun, score, stable, accepted,
                        a[0, 0], a[0, 1], a[1, 1], d[0, 0], d[1, 1]]
    return fits


def simulate_stats(n, reps, branch, epsilon, seed):
    rng = np.random.default_rng(seed)
    delta = epsilon if branch == 2 else .7*epsilon
    d = np.diag([1+delta, 1-delta])
    b, q = coarsen(A[branch], d)
    gamma = solve_discrete_lyapunov(A[branch], d)
    z = rng.standard_normal((reps, 2)) @ np.linalg.cholesky(gamma).T
    chol = np.linalg.cholesky(q)
    s00 = np.zeros((reps, 2, 2)); s10 = s00.copy(); s11 = s00.copy()
    for _ in range(n):
        nxt = z @ b.T + rng.standard_normal((reps, 2)) @ chol.T
        s00 += z[:, :, None]*z[:, None, :]
        s10 += nxt[:, :, None]*z[:, None, :]
        s11 += nxt[:, :, None]*nxt[:, None, :]
        z = nxt
    return s00/n, s10/n, s11/n


def wilson(count, size):
    z = norm.ppf(.975); p = count/size; den = 1+z*z/size
    center = (p+z*z/(2*size))/den
    radius = z*np.sqrt(p*(1-p)/size+z*z/(4*size*size))/den
    return center-radius, center+radius


def summarize():
    rows = []
    for path in sorted((BASE/'results/unknown_B_raw').glob('*.npz')):
        with np.load(path) as z:
            fit = z['fits']; n = int(z['n']); truth = int(z['truth'])
            regime = str(z['regime']); epsilon = float(z['epsilon'])
        reps = len(fit); complete = np.all(fit[:, :, 5] == 1, axis=1)
        valid = fit[complete]; r = len(valid)
        chosen = np.argmin(valid[:, :, 2], axis=1)
        selected = valid[np.arange(r), chosen]
        target = A[truth, 1, 0]
        intervals = (valid[:, :, 0]-norm.ppf(.975)*valid[:, :, 1],
                     valid[:, :, 0]+norm.ppf(.975)*valid[:, :, 1])
        for method, low, high in [
            ('selected', intervals[0][np.arange(r), chosen], intervals[1][np.arange(r), chosen]),
            ('true_branch_oracle', intervals[0][:, truth], intervals[1][:, truth])]:
            cover = (low <= target) & (target <= high)
            declare = (low > 0) | (high < 0)
            wrong = (low > 0) if target < 0 else (high < 0)
            row = dict(regime=regime, n=n, epsilon=epsilon, truth=truth, method=method,
                       reps=reps, completed=r, failures=reps-r,
                       median_width=float(np.median(high-low)),
                       branch_selection_rate=float(np.mean(chosen==truth)),
                       max_score=float(valid[:, :, 3].max()))
            for name, values in [('coverage',cover),('declare',declare),('wrong',wrong)]:
                count = int(values.sum()); lo, hi = wilson(count,r)
                row.update({name+'_count':count, name+'_rate':count/r,
                            name+'_lo':lo, name+'_hi':hi})
            rows.append(row)
    table = pd.DataFrame(rows)
    table.to_csv(BASE/'results/unknown_B_summary.csv', index=False)
    print(table[['regime','n','truth','method','completed','coverage_rate','wrong_rate','median_width']].to_string(index=False))
    return table


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--reps',type=int,default=1000)
    parser.add_argument('--workers',type=int,default=1)
    parser.add_argument('--seed',type=int,default=20260930)
    parser.add_argument('--pilot',action='store_true')
    parser.add_argument('--summarize',action='store_true')
    args = parser.parse_args()
    if args.summarize:
        summarize(); return
    folder = BASE/('results/unknown_B_pilot' if args.pilot else 'results/unknown_B_raw')
    folder.mkdir(parents=True, exist_ok=True)
    sizes = (2000,) if args.pilot else (2000,8000,32000)
    regimes = ('inverse_n','local_c4','fixed_e02')
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for ni,n in enumerate(sizes):
            for ri,regime in enumerate(regimes):
                epsilon = {'inverse_n':1/n,'local_c4':4/np.sqrt(n),'fixed_e02':.2}[regime]
                for truth in (0,2):
                    seed = np.random.SeedSequence([args.seed, n, ri, truth])
                    s00,s10,s11 = simulate_stats(n,args.reps,truth,epsilon,seed)
                    tasks = ((s00[j],s10[j],s11[j],n) for j in range(args.reps))
                    fits = np.array(list(pool.map(fit_record,tasks,chunksize=10)))
                    np.savez_compressed(folder/f'{regime}_n{n}_truth{truth}.npz',
                        s00=s00,s10=s10,s11=s11,fits=fits,n=n,truth=truth,
                        epsilon=epsilon,regime=regime,seed=args.seed)
                    print(f'{regime} n={n} truth={truth} completed={np.all(fits[:,:,5]==1,axis=1).sum()}/{args.reps}',flush=True)
    if not args.pilot:
        (BASE/'results/unknown_B_metadata.json').write_text(json.dumps(dict(
            seed=args.seed,reps_per_cell=args.reps,sizes=list(sizes),regimes=list(regimes),
            truth_branches=[0,2],total_paths=len(sizes)*len(regimes)*2*args.reps,
            generator='stationary observed Gaussian VAR paths, exact recursion',
            estimation='six-coordinate conditional likelihood, three data-derived root starts',
            selection='best attained conditional likelihood; not a certified global optimum',
            information='plug-in full structural stationary Fisher information / n',
            inference='nominal 95% local Wald diagnostic; no uniform coverage guarantee',
            failure_policy='report all attempted paths; summarize only complete three-fit records'
        ),indent=2)+'\n')
        summarize()


if __name__ == '__main__':
    main()
