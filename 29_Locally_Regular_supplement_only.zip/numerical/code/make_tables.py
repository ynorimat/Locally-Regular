"""Generate manuscript tables and independent local-information records."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm
from rotation_family import RotationFamily, local_information
BASE=Path(__file__).resolve().parents[1]

def main():
    f=RotationFamily();out=BASE/'results'
    rows=[]
    for e in np.r_[0.,np.logspace(-6,np.log10(.5),180)]:
        mins=[]
        for branch,t in [(2,e),(0,.7*e)]:
            info=local_information(f.roots[branch],np.diag([1+t,1-t]),3)
            mins.append(float(np.linalg.eigvalsh(info)[0]))
        kn,kg,kq=f.profile_kl(e,1,2,0)
        rows.append(dict(epsilon=e,minimum_information_negative=mins[0],minimum_information_positive=mins[1],
                         nearest_transition_KL=float(kq),nearest_initial_KL=float(kg)))
    pd.DataFrame(rows).to_csv(out/'local_global_information.csv',index=False)
    hrows=[]
    for h in range(1,10):
        vals=[np.linalg.matrix_power(a,h)[1,0] for a in f.roots]
        hrows.append(dict(h=h,branch0=vals[0],branch1=vals[1],branch2=vals[2]))
    pd.DataFrame(hrows).to_csv(out/'branch_horizons.csv',index=False)
    error=pd.read_csv(out/'simple_LR_errors.csv');br=[]
    for (n,regime),g in error.groupby(['n','regime'],sort=False):
        ps=g.error_rate.to_numpy(); N=g.reps.to_numpy()
        avg=ps.mean();se=np.sqrt(np.sum(ps*(1-ps)/N))/2
        c={'local_c1':1,'local_c4':4,'local_c12':12}.get(regime,0)
        limit=.5 if regime=='inverse_n' else norm.cdf(-c*np.sqrt(13/2352))
        br.append(dict(n=n,regime=regime,epsilon=g.epsilon.iloc[0],balanced_error=avg,
                       mc_se=se,normal_low=avg-1.95996398454*se,normal_high=avg+1.95996398454*se,
                       analytical_limit=limit,evaluation_reps=int(N.sum())))
    pd.DataFrame(br).to_csv(out/'balanced_LR_errors.csv',index=False)
    bound=[]
    for n in [10,100,500,1000,2000,8000,32000]:
        total,kg,kq=f.profile_kl(1/n,n,2,0)
        bound.append(dict(n=n,epsilon=1/n,exact_profiled_KL=float(total),
                          lower_probability_diameter_ge_075=max(0,.9-np.sqrt(total/2))))
    pd.DataFrame(bound).to_csv(out/'finite_bounds.csv',index=False)
    print('Generated deterministic information, response, testing-error, and bound summaries.')

if __name__=='__main__':main()
