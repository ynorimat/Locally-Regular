"""Screen all k local fits for a bivariate path at a known odd k>=3.

Input fits use the documented columns produced by unknown_transition.fit_record:
A21, standard error, objective, score norm, spectral radius, accepted,
A11, A12, A22, d1, d2. An optional twelfth evaluation-count field is ignored.
Likelihood and standard errors are recomputed here for the supplied k.
No true model, branch label, transition, or variance is supplied.
The coverage theorem requires consistent local solutions; this function cannot
certify optimizer neighborhoods and does not promise finite-sample coverage.
"""
from statistics import NormalDist
import numpy as np
from gaussian_var import observed, fisher_standard_error


def confidence_union(s00, s10, s11, fits, n, alpha_screen=.025, alpha_interval=.025, k=3):
    if not isinstance(k, (int, np.integer)) or k < 3 or k % 2 == 0:
        raise ValueError('This implementation targets the stated odd-k families, k>=3.')
    if not (0<alpha_screen<1 and 0<alpha_interval<1 and alpha_screen+alpha_interval<1):
        raise ValueError('Positive error allocations must sum to less than one.')
    fallback=dict(intervals=[[-float('inf'),float('inf')]],retained=None,statistics=None,fallback=True)
    try:
        x,y,z=[np.asarray(s,float) for s in (s00,s10,s11)]
        f=np.asarray(fits,float)
        if n<=0 or any(s.shape!=(2,2) for s in (x,y,z)) or f.shape not in ((k,11),(k,12)): return fallback
        if not all(np.all(np.isfinite(s)) for s in (x,y,z,f)): return fallback
        if not np.all(f[:,5]==1) or np.linalg.eigvalsh((x+x.T)/2).min()<=0: return fallback
        bh=np.linalg.solve(x,y.T).T
        eigen=np.linalg.eigvals(bh)
        if abs(eigen).max()>=1 or abs(eigen.imag).min()==0: return fallback
        qh=z-bh@y.T; qh=(qh+qh.T)/2
        if np.linalg.eigvalsh(qh).min()<=0: return fallback
        p=f[:,[6,7,0,8,9,10]]
        if p[:,4:].min()<=0: return fallback
        a,d,_,b,q=observed(p,k)
        if abs(np.linalg.eigvals(a)).max()>=1: return fallback
        residual=z-b@y.T-y@b.transpose(0,2,1)+b@x@b.transpose(0,2,1)
        obj=.5*(np.linalg.slogdet(q)[1]+np.trace(np.linalg.solve(q,residual),axis1=1,axis2=2))
        unrestricted=.5*(np.linalg.slogdet(qh)[1]+2)
        statistics=2*n*(obj-unrestricted)
        if statistics.min() < -1e-7: return fallback
        se=fisher_standard_error(p,n,k)
        if not np.all(np.isfinite(se)) or se.min()<=0: return fallback
        threshold=NormalDist().inv_cdf(1-alpha_screen/2)**2
        critical=NormalDist().inv_cdf(1-alpha_interval/2)
        retained=np.flatnonzero(statistics<=threshold).tolist()
        intervals=sorted([[float(f[j,0]-critical*se[j]),float(f[j,0]+critical*se[j])] for j in retained])
        return dict(intervals=intervals,retained=retained,statistics=statistics.tolist(),fallback=False)
    except (np.linalg.LinAlgError,AssertionError,FloatingPointError,ValueError,IndexError):
        return fallback
