"""Closed-form quantities for the 2D, k=3 example. No estimated B is used here."""
from __future__ import annotations
import numpy as np
from numpy.typing import NDArray
FloatArray = NDArray[np.float64]
B: FloatArray = np.array([[0., -0.125], [0.125, 0.]])
A: FloatArray = np.array([
    [[np.sqrt(3.)/4., -.25], [.25, np.sqrt(3.)/4.]],
    [[-np.sqrt(3.)/4., -.25], [.25, -np.sqrt(3.)/4.]],
    [[0., .5], [-.5, 0.]],
])
C = 21. / 16.
E = np.diag([1., -1.])

def coarsen(a: FloatArray, d: FloatArray, k: int = 3) -> tuple[FloatArray, FloatArray]:
    if k < 1 or int(k) != k:
        raise ValueError('k must be a positive integer')
    p = np.eye(2); q = np.zeros((2, 2))
    for _ in range(k):
        q += p @ d @ p.T
        p = p @ a
    return p, (q + q.T) / 2.

# Q_m(diag(s+t,s-t)) = C*s*I + t*H_m.
H = np.stack([coarsen(a, E)[1] for a in A])
_eigen = [np.linalg.eigh(h) for h in H]
G = np.array([item[0][1] for item in _eigen])
U = np.stack([item[1][:, ::-1] for item in _eigen])  # +g eigenvalue first

def profile_loglik(s: FloatArray, n: int, branch: int) -> FloatArray:
    """Global supremum over d1,d2>0 for FIXED A[branch], using sample covariance s.

    Omits the common -n*p*log(2*pi)/2 constant. Boundary optima are suprema
    approached as a fine-scale variance tends to zero. Coarse Q stays PD.
    Standard floating-point arithmetic is used, not interval certification.
    """
    s = np.asarray(s, dtype=float)
    if s.shape[-2:] != (2, 2) or n <= 0 or branch not in (0,1,2):
        raise ValueError('Require (...,2,2) sample covariance, n>0, branch in 0..2')
    u = U[branch]; g = G[branch]
    x = np.einsum('i,...ij,j->...', u[:,0], s, u[:,0])
    y = np.einsum('i,...ij,j->...', u[:,1], s, u[:,1])
    if np.any(x <= 0.) or np.any(y <= 0.):
        raise ValueError('Rotated sample variances must be positive')
    b = np.clip(C * (x-y) / (g*(x+y)), -1., 1.)
    scale = .5 * (x/(C+g*b) + y/(C-g*b))
    lam1 = scale*(C+g*b); lam2 = scale*(C-g*b)
    return -.5 * n * (np.log(lam1) + np.log(lam2) + 2.)

def exact_kl(epsilon: float | FloatArray, n: int) -> FloatArray:
    """KL(P_0,e^(n) || P_2,e^(n)); n coarse transitions + stationary initial state."""
    e = np.asarray(epsilon, dtype=float)
    if n < 0 or np.any(np.abs(e) >= 1.):
        raise ValueError('Require n>=0 and |epsilon|<1')
    x = e*e
    kq = -117.*x/(2.*(441.-169.*x)) + .5*(np.log1p(-169.*x/441.)-np.log1p(-325.*x/441.))
    kg = -81.*x/(26.*(25.-9.*x)) + .5*(np.log1p(-9.*x/25.)-np.log1p(-9.*x/13.))
    return kg + n*kq

def critical_correlation(epsilon: float | FloatArray) -> FloatArray:
    e = np.asarray(epsilon, dtype=float)
    if np.any((e < 0.) | (e >= 1.)):
        raise ValueError('Require 0<=epsilon<1')
    return np.sqrt(3.)*e / np.sqrt(100.-49.*e*e)
