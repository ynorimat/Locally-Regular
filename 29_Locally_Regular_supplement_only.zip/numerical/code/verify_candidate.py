"""Independent checks for the added local quadratic projection and correlation pivot.

Symbolic checks are separated from Monte Carlo checks. None replace proofs.
Outputs do not tune alpha, sample sizes, model settings, or method definitions.
"""
from __future__ import annotations
import json
from pathlib import Path
import sympy as s
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from scipy.linalg import solve_discrete_lyapunov
from equal_information import correlation_keep, evaluate_record
from local_sequence_experiments import wishart, wilson
from example_model import A,U,coarsen
BASE=Path(__file__).resolve().parents[1]


def symbolic_projection():
    rt=s.sqrt(3); I=s.eye(2); E=s.diag(1,-1)
    a=s.Matrix([[rt/4,-s.Rational(1,4)],[s.Rational(1,4),rt/4]])
    amin=s.Matrix([[0,s.Rational(1,2)],[-s.Rational(1,2),0]])
    x=s.Matrix(s.symbols('h11 h12 h21 h22 k1 k2',real=True))
    H=s.Matrix(2,2,list(x[:4])); K=s.diag(x[4],x[5])
    p=I;dp=s.zeros(2);dq=s.zeros(2)
    for _ in range(3):
        dq+=dp*p.T+p*K*p.T+p*dp.T
        dp,p=dp*a+p*H,p*a
    qm=sum((amin**i*E*(amin**i).T for i in range(3)),s.zeros(2))
    g=s.Rational(4,3);c=s.Rational(21,16)
    frob=lambda m:s.trace(m.T*m)
    J=s.expand(g/(2*c)*frob(dp)+1/(4*c*c)*frob(dq-qm))
    Hess=s.hessian(J,x);grad=s.Matrix([s.diff(J,xi) for xi in x])
    solution=Hess.inv()*(-grad.subs(dict(zip(x,[0]*6))))
    expected=s.Matrix([-17*rt/720,-s.Rational(7,80),-s.Rational(7,80),17*rt/720,s.Rational(7,10),-s.Rational(7,10)])
    check=s.simplify(solution-expected)==s.zeros(6,1)
    assert check
    minval=s.simplify(J.subs(dict(zip(x,solution))));assert minval==s.Rational(13,3780)
    minors=[s.factor(Hess[:i,:i].det()) for i in range(1,7)]
    assert all(v>0 for v in minors)
    delta=x-solution
    assert s.simplify(J-minval-(delta.T*Hess*delta)[0]/2)==0
    # Compare independently derived Hessian to analytic Fisher implementation.
    from rotation_family import local_information
    fisher=local_information(A[0],np.eye(2),3)
    err=float(np.max(np.abs(np.array(Hess,dtype=float)-fisher)));assert err<1e-13
    return dict(variables=[str(i) for i in x],solution=[str(i) for i in solution],minimum=str(minval),
                hessian_leading_principal_minors=[str(v) for v in minors],
                completion_of_squares_verified=True,unique_minimizer=True,fisher_hessian_max_abs_error=err)


def pivot_checks():
    rng=np.random.default_rng(20260925);rows=[]
    # Check df, scale invariance, both anisotropy signs and isotropy across all branches.
    for n in (2,5,20,200):
        for branch in (0,1,2):
            for d in ([.1,3.],[1.,1.],[4.,.2]):
                q=coarsen(A[branch],np.diag(d))[1]
                N=40000;scatter=wishart(n,q,N,rng)
                u=U[branch]; ss=u.T@scatter@u
                rho=ss[:,0,1]/np.sqrt(ss[:,0,0]*ss[:,1,1])
                T=np.sqrt(n-1)*rho/np.sqrt(np.maximum(1-rho*rho,np.finfo(float).tiny))
                critical=student_t.ppf(.975,n-1)
                keep=correlation_keep(scatter,n)[:,branch]
                assert np.array_equal(keep,np.abs(T)<=critical)
                observed=float(keep.mean());se=np.sqrt(.95*.05/N)
                rows.append(dict(n=n,branch=branch,d1=d[0],d2=d[1],reps=N,
                                 retention=observed,z_from_nominal=(observed-.95)/se,
                                 empirical_q975=np.quantile(T,.975),theory_q975=critical))
    df=pd.DataFrame(rows);df.to_csv(BASE/'results'/'pivot_null_checks.csv',index=False)
    # No random p-value cutoffs are used as correctness assertions.
    # Direct raw-innovation vs scatter calculation checks indexing without Wishart generation.
    raw=rng.normal(size=(200,23,2))*np.array([1.7,.4]);sc=np.einsum('rni,rnj->rij',raw,raw)
    direct=(raw[:,:,0]*raw[:,:,1]).sum(axis=1)/np.sqrt((raw[:,:,0]**2).sum(axis=1)*(raw[:,:,1]**2).sum(axis=1))
    reconstructed=sc[:,0,1]/np.sqrt(sc[:,0,0]*sc[:,1,1]);assert np.allclose(direct,reconstructed,atol=1e-14)
    return dict(cells=len(rows),null_replications=len(rows)*N,max_abs_null_z=float(abs(df.z_from_nominal).max()),
                exact_statistic_decisions_verified=True,direct_vs_scatter_max_error=float(np.max(abs(direct-reconstructed))))


def record_checks():
    summary=pd.read_csv(BASE/'results'/'equal_information_summary.csv');maxerr=0.;count=0
    import re
    for folder,design in [('local_raw','local'),('fixed_raw','fixed')]:
        for path in sorted((BASE/'results'/folder).glob('evaluation_*.npz')):
            regime,nn,truth=re.match(r'evaluation_(.+)_n(\d+)_truth(\d+)\.npz',path.name).groups();n=int(nn);truth=int(truth)
            eps=.2 if design=='fixed' else (1/n if regime=='inverse_n' else int(regime.replace('local_c',''))/np.sqrt(n))
            with np.load(path) as z:
                rows,_,_=evaluate_record(z['training_scatter'],z['test_scatter'],truth,
                                        dict(design=design,regime=regime,n=n,epsilon=eps),z if design=='local' else None)
            for row in rows:
                saved=summary[(summary.design==design)&(summary.regime==regime)&(summary.n==n)&(summary.true_branch==truth)&(summary.method==row['method'])]
                assert len(saved)==1
                for key in row:
                    if key.endswith('_count'):assert int(saved[key].iloc[0])==row[key]
                    if key.endswith('_rate'):
                        maxerr=max(maxerr,abs(float(saved[key].iloc[0])-row[key]))
                count+=1
    assert maxerr<1e-14
    return dict(summary_rows_recalculated=count,max_abs_rate_error=maxerr)


def main():
    result=dict(symbolic_local_projection=symbolic_projection(),correlation_pivot=pivot_checks(),saved_decisions=record_checks())
    (BASE/'results'/'verification_candidate.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
