"""Audit the two main experiments against frozen reported summaries (NumPy only).

No generator or fitting module is imported. All 60,000 candidate likelihoods,
scores and Fisher standard errors are reconstructed from saved sufficient
statistics and structural parameters. A separate finite-difference audit checks
330 standard errors. No paths or optimization are rerun.
"""
from pathlib import Path
from statistics import NormalDist
import csv
import json
import platform
import time
import numpy as np

BASE = Path(__file__).resolve().parents[1]
Z975 = NormalDist().inv_cdf(.975)


def read_csv(path):
    with path.open(encoding='utf-8', newline='') as stream:
        return list(csv.DictReader(stream))


def rot(angle):
    return np.array([[np.cos(angle), -np.sin(angle)],
                     [np.sin(angle), np.cos(angle)]])


def observed(parameters):
    a = parameters[:, :4].reshape(-1, 2, 2)
    d = np.zeros_like(a)
    d[:, 0, 0], d[:, 1, 1] = parameters[:, 4], parameters[:, 5]
    identity = np.broadcast_to(np.eye(2), a.shape)
    powers = [identity, a, a @ a]
    b = powers[2] @ a
    q = sum(p @ d @ p.transpose(0, 2, 1) for p in powers)
    return a, d, powers, b, q


def stationary(a, d):
    kron = np.einsum('nij,nkl->nikjl', a, a).reshape(-1, 4, 4)
    return np.linalg.solve(np.eye(4) - kron, d.reshape(-1, 4, 1)).reshape(-1, 2, 2)


def tangent(parameters):
    a, d, powers, b, q = observed(parameters)
    db, dq = [], []
    for direction in np.eye(6):
        h = direction[:4].reshape(2, 2)
        dd = np.diag(direction[4:])
        dp = [np.zeros_like(a), np.broadcast_to(h, a.shape), a @ h + h @ a]
        db.append(h @ powers[2] + a @ h @ a + powers[2] @ h)
        dq.append(sum(dp[j] @ d @ powers[j].transpose(0, 2, 1)
                      + powers[j] @ dd @ powers[j].transpose(0, 2, 1)
                      + powers[j] @ d @ dp[j].transpose(0, 2, 1)
                      for j in range(3)))
    return db, dq


def fisher_standard_error(parameters, n, finite_difference=False):
    a, d, _, b, q = observed(parameters)
    gamma, qi = stationary(a, d), np.linalg.inv(q)
    if finite_difference:
        step = 2e-6
        pairs = [(observed(parameters + step * e),
                  observed(parameters - step * e)) for e in np.eye(6)]
        db = [(p[3] - m[3]) / (2*step) for p, m in pairs]
        dq = [(p[4] - m[4]) / (2*step) for p, m in pairs]
    else:
        db, dq = tangent(parameters)
    info = np.empty((len(parameters), 6, 6))
    for i in range(6):
        mean = qi @ db[i] @ gamma
        covariance = qi @ dq[i] @ qi
        for j in range(6):
            info[:, i, j] = np.sum(mean * db[j], axis=(1, 2)) + .5 * np.sum(covariance * dq[j], axis=(1, 2))
    assert np.linalg.eigvalsh(info).min() > 0
    return np.sqrt(np.linalg.inv(info)[:, 2, 2] / n)


def summary_index(rows):
    return {(r['regime'], int(r['n']), int(r['truth']), r['method']): r for r in rows}


def compare_summary(row, estimate, se, target):
    low, high = estimate - Z975*se, estimate + Z975*se
    covered = (low <= target) & (target <= high)
    wrong = (low > 0) if target < 0 else (high < 0)
    declared = (low > 0) | (high < 0)
    assert int(row.get('completed', row.get('valid'))) == len(estimate)
    assert int(row['failures']) == 0
    for name, event in [('coverage', covered), ('wrong', wrong), ('declare', declared)]:
        if name+'_count' in row:
            assert int(row[name+'_count']) == int(event.sum()), (row['method'], name)
            assert abs(float(row[name+'_rate']) - event.mean()) < 1e-12
    assert abs(float(row['median_width']) - np.median(high-low)) < 1e-10
    return covered


def main():
    started = time.perf_counter()
    reported = BASE / 'reported_results'
    original_main = summary_index(read_csv(reported / 'unknown_B_summary.csv'))
    original_grid = summary_index(read_csv(reported / 'grid_contrast/summary.csv'))
    original_nonrotation = summary_index(read_csv(reported / 'nonrotation_mc/summary.csv'))
    current_main = summary_index(read_csv(BASE / 'results/unknown_B_summary.csv'))
    current_grid = summary_index(read_csv(BASE / 'results/grid_contrast/summary.csv'))
    current_nonrotation = summary_index(read_csv(BASE / 'results/nonrotation_mc/summary.csv'))
    paired = {(r['source_file'], int(r['original_index'])): r
              for r in read_csv(BASE / 'results/grid_contrast/records.csv')}
    assert len(paired) == 18000
    roots = np.array([.5*rot(np.pi/6+2*np.pi*j/3) for j in range(3)])
    shear = np.array([[1., .2], [0., 1.]])
    sheared = shear @ roots @ np.linalg.inv(shear)
    maxima = dict(objective=0., score=0., standard_error=0., finite_difference_se=0.)
    counts = dict(paths=0, candidate_fits=0, finite_difference_fits=0,
                  reported_summary_rows=0, paired_path_rows=0)
    cells = []
    for folder, expected_files, nonrotation in [('unknown_B_raw', 18, False), ('nonrotation_mc/raw', 4, True)]:
        files = sorted((BASE / 'results' / folder).glob('*.npz'))
        assert len(files) == expected_files
        for path in files:
            with np.load(path, allow_pickle=False) as data:
                fit = data['fits']; n = int(data['n']); truth = int(data['truth']); regime = str(data['regime'])
                reps = len(fit); assert reps == (500 if nonrotation else 1000)
                s00, s10, s11 = [data[k] for k in ['s00', 's10', 's11']]
            assert fit.shape == (reps, 3, 11) and np.all(fit[:, :, 5] == 1)
            parameters = fit[:, :, [6, 7, 0, 8, 9, 10]].reshape(-1, 6)
            a, d, _, b, q = observed(parameters)
            assert np.max(abs(np.linalg.eigvals(a))) < 1 and np.min(parameters[:, 4:]) > 0
            nearest = np.linalg.norm(a[:, None] - (sheared if nonrotation else roots)[None], axis=(2, 3)).argmin(axis=1)
            assert np.array_equal(nearest, np.tile(np.arange(3), reps))
            xx, yx, yy = [np.repeat(s, 3, axis=0) for s in (s00, s10, s11)]
            residual = yy - b @ yx.transpose(0, 2, 1) - yx @ b.transpose(0, 2, 1) + b @ xx @ b.transpose(0, 2, 1)
            qi = np.linalg.inv(q)
            objective = .5*(np.linalg.slogdet(q)[1] + np.trace(qi @ residual, axis1=1, axis2=2))
            db, dq = tangent(parameters)
            bg = qi @ (b @ xx - yx)
            qg = .5*(qi - qi @ residual @ qi)
            gradient = np.column_stack([np.sum(bg*db[j] + qg*dq[j], axis=(1, 2)) for j in range(6)])
            gradient[:, 4:] *= parameters[:, 4:]
            score = np.max(abs(gradient), axis=1)
            assert score.max() < 1e-6
            se = fisher_standard_error(parameters, n)
            indices = np.array([3*i+j for i in (0, reps//5, 2*reps//5, 3*reps//5, 4*reps//5) for j in range(3)])
            fd_se = fisher_standard_error(parameters[indices], n, finite_difference=True)
            for key, error in [('objective', np.max(abs(objective-fit[:, :, 2].ravel()))),
                               ('score', np.max(abs(score-fit[:, :, 3].ravel()))),
                               ('standard_error', np.max(abs(se-fit[:, :, 1].ravel()))),
                               ('finite_difference_se', np.max(abs(fd_se-se[indices])))]:
                maxima[key] = max(maxima[key], float(error))
            chosen = objective.reshape(reps, 3).argmin(axis=1)
            assert np.array_equal(chosen, fit[:, :, 2].argmin(axis=1))
            coeff = np.linalg.solve(s00, s10.transpose(0, 2, 1)).transpose(0, 2, 1)
            qhat = s11 - coeff @ s10.transpose(0, 2, 1)
            grid_se = np.sqrt(qhat[:, 1, 1] * np.linalg.inv(s00)[:, 0, 0] / n)
            target = (sheared if nonrotation else roots)[truth, 1, 0]
            indices_rep = np.arange(reps)
            specs = [('selected', fit[indices_rep, chosen, 0], se.reshape(reps, 3)[indices_rep, chosen], target),
                     ('true_branch_oracle', fit[:, truth, 0], se.reshape(reps, 3)[:, truth], target),
                     ('on_grid', coeff[:, 1, 0], grid_se, .125)]
            for method, estimate, stderr, effect in specs:
                key = (regime, n, truth, method)
                if nonrotation:
                    indexes = [original_nonrotation, current_nonrotation]
                elif method == 'on_grid':
                    key = (regime, n, truth, 'ols_on_grid')
                    indexes = [original_grid, current_grid]
                else:
                    indexes = [original_main, current_main]
                for index in indexes:
                    compare_summary(index[key], estimate, stderr, effect)
                counts['reported_summary_rows'] += 1
                if not nonrotation and method != 'on_grid':
                    grid_method = {'selected':'selected_off_grid', 'true_branch_oracle':'oracle_off_grid'}[method]
                    for index in [original_grid, current_grid]:
                        compare_summary(index[(regime,n,truth,grid_method)], estimate, stderr, effect)
                    counts['reported_summary_rows'] += 1
                if not nonrotation:
                    prefix = {'selected':'selected_off_grid', 'true_branch_oracle':'oracle_off_grid', 'on_grid':'ols_on_grid'}[method]
                    for i in range(reps):
                        row = paired[path.name, i]
                        assert abs(float(row[prefix+'_estimate']) - estimate[i]) < 1e-10
                        assert abs(float(row[prefix+'_se']) - stderr[i]) < 1e-10
                        assert abs(float(row[prefix+'_lower']) - (estimate[i]-Z975*stderr[i])) < 1e-10
                        assert abs(float(row[prefix+'_upper']) - (estimate[i]+Z975*stderr[i])) < 1e-10
                        event = abs(estimate[i]-effect) <= Z975*stderr[i]
                        assert (row[prefix+'_covered'] == 'True') == bool(event)
                        assert int(row['selected_branch']) == int(chosen[i])
            counts['paths'] += reps; counts['candidate_fits'] += 3*reps
            counts['finite_difference_fits'] += len(indices)
            if not nonrotation: counts['paired_path_rows'] += reps
            cells.append(dict(experiment='nonrotation' if nonrotation else 'principal', regime=regime,n=n,truth=truth,paths=reps))
    assert counts['paths'] == 20000 and counts['candidate_fits'] == 60000
    assert counts['finite_difference_fits'] == 330
    assert counts['reported_summary_rows'] == 102
    assert maxima['objective'] < 1e-11 and maxima['score'] < 1e-10
    assert maxima['standard_error'] < 1e-9 and maxima['finite_difference_se'] < 1e-8
    report = dict(status='passed', counts=counts, max_absolute_errors=maxima,
                  elapsed_seconds=round(time.perf_counter()-started, 3),
                  environment=dict(python=platform.python_version(), numpy=np.__version__, os=platform.system(),machine=platform.machine()),
                  cells=cells,
                  scope='Saved-record audit against frozen reported summaries; no path regeneration, optimizer rerun, or global optimum certificate.')
    output = BASE / 'results/submission_audit/verification.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='cells'}, indent=2))


if __name__ == '__main__':
    main()
