"""Independent symbolic/numeric checks of the family results and fixed-root KL.

Assertions supplement the written proofs; they are not a formal proof system.
Run from any working directory: python code/verify_generalization.py
"""
from pathlib import Path
import json, time
import numpy as np
import sympy as sp
from scipy.linalg import solve_discrete_lyapunov
from scipy.optimize import minimize
from rotation_family import RotationFamily, coarsen, gaussian_kl, derivatives, local_information
BASE=Path(__file__).resolve().parents[1]

def main():
    checks={}; start=time.perf_counter()
    e=sp.symbols('e', real=True)
    rt=sp.sqrt(3)
    a0=sp.Matrix([[rt/4,-sp.Rational(1,4)],[sp.Rational(1,4),rt/4]])
    a2=sp.Matrix([[0,sp.Rational(1,2)],[-sp.Rational(1,2),0]])
    def q(a,t):
        d=sp.diag(1+t,1-t)
        return sp.simplify(sum((a**l*d*(a**l).T for l in range(3)),sp.zeros(2)))
    def gamma(a,t):
        b=a**3; qq=q(a,t)
        x,y,z=sp.symbols('x y z'); g=sp.Matrix([[x,y],[y,z]])
        sol=sp.solve(list(g-b*g*b.T-qq),(x,y,z))
        return sp.simplify(g.subs(sol))
    qs,qt=q(a2,e),q(a0,sp.Rational(7,10)*e)
    gs,gt=gamma(a2,e),gamma(a0,sp.Rational(7,10)*e)
    assert sp.simplify(sp.trace(qt.inv()*qs)-2)==0
    assert sp.simplify(sp.trace(gt.inv()*gs)-2)==0
    checks['fixed_root_trace_terms_equal_two']=True
    targetq=(1764-637*e**2)/(1764-676*e**2)
    targetg=(1300-441*e**2)/(1300-468*e**2)
    assert sp.simplify(qt.det()/qs.det()-targetq)==0
    assert sp.simplify(gt.det()/gs.det()-targetg)==0
    checks['fixed_root_exact_determinant_ratios']=True
    assert sp.simplify(sp.diff(sp.log(targetq)/2,e,2).subs(e,0)/2-sp.Rational(13,1176))==0
    assert sp.simplify(sp.diff(sp.log(targetg)/2,e,2).subs(e,0)/2-sp.Rational(27,2600))==0
    checks['fixed_root_quarter_coefficients']=True
    # A continuously varying radius at the original angles has beta=(2-r^2)/(2(1+r^2)).
    s=sp.symbols('s',positive=True)
    w2=1/(1+s); w0=1/(1-s*(sp.Rational(1,2)+sp.I*rt/2))
    beta=sp.simplify(sp.re(w2*sp.conjugate(w0))/(w0*sp.conjugate(w0)))
    assert sp.simplify(beta-(2-s)/(2*(1+s)))==0
    checks['radius_family_beta_formula']=True
    rng=np.random.default_rng(20260922)
    max_cov=0.; max_deriv=0.; max_det=0.; max_kl=0.; max_opt=0.
    min_information=1e9; cases=0; optcases=0
    for k in (3,5,7,9):
        for _ in range(25):
            while True:
                fam=RotationFamily(k,float(rng.uniform(.35,.85)),float(rng.uniform(-np.pi,np.pi)))
                if abs(np.sin(k*fam.theta))>.15 and fam.collinearity_margin()>1e-3: break
            roots=fam.roots; m,l=rng.choice(k,size=2,replace=False)
            eps=.05; b=fam.beta(int(m),int(l))
            for j in range(k):
                g,qq=fam.covariance(j,eps)
                bn,qn=coarsen(roots[j],np.diag([1+eps,1-eps]),k)
                gn=solve_discrete_lyapunov(roots[j],np.diag([1+eps,1-eps]))
                max_cov=max(max_cov,np.max(abs(bn-fam.B)),np.max(abs(qq-qn)),np.max(abs(g-gn)))
                db,dq=derivatives(roots[j],np.diag([1+eps,1-eps]),k)
                det=np.linalg.det(db[:4].reshape(4,4).T)
                max_det=max(max_det,abs(det-fam.power_derivative_determinant(j)))
                info=local_information(roots[j],np.eye(2),k)
                min_information=min(min_information,float(np.linalg.eigvalsh(info)[0]))
            # All competitors are permitted arbitrary diagonal variances, not just D_e.
            v=fam.multiplier*fam.w
            target=eps*np.array([v[m].real,v[m].imag])
            for j in range(k):
                if j==m: continue
                direction=np.array([v[j].real,v[j].imag])
                residual=target-direction*(target@direction)/(direction@direction)
                assert np.linalg.norm(residual)>1e-7
            # Test full structural derivatives in random directions.
            h=rng.normal(size=(2,2)); d=np.diag([1+eps,1-eps]); delta=1e-6
            bp,qp=coarsen(roots[m]+delta*h,d,k); bm,qm=coarsen(roots[m]-delta*h,d,k)
            db,dq=derivatives(roots[m],d,k)
            max_deriv=max(max_deriv,np.max(abs((bp-bm)/(2*delta)-np.einsum('i,ijk->jk',h.ravel(),db[:4]))),
                          np.max(abs((qp-qm)/(2*delta)-np.einsum('i,ijk->jk',h.ravel(),dq[:4]))))
            gs,qs=fam.covariance(int(m),eps); gt,qt=fam.covariance(int(l),b*eps)
            exact,kg,kq=fam.profile_kl(eps,137,int(m),int(l))
            direct=gaussian_kl(gs,gt)+137*gaussian_kl(qs,qt)
            max_kl=max(max_kl,abs(float(exact)-direct))
            # Independent optimization of the whole-path KL with unknown d1,d2.
            def objective(u):
                dd=np.diag(np.exp(u)); _,q1=coarsen(roots[l],dd,k)
                g1=solve_discrete_lyapunov(roots[l],dd)
                return gaussian_kl(gs,g1)+137*gaussian_kl(qs,q1)
            op=minimize(objective,np.zeros(2),method='BFGS',options={'gtol':1e-7})
            max_opt=max(max_opt,abs(op.fun-float(exact)))
            assert abs(op.fun-float(exact))<2e-7
            optcases+=1; cases+=1
    assert max_cov<1e-11 and max_deriv<2e-7 and max_det<1e-9
    assert max_kl<1e-9 and min_information>0
    checks.update(generic_families_checked=cases,independent_profile_optimizations=optcases,
                  k_values=[3,5,7,9],max_covariance_error=float(max_cov),
                  max_derivative_error=float(max_deriv),max_determinant_error=float(max_det),
                  max_exact_KL_error=float(max_kl),max_profile_optimization_gap=float(max_opt),
                  min_local_information_eigenvalue=float(min_information))
    # Even-k sign symmetry is exact for every real A, not just rotations.
    for k in (2,4,6,8):
        a=np.array([[.3,.2],[-.1,.4]]); d=np.diag([1.2,.8])
        b,q0=coarsen(a,d,k); b1,q1=coarsen(-a,d,k)
        assert np.array_equal(b,b1) and np.array_equal(q0,q1)
    checks['even_k_symmetry']=True
    checks['elapsed_seconds']=time.perf_counter()-start
    checks['status']='all assertions passed; numerical/symbolic checks, not formal verification'
    (BASE/'results'/'verification_generalization.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))

if __name__=='__main__': main()
