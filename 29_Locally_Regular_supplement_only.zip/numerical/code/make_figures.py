"""Regenerate six manuscript figures; one independent plot per figure.
No raw simulations are run. All colors are Matplotlib defaults.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from rotation_family import RotationFamily
BASE=Path(__file__).resolve().parents[1]

def save(name):
    plt.tight_layout()
    plt.savefig(BASE/'figures'/f'{name}.pdf',bbox_inches='tight')
    plt.savefig(BASE/'figures'/f'{name}.png',dpi=180,bbox_inches='tight')
    plt.close()


def main():
    plt.rcParams.update({'font.size':10,'pdf.fonttype':42})
    # Fixed-trace covariance geometry (exact computed data, not an illustration).
    f=RotationFamily();v=f.multiplier*f.w;eps=.35
    records=[]
    plt.figure(figsize=(6.9,3.2))
    for m,(z,ls) in enumerate(zip(v,['-','--',':'])):
        plt.plot([-z.real,z.real],[-z.imag,z.imag],linestyle=ls,marker='o',fillstyle='none',
                 label=f'Root {m}: '+r'$-1<t<1$')
        records.append(dict(branch=m,real_direction=z.real,imag_direction=z.imag))
    source=eps*v[2];proj=f.beta(2,0)*eps*v[0]
    plt.plot([source.real,proj.real],[source.imag,proj.imag],linestyle='-.',linewidth=1.3,label='Fixed-root projection')
    plt.scatter([0,source.real,proj.real],[0,source.imag,proj.imag],s=32)
    plt.annotate('Isotropic law',(0,0),xytext=(-.62,-.15),arrowprops={'arrowstyle':'->'},fontsize=9)
    plt.annotate(r'Source: $t=.35$',(source.real,source.imag),xytext=(.55,-.13),arrowprops={'arrowstyle':'->'},fontsize=9)
    plt.annotate(r'Projection: $t=.245$',(proj.real,proj.imag),xytext=(.34,.22),arrowprops={'arrowstyle':'->'},fontsize=9)
    plt.xlabel(r'Anisotropy $\mathrm{Re}(z)=(Q_{11}-Q_{22})/2$')
    plt.ylabel(r'$\mathrm{Im}(z)=Q_{12}$')
    plt.title(r'Fixed-trace section: $Q=(21/16)I+T(z)$')
    plt.ylim(-.35,.35);plt.xlim(-1.2,1.2)
    plt.legend(fontsize=8,loc='upper left')
    save('covariance_geometry')
    pd.DataFrame(records).to_csv(BASE/'results'/'geometry_coordinates.csv',index=False)
    # Original branch effects, kept as a companion diagnostic.
    h=pd.read_csv(BASE/'results'/'branch_horizons.csv');h=h[h.h<=6]
    plt.figure(figsize=(6.9,3.6))
    for m,ls,mk in zip(range(3),['-','--',':'],['o','s','^']):
        plt.plot(h.h,h[f'branch{m}'],linestyle=ls,marker=mk,label=f'Root {m}')
    plt.xlabel('Horizon h in system steps');plt.ylabel('Pulse effect from variable 1 to 2')
    plt.xticks(h.h);plt.title('Same observed law, different off-grid effects (k = 3)');plt.legend()
    save('branch_effects')
    inf=pd.read_csv(BASE/'results'/'local_global_information.csv');pos=inf[inf.epsilon>0]
    plt.figure(figsize=(6.9,3.6))
    for col,label,ls in [('minimum_information_negative','Minimum information: negative branch','-'),
                         ('minimum_information_positive','Minimum information: positive branch','--'),
                         ('nearest_transition_KL','Variance-profiled fixed-root KL',':')]:
        plt.loglog(pos.epsilon,pos[col]/pos[col].iloc[-1],linestyle=ls,label=label)
    plt.xlabel(r'Anisotropy $\epsilon$');plt.ylabel(r'Value / its value at $\epsilon=0.5$')
    plt.title('Local information and separation between fixed roots');plt.legend(fontsize=9)
    save('local_global_information')
    summ=pd.read_csv(BASE/'results'/'equal_information_summary.csv');neg=summ[summ.true_branch==2]
    plt.figure(figsize=(6.9,3.6))
    for method,label,ls,mk in [('split_three_branch','Split','-','o'),('correlation_full','Correlation: all innovations','--','s'),
                               ('correlation_test_half','Correlation: test half',':','^')]:
        q=neg[(neg.design=='fixed')&(neg.method==method)].sort_values('n')
        correct=(q.sign_declared_count-q.wrong_sign_count).to_numpy()/q.reps.to_numpy()
        # Exact Wilson intervals for the unconditional correct-declaration event.
        from local_sequence_experiments import wilson
        ci=np.array([wilson(int(d-w),int(nn)) for d,w,nn in zip(q.sign_declared_count,q.wrong_sign_count,q.reps)])
        plt.errorbar(q.n,correct,yerr=np.stack([correct-ci[:,0],ci[:,1]-correct]),marker=mk,linestyle=ls,capsize=3,label=label)
    plt.xscale('log');plt.ylim(-.025,1.025)
    plt.xlabel('Number of observed transitions n');plt.ylabel('Probability of correct sign declaration')
    plt.title(r'Fixed model: $\epsilon=0.2$, known B and unknown D');plt.legend(fontsize=9)
    save('fixed_parameter_control')
    plt.figure(figsize=(6.9,3.6))
    for regime,eq,mk in [('inverse_n',r'1/n','o'),('local_c12',r'12/\sqrt{n}','s')]:
        for method,label,ls in [('split_three_branch','Split','-'),('correlation_full','Corr: all','--'),('correlation_test_half','Corr: half',':')]:
            q=neg[(neg.regime==regime)&(neg.method==method)].sort_values('n')
            plt.semilogx(q.n,q.both_signs_rate,marker=mk,linestyle=ls,label=label+r', $\epsilon='+eq+'$')
    plt.ylim(.86,1.01);plt.xlabel('Number of observed transitions n')
    plt.ylabel('Probability of retaining both signs');plt.title('Matched information on local sequences')
    plt.legend(fontsize=8,ncol=2,loc='lower left');save('matched_local_sequences')
    err=pd.read_csv(BASE/'results'/'balanced_LR_errors.csv')
    plt.figure(figsize=(6.9,3.6))
    for regime,eq in [('inverse_n','1/n'),('local_c1','1/\\sqrt{n}'),('local_c4','4/\\sqrt{n}'),('local_c12','12/\\sqrt{n}')]:
        q=err[err.regime==regime].sort_values('n')
        plt.errorbar(q.n,q.balanced_error,yerr=1.95996398454*q.mc_se,marker='o',capsize=3,
                     label=r'$\epsilon='+eq+'$'+f' (limit {q.analytical_limit.iloc[0]:.3f})')
    plt.xscale('log');plt.axhline(.5,linestyle=':',linewidth=.8);plt.ylim(.13,.535)
    plt.xlabel('Number of observed transitions n');plt.ylabel('Optimal equal-prior error')
    plt.title('Fully specified two-law discrimination on local sequences');plt.legend(fontsize=9,loc='center right')
    save('optimal_error_local_sequences')
    print('Regenerated six figures from saved summaries and exact geometry.')
if __name__=='__main__':main()
