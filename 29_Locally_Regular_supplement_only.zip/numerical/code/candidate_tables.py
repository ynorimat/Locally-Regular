"""Generate candidate-manuscript tables from recorded evaluation summaries."""
from pathlib import Path
import pandas as pd
BASE=Path(__file__).resolve().parents[1]
METHODS={'split_three_branch':'Split','correlation_full':'Corr (all)','correlation_test_half':'Corr (half)','calibrated_two_simple':'Two-simple'}

def rates(row,keys):return ' & '.join(f'{100*row[k+"_rate"]:.2f}' for k in keys)

def main():
    df=pd.read_csv(BASE/'results'/'equal_information_summary.csv'); neg=df[df.true_branch==2]
    cols=['effect_covered','both_signs','sign_declared','wrong_sign','empty']
    text=r'''\begin{table}[htbp]
\centering\small
\caption{Matched-information inference under the negative source: known $B$, unknown positive diagonal $D$, and the same three roots. Each row has 10,000 evaluations on paired sufficient statistics. All numerical entries except $n$ are percentages. Coverage is effect coverage; Both means both signs are retained; Declare means a nonempty set with exactly one sign; Wrong/all is an erroneous declaration divided by \emph{all} replications, not declarations; Empty means no candidate remains.}
\label{tab:matched}
\setlength{\tabcolsep}{3.5pt}
\begin{tabular}{llrrrrrr}
\toprule
Design & Method & $n$ & Coverage & Both & Declare & Wrong/all & Empty\\
\midrule
'''
    settings=[('local','inverse_n',32000,r'$\varepsilon=1/n$'),('local','local_c12',32000,r'$\varepsilon=12/\sqrt n$'),('fixed','fixed_e02',8000,r'$\varepsilon=.2$'),('fixed','fixed_e02',32000,r'$\varepsilon=.2$')]
    for ii,(design,regime,n,label) in enumerate(settings):
        for method in ['split_three_branch','correlation_full','correlation_test_half']:
            row=neg[(neg.design==design)&(neg.regime==regime)&(neg.n==n)&(neg.method==method)].iloc[0]
            text+=f'{label} & {METHODS[method]} & {n} & '+rates(row,cols)+r' \\'+'\n'
        if ii<len(settings)-1:text+=r'\addlinespace'+'\n'
    text+=r'\bottomrule\end{tabular}\end{table}'+'\n'
    (BASE/'results'/'matched_information_table.tex').write_text(text)
    text=r'''\begin{table}[htbp]
\centering\small
\caption{Fully specified two-law benchmark, negative source, $n=32000$, 10,000 evaluations per row. This oracle has additional variance information and is not matched to the three-branch procedures. Wrong/all has all replications as its denominator. Wrong/declare instead conditions on declaration; declaration and wrong-declaration counts are retained in the CSV. Monte Carlo intervals are conditional on saved calibration draws.}
\label{tab:two_simple}
\setlength{\tabcolsep}{3.5pt}
\begin{tabular}{lrrrrrr}
\toprule
$\varepsilon_n$ & Coverage & Both & Declare & Wrong/all & Empty & Wrong/declare\\
\midrule
'''
    for regime,label in [('inverse_n',r'$1/n$'),('local_c1',r'$1/\sqrt n$'),('local_c4',r'$4/\sqrt n$'),('local_c12',r'$12/\sqrt n$')]:
        row=neg[(neg.regime==regime)&(neg.n==32000)&(neg.method=='calibrated_two_simple')].iloc[0]
        text+=label+' & '+rates(row,cols)+f' & {100*row.wrong_given_declared:.2f}'+r' \\'+'\n'
    text+=r'\bottomrule\end{tabular}\end{table}'+'\n'
    (BASE/'results'/'two_simple_diagnostics_table.tex').write_text(text)
    # Small conditional-error table makes the non-selection guarantee transparent.
    text=r'''\begin{table}[htbp]\centering\small
\caption{Conditional sign errors for selected matched-information diagnostics under the negative source. Counts show why unconditional 95\% coverage is not a selective sign guarantee. Wrong/declare is undefined when no declaration occurs.}
\label{tab:conditional}
\begin{tabular}{llrrrr}
\toprule Design & Method & $n$ & Declare count & Wrong count & Wrong/declare (\%)\\\midrule
'''
    for design,regime,n,label in settings:
        for method in ['split_three_branch','correlation_full']:
            row=neg[(neg.design==design)&(neg.regime==regime)&(neg.n==n)&(neg.method==method)].iloc[0]
            frac='--' if pd.isna(row.wrong_given_declared) else f'{100*row.wrong_given_declared:.2f}'
            text+=label+' & '+METHODS[method]+f' & {n} & {int(row.sign_declared_count)} & {int(row.wrong_sign_count)} & '+frac+r' \\'+'\n'
    text+=r'\bottomrule\end{tabular}\end{table}'+'\n'
    (BASE/'results'/'conditional_sign_table.tex').write_text(text)
    print('Wrote three explicitly defined manuscript tables.')
if __name__=='__main__':main()
