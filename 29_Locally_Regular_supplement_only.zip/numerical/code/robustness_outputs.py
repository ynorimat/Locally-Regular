"""Generate all robustness text, table and plot from saved robustness records."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullLocator
BASE=Path(__file__).resolve().parents[1]


def main():
    out=BASE/'results/robustness';audit=json.loads((out/'audit_summary.json').read_text())
    df=pd.read_csv(out/'sensitivity_summary.csv')
    assert len(df)==48
    text=(f'All {audit["extra_BFGS_fits"]+audit["alternate_fits"]:,} additional fits met the acceptance criteria. '
          f'The largest total log-likelihood improvement was ${audit["max_loglik_improvement"]:.2g}$, '
          f'and the largest change to either selected interval endpoint was ${audit["max_endpoint_change"]:.2g}$. '
          f'There were {audit["changed_branch_count"]} changes in the selected branch, '
          f'{audit["changed_coverage_count"]} changes in effect coverage, and '
          f'{audit["changed_wrong_sign_count"]} changes in wrong-sign declaration across the 360 audited paths. '
          f'The alternate optimizer alone changed {audit["alternate_changed_coverage_count"]} coverage decisions and '
          f'{audit["alternate_changed_wrong_sign_count"]} wrong-sign decisions. '
          'The observed failures of local-Wald coverage therefore persist in this audit when the initializations and optimizer are changed. '
          'The finite audit is not a certificate of a global optimum.\n')
    # Scientific notation in LaTeX must be explicitly typeset, not e-notation in math mode.
    for value in (audit['max_loglik_improvement'],audit['max_endpoint_change']):
        raw=f'{value:.2g}';mant,exp=raw.split('e');text=text.replace('$'+raw+'$',f'${mant}\\times10^{{{int(exp)}}}$')
    assert audit['failed_jitter_fits']==0 and audit['failed_alternate_fits']==0
    (out/'audit_text.tex').write_text(text)
    neg=df[(df.target<0)&(df.regime=='inverse_n')&(df.n==32000)]
    sel=neg[neg.method=='selected'];ora=neg[neg.method=='true_branch_oracle']
    completed=df[df.method=='selected'].completed.sum();attempted=df[df.method=='selected'].attempted.sum()
    failed=attempted-completed
    text2=(f'All {attempted:,} paths were attempted; {completed:,} yielded a complete set of accepted candidate fits, '
           f'with {failed} failed paths. Across the three negative-source settings at $n=32000$ and $\\varepsilon=1/n$, '
           f'selected coverage ranges from {100*sel.coverage_rate.min():.1f} to {100*sel.coverage_rate.max():.1f}'+r'\%, '
           f'whereas true-branch coverage ranges from {100*ora.coverage_rate.min():.1f} to {100*ora.coverage_rate.max():.1f}'+r'\%. '
           'The table retains both signs, both sample sizes, and the fixed-perturbation controls. '
           'These are sensitivity checks within the theorem\'s rotation family; broader model coverage is not inferred from them.\n')
    (out/'sensitivity_text.tex').write_text(text2)
    maintext=(r'\paragraph{Optimizer and setting sensitivity.}'+'\n'
          r'On a stratified sample of 360 existing paths, 4,320 perturbed-start BFGS fits and 1,080 L-BFGS-B fits left the selected branch, coverage, and wrong-sign decisions unchanged. '
          r'The largest improvement in total log likelihood was below $10^{-8}$. '
          r'We also simulated 12,000 paths in three additional settings varying the contraction, angle, and sampling interval ($k=3,5$). '
          f'For negative sources at $n=32000$ and $\\varepsilon=1/n$, selected coverage was {100*sel.coverage_rate.min():.1f}--{100*sel.coverage_rate.max():.1f}'+r'\%, '
          f'versus {100*ora.coverage_rate.min():.1f}--{100*ora.coverage_rate.max():.1f}'+r'\% on the true branch. '
          r'Appendix~\ref{app:robustness} reports all settings and both signs. This supports the phenomenon within the stated family without certifying global optimization or a broader VAR result.'+'\n')
    assert audit['changed_branch_count']==audit['changed_coverage_count']==audit['changed_wrong_sign_count']==0
    assert audit['max_loglik_improvement']<1e-8
    (out/'main_text.tex').write_text(maintext)
    rows=[r'\begin{table}[!ht]',r'\centering\small',
          r'\caption{Sensitivity results: 500 attempted paths per row. Coverage and wrong-sign declarations are percentages; width is the median selected interval width. Complete failure counts and Wilson intervals are in the accompanying CSV. $-$ and $+$ identify the negative source and positive competitor.}',
          r'\label{tab:robustness}',r'\begin{tabular}{llrrrrrr}',r'\toprule',
          r'Setting & $\varepsilon$ & Sign & $n$ & Selected & Oracle & Wrong/all & Width\\',r'\midrule']
    for setting,name in [('radius','Radius'),('angle','Angle'),('sampling','Sampling')]:
        for regime,regname in [('inverse_n',r'$1/n$'),('fixed_e02',r'$.2$')]:
            for sign in [-1,1]:
                for n in [8000,32000]:
                    sub=df[(df.setting==setting)&(df.regime==regime)&(df.n==n)&(np.sign(df.target)==sign)]
                    s=sub[sub.method=='selected'].iloc[0];o=sub[sub.method=='true_branch_oracle'].iloc[0]
                    rows.append(f'{name} & {regname} & '+('$-$' if sign<0 else '$+$')+f' & {n} & {100*s.coverage_rate:.1f} & {100*o.coverage_rate:.1f} & {100*s.wrong_rate:.1f} & {s.median_width:.3f} '+r'\\')
        rows.append(r'\addlinespace')
    rows.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}'])
    (out/'sensitivity_table.tex').write_text('\n'.join(rows)+'\n')
    plt.rcParams.update({'font.family':'serif','font.size':9,'pdf.fonttype':42,'ps.fonttype':42})
    fig,axes=plt.subplots(1,3,figsize=(7,2.7),sharey=True)
    for ax,setting,title in zip(axes,['radius','angle','sampling'],[r'Radius: $k=3$, $r=.7$',r'Angle: $k=3$, $\theta=\pi/5$',r'Sampling: $k=5$, $r=.7$']):
        for regime,color in [('inverse_n','#28649d'),('fixed_e02','#b35523')]:
            for method,style in [('selected','-'),('true_branch_oracle','--')]:
                d=df[(df.setting==setting)&(df.target<0)&(df.regime==regime)&(df.method==method)].sort_values('n')
                label=('Selected' if method=='selected' else 'True-branch oracle')+', '+('$1/n$' if regime=='inverse_n' else '$\\varepsilon=.2$')
                ax.errorbar(d.n,d.coverage_rate,yerr=np.array([d.coverage_rate-d.coverage_lo,d.coverage_hi-d.coverage_rate]),
                            color=color,linestyle=style,marker='o',markersize=3,capsize=2,label=label)
        ax.axhline(.95,color='.4',linestyle=':',linewidth=1);ax.set_title(title,fontsize=9)
        ax.set_xscale('log');ax.set_xticks([8000,32000],['8,000','32,000']);ax.set_ylim(0,1.04)
        ax.xaxis.set_minor_locator(NullLocator())
        ax.set_xlabel('Observed transitions');ax.grid(alpha=.15)
    axes[0].set_ylabel('Effect coverage')
    handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=2,frameon=False,fontsize=8)
    fig.tight_layout(rect=(0,.20,1,1),pad=.6)
    fig.savefig(BASE/'figures/robustness_sensitivity.pdf');fig.savefig(BASE/'figures/robustness_sensitivity.png',dpi=180);plt.close(fig)
    print(text);print(text2)


if __name__=='__main__':main()
