"""branch and distance: deterministic diagnostics from existing fits and specified population laws.

No simulation or refitting is performed. Frequencies use all completed paths in
each original cell. Likelihood gaps refer to the attained conditional fits.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import norm
from rotation_family import RotationFamily, local_information

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'results/branch_diagnostics'


def branch_diagnostics():
    fam = RotationFamily()
    records, cells, branches = [], [], []
    largest_departure = 0.
    label_mismatches = 0
    for path in sorted((BASE/'results/unknown_B_raw').glob('*.npz')):
        with np.load(path) as z:
            fit = z['fits']; n = int(z['n']); truth = int(z['truth'])
            regime = str(z['regime']); epsilon = float(z['epsilon'])
        complete = np.all(fit[:, :, 5] == 1, axis=1)
        ix = np.flatnonzero(complete); f = fit[complete]; size = len(f)
        chosen = np.argmin(f[:, :, 2], axis=1)
        sorted_f = np.sort(f[:, :, 2], axis=1)
        gaps = n*(sorted_f[:, 1]-sorted_f[:, 0])
        aa = np.empty((size, 3, 2, 2))
        aa[:, :, 0, 0] = f[:, :, 6]; aa[:, :, 0, 1] = f[:, :, 7]
        aa[:, :, 1, 0] = f[:, :, 0]; aa[:, :, 1, 1] = f[:, :, 8]
        distances = np.linalg.norm(aa[:, :, None]-fam.roots[None, None], axis=(3, 4))
        nearest = distances.argmin(axis=2)
        label_mismatches += int(np.count_nonzero(nearest != np.arange(3)))
        largest_departure = max(largest_departure, float(distances.min(axis=2).max()))
        widths = 2*norm.ppf(.975)*f[:, :, 1]
        target = fam.roots[truth, 1, 0]
        common = dict(regime=regime, n=n, epsilon=epsilon, truth=truth,
                      attempted=len(fit), completed=size, failures=len(fit)-size)
        cell = dict(common, gap_q25=float(np.quantile(gaps, .25)),
                    gap_median=float(np.median(gaps)), gap_q75=float(np.quantile(gaps, .75)),
                    gap_max=float(gaps.max()), gap_le_1_count=int((gaps <= 1).sum()))
        for b in range(3):
            count = int((chosen == b).sum())
            cell[f'branch{b}_count'] = count
            cell[f'branch{b}_rate'] = count/size
            cell[f'branch{b}_width'] = float(np.median(widths[:, b]))
            branches.append(dict(common, fitted_branch=b, selected_count=count,
                                 selected_rate=count/size,
                                 median_width=float(np.median(widths[:, b]))))
        cells.append(cell)
        for j, original_index in enumerate(ix):
            pick = f[j, chosen[j]]
            low, high = pick[0]-norm.ppf(.975)*pick[1], pick[0]+norm.ppf(.975)*pick[1]
            records.append(dict(regime=regime, n=n, truth=truth, original_index=int(original_index),
                                selected_branch=int(chosen[j]), loglik_gap=float(gaps[j]),
                                selected_width=float(high-low), covered=bool(low <= target <= high)))
    assert label_mismatches == 0
    df = pd.DataFrame(cells)
    df.to_csv(OUT/'branch_cells.csv', index=False)
    pd.DataFrame(branches).to_csv(OUT/'branch_widths.csv', index=False)
    pd.DataFrame(records).to_csv(OUT/'branch_records.csv', index=False)
    rows = [r'\begin{table}[htbp]', r'\centering\small',
            r'\caption{Selection among the three attained local fits at $n=32000$. Every row has 1,000 completed paths. Branch columns are selection percentages; $\Delta\ell$ is the median total conditional log-likelihood gap between the best and second-best fits. Branches 0 and 1 share effect $1/4$, whereas branch 2 has effect $-1/2$. These gaps are descriptive, with no test calibration.}',
            r'\label{tab:branch_selection}', r'\begin{tabular}{llrrrr}', r'\toprule',
            r'$\varepsilon$ & True branch & Select 0 & Select 1 & Select 2 & $\Delta\ell$ \\', r'\midrule']
    names = {'inverse_n':r'$1/n$', 'local_c4':r'$4/\sqrt n$', 'fixed_e02':r'$.2$'}
    for regime, name in names.items():
        for truth in (0, 2):
            s = df[(df.regime == regime)&(df.n == 32000)&(df.truth == truth)].iloc[0]
            rows.append(f'{name} & {truth} & {100*s.branch0_rate:.1f} & {100*s.branch1_rate:.1f} & {100*s.branch2_rate:.1f} & {s.gap_median:.3f} '+r'\\')
        rows.append(r'\addlinespace')
    rows.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}'])
    (OUT/'branch_selection_table.tex').write_text('\n'.join(rows)+'\n')
    s = df[(df.regime=='inverse_n')&(df.n==32000)&(df.truth==2)].iloc[0]
    widths_limit = [float(2*norm.ppf(.975)*np.sqrt(np.linalg.inv(local_information(a,np.eye(2),3))[2,2]/32000)) for a in fam.roots]
    (OUT/'branch_interpretation.tex').write_text(
        r'\paragraph{Branch multiplicity and local width.}'+'\n'+
        r'The positive effect $1/4$ is shared by branches 0 and 1; only branch 2 has effect $-1/2$. '
        r'Effect coverage therefore differs from recovery of the generating branch. At $n=32000$ and $\varepsilon=1/n$, '
        f'the negative-source fits select these branches in {100*s.branch0_rate:.1f}'+r'\%, '+
        f'{100*s.branch1_rate:.1f}'+r'\%, and '+f'{100*s.branch2_rate:.1f}'+r'\% of paths. '
        r'The limiting local Wald widths at this $n$ are approximately $.0288$ on either positive branch and $.0648$ on the negative branch. '
        rf'The median best-versus-second-best log-likelihood gap is ${s.gap_median:.3f}$. '
        r'The selected width reflects both sample size and which branch is selected. Appendix Table~\ref{tab:branch_selection} reports selection frequencies and attained likelihood gaps; branch-specific widths for all cells accompany it.'+'\n')
    rows = [r'\begin{table}[htbp]', r'\centering\small',
            r'\caption{Median local interval widths on each fitted branch at $n=32000$, $\varepsilon=1/n$. Each empirical median uses all 1,000 completed paths, without conditioning on selection. The last row uses population Fisher information at isotropic innovations.}',
            r'\label{tab:branch_width}', r'\begin{tabular}{lrrr}',r'\toprule',
            r'Data-generating law & Fit 0 & Fit 1 & Fit 2 \\',r'\midrule']
    for truth in (0,2):
        s = df[(df.regime=='inverse_n')&(df.n==32000)&(df.truth==truth)].iloc[0]
        rows.append(f'True branch {truth} & {s.branch0_width:.4f} & {s.branch1_width:.4f} & {s.branch2_width:.4f} '+r'\\')
    rows.append('Isotropic information & '+' & '.join(f'{v:.4f}' for v in widths_limit)+r'\\')
    rows.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}'])
    (OUT/'branch_width_table.tex').write_text('\n'.join(rows)+'\n')
    return dict(paths=len(records), candidate_fits=3*len(records), cells=len(cells),
                nearest_root_label_mismatches=label_mismatches,
                maximum_distance_to_assigned_population_root=largest_departure,
                isotropic_widths_n32000=widths_limit)


def distances():
    settings=[('Base',3,.5,np.pi/6,2,0),('Radius',3,.7,np.pi/6,2,0),
              ('Angle',3,.5,np.pi/5,2,0),('Sampling',5,.7,np.pi/10,3,0)]
    records=[]
    for name,k,r,theta,m,l in settings:
        family=RotationFamily(k,r,theta)
        for n in (8000,32000):
            for regime,eps in [('inverse_n',1/n),('fixed_e02',.2)]:
                total,initial,transition=family.profile_kl(eps,n,m,l)
                effect_gap=abs(family.roots[m,1,0]-family.roots[l,1,0])
                records.append(dict(setting=name,k=k,r=r,theta=theta,source=m,competitor=l,n=n,
                                    regime=regime,epsilon=eps,beta=family.beta(m,l),
                                    exact_path_KL=float(total),initial_KL=float(initial),
                                    per_transition_KL=float(transition),effect_gap=effect_gap,
                                    diameter_lower_probability=max(0.,.9-np.sqrt(total/2))))
    df=pd.DataFrame(records);df.to_csv(OUT/'setting_distances.csv',index=False)
    from finite_sample_bounds import export_table
    export_table(OUT)
    s=df[(df.setting=='Sampling')&(df.n==32000)&(df.regime=='fixed_e02')].iloc[0]
    (OUT/'distance_interpretation.tex').write_text(
        r'\paragraph{Distance explains the slow fixed-model control.}'+'\n'+
        r'For the $k=5$ setting in Appendix~\ref{app:robustness}, $n=32000$ and $\varepsilon=.2$ still give '
        rf'$K^\star_{{30,n}}={s.exact_path_KL:.3f}$ between the designated opposite-sign laws. '
        rf'Their effect gap is ${s.effect_gap:.4f}$. A set with 95\% coverage under both laws must have at least this diameter with probability at least ${s.diameter_lower_probability:.4f}$ under the negative law. '
        r'Thus fixed nonzero anisotropy need not make these sample sizes informative. This population-distance calculation explains persistent ambiguity, without predicting the coverage of the selected Wald procedure. Table~\ref{tab:setting_distances} compares all settings.'+'\n')
    return dict(distance_rows=len(df),sampling_fixed_KL=float(s.exact_path_KL),
                sampling_fixed_diameter_bound=float(s.diameter_lower_probability))


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    result=branch_diagnostics();result.update(distances())
    result['scope']='Deterministic reanalysis of saved fits; no new simulation or optimizer run.'
    (OUT/'diagnostic_metadata.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__': main()
