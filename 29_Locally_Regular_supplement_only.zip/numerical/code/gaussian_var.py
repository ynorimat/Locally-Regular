"""NumPy-only batched observed laws and full Fisher information for fixed k.

Coordinates are (A11,A12,A21,A22,d1,d2), with variances on their original scale.
This extends the independent k=3 audit formulas without importing a simulator
or optimizer. It does not certify likelihood convergence or uniform asymptotics.
"""
import numpy as np


def observed(parameters, k=3):
    if not isinstance(k, (int, np.integer)) or k < 1:
        raise ValueError('k must be a positive integer')
    p = np.asarray(parameters, dtype=float)
    if p.ndim != 2 or p.shape[1] != 6:
        raise ValueError('Expected a batch of six-coordinate structural parameters')
    a = p[:, :4].reshape(-1, 2, 2)
    d = np.zeros_like(a)
    d[:, 0, 0], d[:, 1, 1] = p[:, 4], p[:, 5]
    powers = [np.broadcast_to(np.eye(2), a.shape)]
    for _ in range(k):
        powers.append(powers[-1] @ a)
    q = sum(v @ d @ v.transpose(0, 2, 1) for v in powers[:-1])
    return a, d, powers[:-1], powers[-1], q


def stationary(a, d):
    kron = np.einsum('nij,nkl->nikjl', a, a).reshape(-1, 4, 4)
    return np.linalg.solve(np.eye(4)-kron, d.reshape(-1, 4, 1)).reshape(-1, 2, 2)


def tangent(parameters, k=3):
    a, d, powers, _, _ = observed(parameters, k)
    db, dq = [], []
    for direction in np.eye(6):
        h = direction[:4].reshape(2, 2)
        dd = np.diag(direction[4:])
        dp = np.zeros_like(a)
        qprime = np.zeros_like(a)
        for p in powers:
            qprime += (dp @ d @ p.transpose(0, 2, 1)
                       + p @ dd @ p.transpose(0, 2, 1)
                       + p @ d @ dp.transpose(0, 2, 1))
            dp = dp @ a + p @ h
        db.append(dp)
        dq.append(qprime)
    return db, dq


def fisher_standard_error(parameters, n, k=3, finite_difference=False):
    a, d, _, _, q = observed(parameters, k)
    gamma, qi = stationary(a, d), np.linalg.inv(q)
    if finite_difference:
        step = 2e-6
        pairs = [(observed(parameters+step*e, k), observed(parameters-step*e, k))
                 for e in np.eye(6)]
        db = [(p[3]-m[3])/(2*step) for p, m in pairs]
        dq = [(p[4]-m[4])/(2*step) for p, m in pairs]
    else:
        db, dq = tangent(parameters, k)
    info = np.empty((len(parameters), 6, 6))
    for i in range(6):
        mean = qi @ db[i] @ gamma
        covariance = qi @ dq[i] @ qi
        for j in range(6):
            info[:, i, j] = (np.sum(mean*db[j], axis=(1, 2))
                            + .5*np.sum(covariance*dq[j], axis=(1, 2)))
    if np.linalg.eigvalsh(info).min() <= 0:
        raise ValueError('Nonpositive structural information')
    return np.sqrt(np.linalg.inv(info)[:, 2, 2]/n)
