"""Deterministic checks supporting the varying-transition corollary.

Uses NumPy only. Finite checks do not prove uniformity, certify a neighborhood
radius, simulate empirical paths, or rerun structural optimizers.
The proof is in Appendix B.2 of the companion manuscript.
"""
from fractions import Fraction
from pathlib import Path
import json
import numpy as np

BASE = Path(__file__).resolve().parents[1]


def lyapunov(matrix, covariance):
    return np.linalg.solve(np.eye(4) - np.kron(matrix, matrix),
                           covariance.ravel()).reshape(2, 2)


def roots_at(matrix):
    # Independent of the proof's eigenvector construction.
    u = np.trace(matrix) / 2
    v = np.sqrt(np.linalg.det(matrix) - u*u)
    j = (matrix - u*np.eye(2)) / v
    angle = np.arctan2(v, u)
    radius = np.hypot(u, v)**(1/3)
    return [radius*(np.cos((angle+2*np.pi*m)/3)*np.eye(2)
                    + np.sin((angle+2*np.pi*m)/3)*j) for m in range(3)]


def gradient(matrix, horizon):
    result = np.zeros((2, 2))
    for row in range(2):
        for column in range(2):
            direction = np.zeros((2, 2)); direction[row, column] = 1
            result[row, column] = sum(
                (np.linalg.matrix_power(matrix, u) @ direction
                 @ np.linalg.matrix_power(matrix, horizon-1-u))[1, 0]
                for u in range(horizon))
    return result


def stationary_pair(matrix):
    roots = roots_at(matrix)
    basis = [np.array([[1., 0], [0, 0]]),
             np.array([[0., 1], [1, 0]]),
             np.array([[0., 0], [0, 1]])]
    mapping = np.array([[np.trace(h) for h in basis]] +
                       [[(h-roots[j]@h@roots[j].T)[0, 1]
                         for h in basis] for j in (0, 2)])
    gamma = sum(x*h for x, h in zip(np.linalg.solve(mapping, [8/3, 0, 0]), basis))
    return roots, gamma


def main():
    b0 = np.array([[1/40, -13/100], [1/8, -1/40]])
    exact_norm = sum(x*x for x in [Fraction(1, 40), -Fraction(13, 100),
                                   Fraction(1, 8), -Fraction(1, 40)])
    assert exact_norm == Fraction(1351, 40000)
    shear = np.array([[1., .2], [0., 1.]])
    js = shear @ np.array([[0., -1.], [1., 0.]]) @ np.linalg.inv(shear)
    horizons = (1, 2, 3, 4, 6, 9)
    for q in horizons:
        grad = gradient(b0, q)
        expected = q*(1/8)**q*np.array([np.sin(q*np.pi/2), np.cos(q*np.pi/2)])
        actual = np.array([np.sum(grad*b0), np.sum(grad*(b0@js))])
        assert np.allclose(actual, expected, atol=1e-16, rtol=1e-12)
        assert np.linalg.norm(grad) > 0
    matrices = [b0]
    for coordinate in range(4):
        for step in (-.001, -.0001, .0001, .001):
            m = b0.copy(); m.flat[coordinate] += step; matrices.append(m)
    max_derivative_error = 0.; max_lyapunov_residual = 0.; max_root_error = 0.
    min_covariance = np.inf; min_variance_by_horizon = {q: np.inf for q in horizons}
    min_effect_gap = np.inf; checked = 0
    e = np.diag([1., -1.])
    for b in matrices:
        assert np.linalg.norm(b, 2) < 1
        roots, common = stationary_pair(b)
        min_effect_gap = min(min_effect_gap, roots[0][1, 0]-roots[2][1, 0])
        assert roots[0][1, 0] > 0 > roots[2][1, 0]
        gradients = {}
        for q in horizons:
            g = gradient(b, q); numerical = np.zeros((2, 2)); step = 1e-6
            for coordinate in range(4):
                h = np.zeros((2, 2)); h.flat[coordinate] = step
                numerical.flat[coordinate] = (
                    np.linalg.matrix_power(b+h, q)[1, 0]
                    - np.linalg.matrix_power(b-h, q)[1, 0])/(2*step)
            relative_error = np.linalg.norm(g-numerical)/np.linalg.norm(g)
            max_derivative_error = max(max_derivative_error, float(relative_error))
            assert relative_error < 2e-7
            gradients[q] = g.ravel(order='F')
        for branch, scale in ((0, .7), (2, 1.)):
            a = roots[branch]; d = common-a@common@a.T
            max_root_error = max(max_root_error, float(abs(a@a@a-b).max()))
            assert abs(d[0, 1]) < 1e-12
            v = lyapunov(a, e)
            for epsilon in (-.025, 0., .025):
                gamma = common+scale*epsilon*v
                covariance = gamma-b@gamma@b.T
                innovations = d+scale*epsilon*e
                assert np.linalg.eigvalsh(innovations).min() > 0
                independent = lyapunov(b, covariance)
                max_lyapunov_residual = max(max_lyapunov_residual,
                    float(abs(gamma-independent).max()))
                min_covariance = min(min_covariance,
                    float(np.linalg.eigvalsh(gamma).min()),
                    float(np.linalg.eigvalsh(covariance).min()))
                for q, g in gradients.items():
                    variance = float(g@np.kron(np.linalg.inv(gamma), covariance)@g)
                    assert variance > 0
                    min_variance_by_horizon[q] = min(min_variance_by_horizon[q], variance)
                    checked += 1
    assert max_root_error < 1e-12 and max_lyapunov_residual < 1e-12
    report = dict(status='passed', transitions_checked=len(matrices),
                  horizons=list(horizons), population_variances_checked=checked,
                  exact_center_frobenius_norm_squared=str(exact_norm),
                  center_directional_derivatives_checked=True,
                  maximum_relative_gradient_error=max_derivative_error,
                  maximum_root_error=max_root_error,
                  maximum_lyapunov_residual=max_lyapunov_residual,
                  minimum_sampled_covariance_eigenvalue=min_covariance,
                  minimum_sampled_effect_gap=float(min_effect_gap),
                  minimum_sampled_variance_by_horizon=min_variance_by_horizon,
                  empirical_paths_added=0, structural_optimizer_fits_added=0,
                  scope='Finite deterministic checks; no certified radius or numerical proof of uniformity.')
    path = BASE/'results/varying_grid/verification.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
