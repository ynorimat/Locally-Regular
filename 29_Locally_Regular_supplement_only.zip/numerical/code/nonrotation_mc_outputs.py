"""Export all four nonrotation cells from summary counts (standard library)."""
from pathlib import Path
import csv

BASE = Path(__file__).resolve().parents[1]
OUT = BASE/'results/nonrotation_mc'


def main():
    with (OUT/'summary.csv').open(newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    def get(regime, truth, method):
        return next(r for r in rows if r['regime']==regime and int(r['truth'])==truth and r['method']==method)
    def pct(row, event='coverage'):
        return f"{100*int(row[event+'_count'])/int(row['reps']):.1f}"
    lines = [r'\begin{table}[htbp]', r'\centering\small',
      r'\caption{Nonrotation diagnostic at $n=32000$: 500 independent paths per row. Coverage and wrong-sign declarations use all attempted paths (percent); brackets give 95\% Wilson Monte Carlo intervals for selected coverage. Oracle uses the true initial branch; on-grid OLS targets $B_{21}=1/8$. All 6000 fits were accepted, with no nearest-root label changes.}',
      r'\label{tab:nonrotation_mc}', r'\begin{tabular}{llrrrr}', r'\toprule',
      r'$\varepsilon$ & Source & Selected [MC interval] & Oracle & On-grid & Wrong/all \\', r'\midrule']
    for regime, label in [('inverse_n',r'$1/n$'), ('fixed_e005',r'$1/20$')]:
        for truth, sign in [(2,'Negative'),(0,'Positive')]:
            sel = get(regime,truth,'selected'); ora = get(regime,truth,'true_branch_oracle'); grid = get(regime,truth,'on_grid')
            interval = f"[{100*float(sel['coverage_lo']):.1f}, {100*float(sel['coverage_hi']):.1f}]"
            lines.append(f"{label} & {sign} & {pct(sel)} {interval} & {pct(ora)} & {pct(grid)} & {pct(sel,'wrong')} "+r'\\')
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    # Caption assertions must not silently persist when a rerun has failures.
    failures=sum(int(r['failures']) for r in rows)
    migrations=max(int(r['start_label_migrations']) for r in rows)
    if failures or migrations:
        lines[2]=lines[2].replace('All 6000 fits were accepted, with no nearest-root label changes.',
          f'Interval failures total {failures} across the three methods; the maximum per-cell count of nearest-root label changes is {migrations}. See the complete summaries for denominators.')
    (OUT/'table.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    selected=[r for r in rows if r['method']=='selected']
    oracle=[r for r in rows if r['method']=='true_branch_oracle']
    grid=[r for r in rows if r['method']=='on_grid']
    def span(rs, key='coverage_rate'):
        vs=[100*float(r[key]) for r in rs]; return f'{min(vs):.1f}--{max(vs):.1f}'
    acceptance = ('All 6,000 fits were accepted. ' if not failures else
                  'Interval failure counts are included in the summaries. ')
    maintext=(r'\paragraph{Beyond rotations.} '+
      r'The same unrestricted estimator is applied to the explicit nonrotation pair of Proposition~\ref{prop:persistence}, at $n=32000$, using 500 paths per source and perturbation (2,000 paths). '+
      rf'Table~\ref{{tab:nonrotation_mc}} shows selected coverage of {span(selected)}\%, versus {span(oracle)}\% for the true-branch oracle. '+
      acceptance+
      r'This fixed-pair diagnostic supports the phenomenon beyond rotations; Appendix~\ref{app:nonrotation_mc} gives the protocol and checks.'+'\n')
    (OUT/'main_text.tex').write_text(maintext,encoding='utf-8')
    text=(rf'Selected coverage ranges from {span(selected)}\%, compared with {span(oracle)}\% for the true-branch oracle and {span(grid)}\% for on-grid OLS. '+
      rf'Wrong-sign declarations from selected intervals occur on {span(selected,"wrong_rate")}\% of attempted paths. '+
      r'The fixed $1/20$ perturbation improves selected coverage only modestly at this sample size; it is smaller than the $.2$ control in the rotation experiment. '+
      r'This four-cell diagnostic supports the distinction between within-branch precision and branch uncertainty at the explicit pair. It neither establishes uniform calibration over the neighborhood in Proposition~\ref{prop:persistence} nor certifies global optimization.'+'\n')
    (OUT/'summary_text.tex').write_text(text,encoding='utf-8')
    print('Exported nonrotation table and two text fragments.')


if __name__ == '__main__': main()
