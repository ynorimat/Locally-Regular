Supplement to Locally Regular, Globally Hard to Distinguish: Causal Effects under Temporal Subsampling

docs/complete_results.pdf contains Supplementary Tables S1–S15, Figure S1, and Corollary S1. These use the same labels as the citations in the main paper.

docs/additional_diagnostics.pdf gives comparisons in which the sampled transition is known, together with their calibration and simulation design.

numerical/README.md explains how to use the two estimators and reproduce the numerical comparisons. numerical/RESULT_MAP.md links individual tables to the data files.
