"""Exact LLR moments for two complete laws on fixed competing roots.

No optimization over A or B occurs here. Both hypotheses and their diagonal
innovation covariances are fully specified. This is not a profile-test law.
"""
from __future__ import annotations
import numpy as np
from rotation_family import RotationFamily


def llr_moments(family: RotationFamily, epsilon: float, n: int,
                source: int, target: int) -> dict[str, float]:
    """Return moments of log(p_target / p_source), including the stationary start.

    The target innovation anisotropy is beta(source,target)*epsilon. Finite-sample
    moments are under both complete Gaussian path laws. Require feasible positive
    diagonal innovation covariances and a nonnegative integer transition count.
    """
    if not isinstance(n, (int, np.integer)) or n < 0:
        raise ValueError('n must be a nonnegative integer')
    if not np.isscalar(epsilon) or not np.isfinite(epsilon):
        raise ValueError('epsilon must be a finite scalar')
    if source not in range(family.k) or target not in range(family.k):
        raise ValueError('invalid root index')
    beta = family.beta(source, target)
    if abs(epsilon) >= 1 or abs(beta*epsilon) >= 1:
        raise ValueError('both positive diagonal covariance conditions must hold')
    ws, wt = family.w[source], family.w[target]
    residual = float(np.imag(ws*np.conj(wt))**2/abs(wt)**2)
    v = beta**2*abs(wt)**2
    aa = abs(family.multiplier)**2
    e2 = epsilon**2
    xg = residual*e2/(family.gamma_scale**2-v*e2)
    xq = aa*residual*e2/(family.q_scale**2-aa*v*e2)
    if not (0 <= xg < 1 and 0 <= xq < 1):
        raise ArithmeticError('relative covariance determinant outside its domain')
    def component(x):
        minus_mean = .5*np.log1p(-x)
        plus_mean = x/(1-x) + .5*np.log1p(-x)
        return np.array([minus_mean, x, plus_mean, x*(1+x)/(1-x)**2])
    vals = component(xg)+n*component(xq)
    return dict(mean_source=float(vals[0]), variance_source=float(vals[1]),
                mean_target=float(vals[2]), variance_target=float(vals[3]),
                x_initial=float(xg), x_transition=float(xq),
                j=float(aa*residual/(2*family.q_scale**2)), beta=float(beta))
