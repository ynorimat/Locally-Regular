"""Direct experiments for local-global identification, using exact sufficient statistics.

Design:
  H-=(A2,D_e), H+=(A0,D_(.7 e)), B known under both.
  e=1/n and e=c/sqrt(n), c=1,4,12, n=500,2000,8000,32000.
  Split procedure: B and all three A branches known, diagonal variances unknown.
  Calibrated two-simple oracle: both complete Gaussian laws known, including D.
  Forced optimal classifier: same two complete laws, equal-prior likelihood ratio.

A Gaussian VAR with known B is exactly equivalent to a stationary initial state
and n independent innovations. Bartlett Wishart draws generate their exact
scatter matrices, not asymptotic approximations or effective sample sizes.
"""
from __future__ import annotations
import argparse, csv, json, time
from pathlib import Path
import numpy as np
from rotation_family import RotationFamily
from example_model import profile_loglik
BASE=Path(__file__).resolve().parents[1]
FAM=RotationFamily()


def wishart(df, q, reps, rng):
    if df<2: raise ValueError('df must be >=2')
    bart=np.zeros((reps,2,2))
    bart[:,0,0]=np.sqrt(rng.chisquare(df,size=reps))
    bart[:,1,0]=rng.normal(size=reps)
    bart[:,1,1]=np.sqrt(rng.chisquare(df-1,size=reps))
    y=np.linalg.cholesky(q)[None,:,:]@bart
    return y@np.swapaxes(y,-1,-2)


def sample_stats(n, eps, branch, reps, rng, split=False):
    anis=eps if branch==2 else FAM.beta(2,0)*eps
    g,q=FAM.covariance(branch,anis)
    z0=rng.normal(size=(reps,2))@np.linalg.cholesky(g).T
    if split:
        n1=n//2
        return z0,wishart(n1,q,reps,rng),wishart(n-n1,q,reps,rng)
    return z0,wishart(n,q,reps,rng)


def llr(z0, scatter, n, eps):
    """log p_positive / p_negative, including the stationary initial density."""
    gm,qm=FAM.covariance(2,eps)
    gp,qp=FAM.covariance(0,FAM.beta(2,0)*eps)
    dg=np.linalg.inv(gp)-np.linalg.inv(gm)
    dq=np.linalg.inv(qp)-np.linalg.inv(qm)
    constant=(np.linalg.slogdet(gp)[1]-np.linalg.slogdet(gm)[1]
              +n*(np.linalg.slogdet(qp)[1]-np.linalg.slogdet(qm)[1]))
    return -.5*(constant+np.einsum('ri,ij,rj->r',z0,dg,z0)
                +np.einsum('ij,rji->r',dq,scatter))


def wilson(count,n):
    z=1.959963984540054; p=count/n; den=1+z*z/n
    center=(p+z*z/(2*n))/den
    half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return float(max(0,center-half)),float(min(1,center+half))


def metrics(neg, pos, true_branch):
    empty=~(neg|pos); both=neg&pos; declared=neg^pos
    coverage=neg if true_branch==2 else pos
    wrong=(pos&~neg) if true_branch==2 else (neg&~pos)
    return dict(effect_covered=coverage,both_signs=both,sign_declared=declared,
                wrong_sign=wrong,empty=empty)


def write_csv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--reps',type=int,default=10000)
    ap.add_argument('--calibration',type=int,default=39999)
    ap.add_argument('--seed',type=int,default=20260923)
    args=ap.parse_args()
    if min(args.reps,args.calibration)<1: raise ValueError('sample sizes must be positive')
    out=BASE/'results'; rawdir=out/'local_raw';rawdir.mkdir(exist_ok=True)
    summaries=[]; errors=[]; checks=[]; start=time.perf_counter(); alpha=.05
    regimes=[('inverse_n',None),('local_c1',1.),('local_c4',4.),('local_c12',12.)]
    for ni,n in enumerate((500,2000,8000,32000)):
        for ri,(regime,c) in enumerate(regimes):
            eps=1/n if c is None else c/np.sqrt(n)
            seedbase=[args.seed,ni,ri]
            cal={}
            for truth in (2,0):
                rng=np.random.default_rng(np.random.SeedSequence(seedbase+[0,truth]))
                zi,ss=sample_stats(n,eps,truth,args.calibration,rng)
                cal[truth]=np.sort(llr(zi,ss,n,eps))
            np.savez_compressed(rawdir/f'calibration_{regime}_n{n}.npz',negative=cal[2],positive=cal[0])
            for truth in (2,0):
                rng=np.random.default_rng(np.random.SeedSequence(seedbase+[1,truth]))
                z0,st,su=sample_stats(n,eps,truth,args.reps,rng,split=True)
                n1=n//2; n2=n-n1
                qt=st/n1
                reference=-.5*(n2*np.linalg.slogdet(qt)[1]
                               +np.trace(np.linalg.solve(qt,su),axis1=-2,axis2=-1))
                prof=np.stack([profile_loglik(su/n2,n2,j) for j in range(3)],axis=1)
                keep=(reference[:,None]-prof)<=np.log(1/alpha)
                t=llr(z0,st+su,n,eps)
                # Under H-, large t is evidence against H-; under H+, small t is against H+.
                pn=(1+args.calibration-np.searchsorted(cal[2],t,side='left'))/(args.calibration+1)
                pp=(1+np.searchsorted(cal[0],t,side='right'))/(args.calibration+1)
                kn=pn>alpha; kp=pp>alpha
                for method,negative,positive in [('split_three_branch',keep[:,2],keep[:,:2].any(axis=1)),
                                                 ('calibrated_two_simple',kn,kp)]:
                    rec=dict(n=n,regime=regime,c='' if c is None else c,epsilon=eps,true_branch=truth,
                             method=method,reps=args.reps,alpha=alpha)
                    met=metrics(negative,positive,truth)
                    for key,val in met.items():
                        count=int(val.sum());rec[key+'_count']=count;rec[key+'_rate']=count/args.reps
                        rec[key+'_wilson_low'],rec[key+'_wilson_high']=wilson(count,args.reps)
                    rec['mean_diameter']=.75*met['both_signs'].mean()
                    if method=='split_three_branch':
                        rec['true_branch_retention']=float(keep[:,truth].mean())
                    else: rec['true_branch_retention']=float(met['effect_covered'].mean())
                    summaries.append(rec)
                err=(t>0) if truth==2 else (t<0)
                er=dict(n=n,regime=regime,epsilon=eps,true_branch=truth,reps=args.reps,
                        error_count=int(err.sum()),error_rate=float(err.mean()))
                er['wilson_low'],er['wilson_high']=wilson(int(err.sum()),args.reps)
                er['mean_log_positive_over_negative']=float(t.mean())
                er['variance_log_positive_over_negative']=float(t.var(ddof=1)); errors.append(er)
                covname=(('a','b','c'))
                np.savez_compressed(rawdir/f'evaluation_{regime}_n{n}_truth{truth}.npz',
                                    initial=z0,training_scatter=st,test_scatter=su,split_keep=keep,
                                    positive_log_likelihood_ratio=t,calibrated_negative=kn,calibrated_positive=kp)
                # Stored scatter matrices are sufficient for reproducing all decisions.
                km=float(FAM.profile_kl(eps,n,2,0)[0])
                if truth==2:
                    checks.append(dict(n=n,regime=regime,epsilon=eps,exact_KL=km,
                                       empirical_KL=float(-t.mean()),sd_LLR=float(t.std(ddof=1)),
                                       mc_se_KL=float(t.std(ddof=1)/np.sqrt(args.reps))))
            pair=[x for x in errors if x['n']==n and x['regime']==regime]
            print(f'{regime:10s} n={n:5d} e={eps:.6g} Bayes_error={np.mean([x["error_rate"] for x in pair]):.4f}',flush=True)
    write_csv(out/'local_summary.csv',summaries)
    write_csv(out/'simple_LR_errors.csv',errors)
    write_csv(out/'KL_simulation_checks.csv',checks)
    meta=dict(seed=args.seed,evaluation_reps_per_law_per_condition=args.reps,
              conditions=len(regimes)*4,law_condition_cells=len(errors),
              total_evaluation_replications=len(errors)*args.reps,
              calibration_draws_per_law_per_condition=args.calibration,
              total_calibration_draws=len(errors)*args.calibration,
              alpha=alpha,elapsed_seconds=time.perf_counter()-start,
              simulation='Exact Bartlett Wishart scatter draws plus independent stationary initial state; known-B Gaussian VAR sufficient statistics',
              split_information='Known B, fixed A0,A1,A2; unknown arbitrary positive diagonal D; train covariance unconstrained',
              two_simple_information='Known B and both full structural laws including diagonal D; H-=(A2,D_e), H+=(A0,D_.7e)',
              calibration='Independent per condition; rank p-values; finite-sample size is unconditional over calibration and evaluation',
              intervals='Wilson Monte Carlo intervals conditional on recorded calibration; they do not quantify calibration Monte Carlo uncertainty',
              raw='NPZ includes sufficient statistics and decisions for every evaluation; independent calibration score arrays also retained')
    (out/'local_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps(meta,indent=2))

if __name__=='__main__': main()
