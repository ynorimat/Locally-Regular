"""Fixed-horizon observed-VAR Wald intervals, Theorem 2(iv).

Inputs are averages of the n transition cross products. No structural branch,
true transition, or true innovation covariance is supplied to the estimator.
The guarantee is asymptotic on the fixed theorem family. The deterministic
output illustrates its gradient and variance, not finite-sample calibration.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.linalg import solve_discrete_lyapunov
from scipy.stats import norm

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'results/theory_checks'


def effect_gradient(matrix, q):
    """Column-vectorized gradient of (matrix**q)[1, 0]."""
    if not isinstance(q, (int, np.integer)) or q < 1:
        raise ValueError('q must be a positive integer')
    matrix = np.asarray(matrix, dtype=float)
    p = len(matrix)
    if matrix.shape != (p, p) or p < 2:
        raise ValueError('matrix must be square with dimension at least two')
    powers = [np.eye(p)]
    for _ in range(q):
        powers.append(powers[-1] @ matrix)
    gradient = sum(np.kron(powers[q-1-u][:, 0], powers[u][1, :])
                   for u in range(q))
    return float(powers[q][1, 0]), gradient


def interval_from_moments(s00, s10, s11, n, q=1, alpha=.05):
    """Return the estimate, standard error, interval, and regular-event flag.

    The exceptional-event interval is the real line, as in Appendix A.2.5.
    """
    if n <= 0 or not 0 < alpha < 1:
        raise ValueError('require n > 0 and 0 < alpha < 1')
    failure = dict(estimate=None, se=None, lower=-np.inf, upper=np.inf, valid=False)
    try:
        np.linalg.cholesky(s00)
        inverse = np.linalg.inv(s00)
        bhat = s10 @ inverse
        qhat = s11 - bhat @ s10.T
        qhat = (qhat + qhat.T) / 2
        np.linalg.cholesky(qhat)
        estimate, gradient = effect_gradient(bhat, q)
        variance = float(gradient @ np.kron(inverse, qhat) @ gradient)
        if not np.isfinite(variance) or variance <= 0:
            return failure
        se = np.sqrt(variance / n)
        half = norm.ppf(1-alpha/2) * se
        return dict(estimate=estimate, se=float(se), lower=float(estimate-half),
                    upper=float(estimate+half), valid=True)
    except np.linalg.LinAlgError:
        return failure


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for branch in range(3):
        angle = np.pi/6 + 2*np.pi*branch/3
        a = .5*np.array([[np.cos(angle), -np.sin(angle)],
                         [np.sin(angle), np.cos(angle)]])
        b = np.linalg.matrix_power(a, 3)
        for t in (-.8, -.2, 0., .2, .8):
            gamma = solve_discrete_lyapunov(a, np.diag([1+t, 1-t]))
            covariance = gamma - b @ gamma @ b.T
            for q in (1, 2, 3, 6):
                effect, gradient = effect_gradient(b, q)
                variance = float(gradient @ np.kron(np.linalg.inv(gamma), covariance) @ gradient)
                rows.append(dict(branch=branch, t=t, q=q, horizon=3*q,
                                 effect=effect, gradient_norm=np.linalg.norm(gradient),
                                 asymptotic_variance=variance))
    pd.DataFrame(rows).to_csv(OUT/'grid_population_checks.csv', index=False)
    metadata = dict( rows=len(rows), empirical_paths_added=0,
                    structural_refits_added=0,
                    scope='Deterministic illustrations of Theorem 2(iv), not a coverage simulation.',
                    implementation='code/uniform_grid.py',
                    proof='sections/uniform_grid_proof.tex')
    (OUT/'metadata.json').write_text(json.dumps(metadata, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
