"""Independent audit of the screened-union reanalysis (NumPy only).

Uses scalar 2x2 determinants/inverses and inclusion-exclusion for union length.
No branch_union or fitting module is imported. All new events and numeric
manuscript tables are checked; original raw-record hashes must agree.
"""
from pathlib import Path
from statistics import NormalDist
from itertools import combinations
import csv
import hashlib
import json
import math
import numpy as np

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'results/branch_union'


def det(a):
    return a[0,0]*a[1,1]-a[0,1]*a[1,0]


def inv(a):
    return np.array([[a[1,1],-a[0,1]],[-a[1,0],a[0,0]]])/det(a)


def read(name):
    with (OUT/name).open(newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))


def main():
    report=json.loads((OUT/'verification.json').read_text())
    protocol=json.loads((BASE/'branch_union_protocol.json').read_text())
    assert hashlib.sha256((BASE/'branch_union_protocol.json').read_bytes()).hexdigest()==report['protocol_sha256']
    z=NormalDist().inv_cdf(1-protocol['alpha_interval']/2)
    critical=NormalDist().inv_cdf(1-protocol['alpha_screen']/2)**2
    records=read('records.csv')
    lookup={(r['experiment'],r['source_file'],int(r['record']),r['method']):r for r in records}
    assert len(records)==len(lookup)==40000
    maximum=0.; maximum_rho=0.; minimum_imag=float('inf'); maximum_scaled_score=0.; checked=0
    for relative,digest in report['input_sha256'].items():
        path=BASE/relative
        assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
        experiment='nonrotation' if '/nonrotation_mc/' in relative else 'principal'
        with np.load(path,allow_pickle=False) as data:
            fits=data['fits']; n=int(data['n']); truth=int(data['truth'])
            target=-.5 if truth==2 else .25
            for i,fit in enumerate(fits):
                xx,yx,yy=[data[v][i] for v in ['s00','s10','s11']]
                bh=yx@inv(xx)
                qh=yy-bh@yx.T
                qh=(qh+qh.T)/2
                eigen=np.linalg.eigvals(bh)
                maximum_rho=max(maximum_rho,float(abs(eigen).max()))
                minimum_imag=min(minimum_imag,float(abs(eigen.imag).min()))
                maximum_scaled_score=max(maximum_scaled_score,float(np.max(fit[:,3])*np.sqrt(n)))
                assert max(abs(eigen))<1 and min(abs(eigen.imag))>0
                assert det(qh)>0 and qh[0,0]>0 and np.all(fit[:,5]==1)
                ratios=[]; bounds=[]
                for j in range(3):
                    A=np.array([[fit[j,6],fit[j,7]],[fit[j,0],fit[j,8]]])
                    D=np.diag(fit[j,9:11]); A2=A@A; B=A2@A
                    Q=D+A@D@A.T+A2@D@A2.T
                    R=yy-B@yx.T-yx@B.T+B@xx@B.T
                    ratio=n*(math.log(det(Q)/det(qh))+np.trace(inv(Q)@R)-2)
                    ratios.append(ratio)
                    bounds.append((fit[j,0]-z*fit[j,1],fit[j,0]+z*fit[j,1]))
                for method in ['screened_union','all_branch_union']:
                    row=lookup[(experiment,path.name,i,method)]
                    retained=[j for j in range(3) if method=='all_branch_union' or ratios[j]<=critical]
                    for j in range(3):
                        maximum=max(maximum,abs(float(row[f'lr{j}'])-ratios[j]))
                        assert int(row[f'keep{j}'])==int(j in retained)
                        assert abs(float(row[f'lower{j}'])-bounds[j][0])<1e-10
                        assert abs(float(row[f'upper{j}'])-bounds[j][1])<1e-10
                    intervals=[bounds[j] for j in retained]
                    covered=any(a<=target<=b for a,b in intervals)
                    if intervals:
                        lo=min(a for a,b in intervals); hi=max(b for a,b in intervals)
                        both=lo<0<hi; declared=lo>0 or hi<0
                        wrong=lo>0 if target<0 else hi<0
                        diameter=hi-lo
                    else:
                        both=declared=wrong=False; diameter=0.
                    length=0.
                    for size in range(1,len(intervals)+1):
                        for subset in combinations(intervals,size):
                            length+=(-1)**(size+1)*max(0.,min(v[1] for v in subset)-max(v[0] for v in subset))
                    events=dict(covered=covered,both=both,declared=declared,wrong=wrong,empty=not intervals,true_retained=truth in retained)
                    for key,val in events.items(): assert int(row[key])==int(val)
                    assert abs(float(row['diameter'])-diameter)<1e-10
                    assert abs(float(row['total_length'])-length)<1e-10
                    assert int(row['fallback'])==0 and int(row['branches'])==len(retained)
                    checked+=1
    assert maximum<1e-7 and checked==40000
    summaries=read('summary.csv')
    assert (OUT/'summary.csv').read_bytes()==(BASE/'reported_results/branch_union_summary.csv').read_bytes()
    for s in summaries:
        rows=[r for r in records if all(r[key]==s[key] for key in ['experiment','regime','n','truth','method'])]
        assert len(rows)==int(s['reps'])
        for key in ['covered','both','declared','wrong','empty','fallback','true_retained']:
            count=sum(int(r[key]) for r in rows)
            assert count==int(s[key+'_count'])
            assert abs(count/len(rows)-float(s[key+'_rate']))<1e-12
        for key in ['diameter','total_length']:
            assert abs(np.median([float(r[key]) for r in rows])-float(s['median_'+key]))<1e-10
    ms=BASE/'exports/branch_union'
    # TeX exports are supplied in the separate source archive.
    # Numerical records and frozen CSVs above are always audited.
    if ms.is_dir():
        for file in OUT.glob('*.tex'):
            assert file.read_bytes()==(ms/file.name).read_bytes()
    # Independently check every displayed numerical cell against the summary.
    for filename,experiment in [('principal_table.tex','principal'),('nonrotation_table.tex','nonrotation')]:
        if not (OUT/filename).is_file():
            continue  # optional TeX display check; all numeric rows checked above
        table=(OUT/filename).read_text()
        for s in summaries:
            if s['experiment']!=experiment or s['method']!='screened_union': continue
            fragment=f"{100*float(s['covered_rate']):.1f} [{100*float(s['coverage_lo']):.1f}, {100*float(s['coverage_hi']):.1f}]"
            assert fragment in table
    result=dict(status='passed',checked_record_method_pairs=checked,checked_summary_rows=len(summaries),maximum_lr_difference=maximum,
                maximum_observed_spectral_radius=maximum_rho,minimum_observed_eigenvalue_imaginary_magnitude=minimum_imag,
                maximum_sqrt_n_scaled_score=maximum_scaled_score,
                scope='Independent scalar-matrix and interval-union audit; no resimulation or mathematical proof certificate.')
    from screened_union import confidence_union
    path=BASE/'results/unknown_B_raw/inverse_n_n32000_truth2.npz'
    with np.load(path,allow_pickle=False) as d:
        for i in [0,200,400,600,800]:
            answer=confidence_union(d['s00'][i],d['s10'][i],d['s11'][i],d['fits'][i],int(d['n']))
            row=lookup['principal',path.name,i,'screened_union']
            assert not answer['fallback']
            assert answer['retained']==[j for j in range(3) if int(row[f'keep{j}'])]
            for j in range(3): assert abs(answer['statistics'][j]-float(row[f'lr{j}']))<1e-7
        unusable=confidence_union(np.zeros((2,2)),d['s10'][0],d['s11'][0],d['fits'][0],int(d['n']))
        assert unusable['fallback'] and unusable['intervals']==[[-float('inf'),float('inf')]]
    result['reusable_procedure_checks']=6
    result['optional_tex_tables_present']=sum((OUT/name).is_file() for name in ['principal_table.tex','nonrotation_table.tex'])
    (OUT/'independent_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
