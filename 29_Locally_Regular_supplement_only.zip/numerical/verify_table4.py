"""Verify the six displayed comparison rows against the numerical summaries."""
from pathlib import Path
import csv,json
BASE=Path(__file__).resolve().parent
c=json.loads((BASE/'table4_values.json').read_text())
def rows(path):
    with (BASE/path).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
local,one=[rows(p) for p in c['source_files']]
for v in c['records']:
    def match(r):return all(r[k]==str(v[k]) for k in ['setting','regime','n','truth'])
    l=next(r for r in local if match(r) and r['method']=='screened_union')
    o=next(r for r in one if match(r))
    assert int(l['reps'])==int(o['reps'])==v['paths']
    for field,value in [('local_coverage',l['coverage']),('one_step_coverage',o['coverage']),('local_median_diameter',l['diameter']),('one_step_median_diameter',o['median_diameter'])]:
        assert v[field]==float(value),(v['setting'],field)
print('PASS: all six comparison rows match the original saved CSV summaries')
