"""Complete paired comparison and one-step evaluation on the 46 saved cells.

No simulations, optimizer calls, fitted labels, or threshold tuning.
Both local-fit unions use exactly the same 97.5% component intervals.
"""
from pathlib import Path
from statistics import NormalDist
import csv
import hashlib
import json
import numpy as np
from branch_union import union_metrics, wilson
from one_step_union import fit_batch

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'results/method_comparisons'
MANUSCRIPT=BASE/'exports/method_comparisons'


def read_csv(path):
    with path.open(encoding='utf-8',newline='') as f: return list(csv.DictReader(f))


def cells():
    for setting,folder in [('Base','unknown_B_raw'),('Nonrotation','nonrotation_mc/raw'),(None,'robustness/sensitivity_raw')]:
        for path in sorted((BASE/'results'/folder).glob('*.npz')):
            with np.load(path,allow_pickle=False) as d:
                k=int(d['k']) if 'k' in d else 3
                name=str(d['setting']).title() if setting is None else setting
                truth=int(d['truth'])
                target=float(d['r'])*np.sin(float(d['theta'])+2*np.pi*truth/k) if setting is None else (-.5 if truth==2 else .25)
                yield path,dict(setting=name,k=k,n=int(d['n']),regime=str(d['regime']),truth=truth,target=target),[d[v].copy() for v in ['s00','s10','s11']]


def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def analyze():
    protocol=json.loads((BASE/'method_comparisons_protocol.json').read_text())
    z=NormalDist().inv_cdf(1-protocol['alpha_interval']/2)
    cutoff=NormalDist().inv_cdf(1-protocol['alpha_screen']/2)**2
    baseline=[]
    for directory in ['branch_union','sensitivity_union']:
        for row in read_csv(BASE/f'results/{directory}/summary.csv'):
            setting=(row.get('setting') or ('Base' if row['experiment']=='principal' else 'Nonrotation')).title()
            baseline.append(dict(setting=setting,k=int(row.get('k',3)),regime=row['regime'],n=int(row['n']),truth=int(row['truth']),method=row['method'],
                reps=int(row['reps']),coverage=float(row['covered_rate']),diameter=float(row['median_diameter']),length=float(row['median_total_length']),
                declared=float(row['declared_rate']),wrong=float(row['wrong_rate']),empty=int(row['empty_count']),fallback=int(row['fallback_count'])))
    assert len(baseline)==92
    records=[];summary=[];hashes={}
    for path,meta,ss in cells():
        result=fit_batch(*ss,meta['n'],meta['k'])
        keep=result['statistics']<=cutoff
        p=result['parameters'];se=result['standard_error']
        lo=p[:,:,2]-z*se;hi=p[:,:,2]+z*se
        rr=[]
        for i in range(len(p)):
            intervals=[(float(lo[i,j]),float(hi[i,j])) for j in range(meta['k']) if keep[i,j]]
            if result['fallback'][i]: intervals=[(-float('inf'),float('inf'))]
            cv,both,decl,wrong,empty,diam,length=union_metrics(intervals,meta['target'])
            row=dict(**meta,source_file=path.name,record=i,covered=int(cv),both=int(both),declared=int(decl),wrong=int(wrong),empty=int(empty),
                diameter=diam,total_length=length,fallback=int(result['fallback'][i]),retained=int(keep[i].sum()),
                true_retained=int(keep[i,meta['truth']] or result['fallback'][i]))
            for j in range(5):
                row[f'lower{j}']=float(lo[i,j]) if j<meta['k'] else ''
                row[f'upper{j}']=float(hi[i,j]) if j<meta['k'] else ''
                row[f'lr{j}']=float(result['statistics'][i,j]) if j<meta['k'] else ''
            rr.append(row);records.append(row)
        count=sum(r['covered'] for r in rr);ci=wilson(count,len(rr))
        s=dict(**meta,reps=len(rr),covered_count=count,coverage=count/len(rr),coverage_lo=ci[0],coverage_hi=ci[1],
            median_diameter=float(np.median([r['diameter'] for r in rr])),median_total_length=float(np.median([r['total_length'] for r in rr])))
        for name in ['declared','wrong','empty','fallback','true_retained']:
            s[name+'_count']=sum(r[name] for r in rr);s[name+'_rate']=s[name+'_count']/len(rr)
        summary.append(s)
        hashes[path.relative_to(BASE).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
    assert len(records)==32000 and len(summary)==46
    OUT.mkdir(exist_ok=True,parents=True);MANUSCRIPT.mkdir(exist_ok=True,parents=True)
    write_csv(OUT/'local_fit_comparison.csv',baseline)
    write_csv(OUT/'one_step_records.csv',records)
    write_csv(OUT/'one_step_summary.csv',summary)
    write_csv(MANUSCRIPT/'local_fit_comparison.csv',baseline)
    write_csv(MANUSCRIPT/'one_step_summary.csv',summary)
    export_tables(baseline,summary)
    report=dict(status='computed',paths=32000,cells=46,one_step_fallbacks=sum(s['fallback_count'] for s in summary),
        min_one_step_coverage=min(s['coverage'] for s in summary),max_one_step_coverage=max(s['coverage'] for s in summary),
        input_sha256=hashes,protocol_sha256=hashlib.sha256((BASE/'method_comparisons_protocol.json').read_bytes()).hexdigest(),
        scope='New deterministic fits on the original paths, plus paired existing-local-fit comparison; no independent replication.')
    (OUT/'computation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='input_sha256'},indent=2))
    for s in summary:
        if s['n']==32000 and s['regime']=='fixed_e02':print(s['setting'],s['truth'],'one-step',s['coverage'])


def export_tables(baseline,summary):
    order={'Base':0,'Radius':1,'Angle':2,'Sampling':3,'Nonrotation':4}
    regimes={'inverse_n':r'$1/n$','local_c4':r'$4/\sqrt n$','fixed_e02':r'$.2$','fixed_e005':r'$.05$'}
    # Use the labels present in the original records, without changing their values.
    for r in summary:
        if r['regime'] not in regimes:
            if 'inv' in r['regime'] or r['regime']=='one_over_n':regimes[r['regime']]=r'$1/n$'
            elif 'local' in r['regime']:regimes[r['regime']]=r'$4/\sqrt n$'
            else: raise ValueError(r['regime'])
    rows=sorted(summary,key=lambda x:(order[x['setting']],x['regime'],x['truth'],x['n']))
    # Full paired comparisons: 46 rows, split into two readable tables.
    for part,ss in enumerate([rows[:22],rows[22:]],1):
        lines=[r'\begin{table}[p]',r'\centering\small',
            r'\caption{Paired local-fit unions ('+str(part)+r'/2). Each entry is screened / unfiltered; both use the same 97.5\% component intervals. Coverage (Cov.) and sign declarations (Decl.) are percentages; diameter and total length are medians. A declaration requires the entire set to have one strict sign. All '+('1,000 Base or 500 other' if part==1 else '500')+r' paths per row enter the denominator.}',
            r'\label{tab:union_comparison_'+str(part)+'}',r'\begin{tabular}{llcrrrrr}',r'\toprule',
            r'Setting & $\varepsilon$ & Sign & $n$ & Cov. & Diameter & Length & Decl.\\',r'\midrule']
        for s in ss:
            pair=[next(b for b in baseline if all(b[key]==s[key] for key in ['setting','regime','truth','n']) and b['method']==m) for m in ['screened_union','all_branch_union']]
            a,b=pair
            lines.append(f"{s['setting']} & {regimes[s['regime']]} & {'$-$' if s['target']<0 else '$+$'} & {s['n']} & "+
                ' & '.join(f"{a[key]*scale:.{prec}f}/{b[key]*scale:.{prec}f}" for key,scale,prec in [('coverage',100,1),('diameter',1,3),('length',1,3),('declared',100,1)])+r'\\')
        lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
        (MANUSCRIPT/f'comparison_{part}.tex').write_text('\n'.join(lines)+'\n')
    for part,ss in enumerate([rows[:22],rows[22:]],1):
        lines=[r'\begin{table}[p]',r'\centering\small',
            r'\caption{One-step screened unions ('+str(part)+r'/2): all original cells, with no iterative optimization. Brackets give 95\% Wilson intervals. Rates are percentages; diameter and total length are medians. Empty and fallback are counts. Base rows have 1,000 paths; all others have 500.}',
            r'\label{tab:one_step_'+str(part)+'}',r'\begin{tabular}{llcrrrrrr}',r'\toprule',
            r'Setting & $\varepsilon$ & Sign & $n$ & Coverage [MC] & Diam. & Length & Empty & Fallback\\',r'\midrule']
        for s in ss:
            lines.append(f"{s['setting']} & {regimes[s['regime']]} & {'$-$' if s['target']<0 else '$+$'} & {s['n']} & {100*s['coverage']:.1f} [{100*s['coverage_lo']:.1f}, {100*s['coverage_hi']:.1f}] & {s['median_diameter']:.3f} & {s['median_total_length']:.3f} & {s['empty_count']} & {s['fallback_count']}"+r'\\')
        lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
        (MANUSCRIPT/f'one_step_{part}.tex').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':analyze()
