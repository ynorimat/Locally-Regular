"""Exact two-branch construction outside positive diagonal rotation similarities.

The construction is deterministic. Symbolic assertions check compatibility,
positivity, and point identification on 0 < |epsilon| <= 1/20. High-precision
distance evaluations supplement the written argument; no Monte Carlo is used.
"""
from pathlib import Path
import json
import sympy as s
import mpmath as mp
import numpy as np
import pandas as pd
from rotation_family import local_information

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'results/branch_diagnostics'


def construction():
    q=s.Rational; rt=s.sqrt(3); eye=s.eye(2); E=s.diag(1,-1)
    S=s.Matrix([[1,q(1,5)],[0,1]])
    rotations=[s.Matrix([[rt/4,-q(1,4)],[q(1,4),rt/4]]),
               s.Matrix([[-rt/4,-q(1,4)],[q(1,4),-rt/4]]),
               s.Matrix([[0,q(1,2)],[-q(1,2),0]])]
    roots=[s.simplify(S*a*S.inv()) for a in rotations]
    x,y,z=s.symbols('x y z'); GG=s.Matrix([[x,y],[y,z]])
    equations=[(GG-roots[m]*GG*roots[m].T)[0,1] for m in (0,2)]+[x+z-q(8,3)]
    sol=s.solve(equations,(x,y,z)); assert len(sol)==3
    G=s.simplify(GG.subs(sol))
    ds=[s.simplify(G-a*G*a.T) for a in roots]
    B=s.simplify(roots[0]**3)
    assert all(s.simplify(a**3-B)==s.zeros(2) for a in roots)
    assert G[0,0]>0 and s.simplify(G.det())>0
    eps=s.symbols('epsilon',real=True); limit=q(1,20)
    derivatives={}; checks={}
    for m,mult in [(2,s.Integer(1)),(0,q(7,10))]:
        a=roots[m];d=ds[m]
        assert d[0,1]==0 and d[1,0]==0
        for diagonal in range(2):
            assert s.simplify(d[diagonal,diagonal]-limit*mult)>0
        delta=s.simplify(GG.subs(s.solve(list(GG-a*GG*a.T-mult*E),(x,y,z))))
        derivatives[m]=delta
        constraints=[]
        for j,other in enumerate(roots):
            f=s.simplify((G+eps*delta-other*(G+eps*delta)*other.T)[0,1])
            intercept=s.simplify(f.subs(eps,0));slope=s.simplify(s.diff(f,eps))
            assert s.diff(f,eps,2)==0
            if j==m: assert f==0
            elif intercept==0: assert slope!=0
            else:
                assert s.simplify(f.subs(eps,-limit)*f.subs(eps,limit))>0
            constraints.append(dict(candidate=j,intercept=str(intercept),slope=str(slope),
                                    intercept_numeric=float(intercept),slope_numeric=float(slope)))
        assert a[0,0]!=a[1,1]
        information=local_information(np.array(a,dtype=float),np.array(d,dtype=float),3)
        checks[str(m)]=dict(innovation_diagonal=[float(d[i,i]) for i in range(2)],
                           local_information_minimum=float(np.linalg.eigvalsh(information).min()),
                           exclusion_constraints=constraints)
    return roots,G,ds,B,derivatives,checks


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    roots,G,ds,B,delta,checks=construction()
    mp.mp.dps=70
    def matrix(M): return mp.matrix([[mp.mpf(str(s.N(v,72))) for v in row] for row in M.tolist()])
    g=matrix(G);b=matrix(B);directions={m:matrix(v) for m,v in delta.items()}
    def kl(a,c):
        product=c**-1*a
        return (product[0,0]+product[1,1]-2+mp.log(mp.det(c)/mp.det(a)))/2
    records=[]
    for n in [2000,8000,32000,128000]:
        eps=mp.mpf(1)/n
        gm=g+eps*directions[2];gp=g+eps*directions[0]
        qm=gm-b*gm*b.T;qp=gp-b*gp*b.T
        initial=kl(gm,gp);transition=kl(qm,qp);total=initial+n*transition
        records.append(dict(n=n,epsilon=float(eps),initial_KL=float(initial),
                            per_transition_KL=float(transition),path_KL=float(total),
                            effect_gap=.75,diameter_lower_probability=float(mp.mpf('.9')-mp.sqrt(total/2))))
    pd.DataFrame(records).to_csv(OUT/'nonrotation_distances.csv',index=False)
    result=dict(shear=[[1,.2],[0,1]],covariance_exact=[[str(v) for v in row] for row in G.tolist()],
                covariance_numeric=np.array(G,dtype=float).tolist(),
                roots=[np.array(a,dtype=float).tolist() for a in roots],
                innovation_diagonals_and_checks=checks,
                epsilon_interval='0 < |epsilon| <= 1/20',
                common_cube_exact=True,positive_covariance_and_diagonal_innovations=True,
                all_wrong_roots_excluded_symbolically=True,
                unequal_diagonals_exclude_positive_diagonal_rotation_similarity=True,
                precision_digits=70,status='all symbolic and numerical checks passed')
    (OUT/'nonrotation_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    gvals=np.array(G,dtype=float);d0=checks['0']['innovation_diagonal'];d2=checks['2']['innovation_diagonal']
    text=(r'The exact linear system gives '+
          r'$\Gamma_\circ\approx\left(\begin{smallmatrix}'+
          f'{gvals[0,0]:.6f}&{gvals[0,1]:.6f}'+r'\\'+f'{gvals[1,0]:.6f}&{gvals[1,1]:.6f}'+r'\end{smallmatrix}\right)$, '+
          rf'$D_{{0,\circ}}\approx\diag({d0[0]:.6f},{d0[1]:.6f})$ and '+
          rf'$D_{{2,\circ}}\approx\diag({d2[0]:.6f},{d2[1]:.6f})$. '+
          'These decimals are descriptive; all calculations use the exact defining system. '+
          r'The smallest full-coordinate information eigenvalues at $\varepsilon=0$ are approximately '+
          f"${checks['0']['local_information_minimum']:.6f}$ on branch 0 and ${checks['2']['local_information_minimum']:.6f}$ on branch 2."+'\n')
    (OUT/'nonrotation_constants.tex').write_text(text)
    rows=[r'\begin{table}[htbp]',r'\centering\small',
          r'\caption{Deterministic whole-path KL in the nonrotation example along $\varepsilon_n=1/n$. The final column is the two-point diameter bound at level 95\%, for a gap of $3/4$. No simulated paths or fitted intervals enter these values.}',
          r'\label{tab:nonrotation}',r'\begin{tabular}{rrr}',r'\toprule',
          r'$n$ & Whole-path KL & Diameter bound \\',r'\midrule']
    for row in records:
        rows.append(f"{row['n']} & {row['path_KL']:.8f} & {row['diameter_lower_probability']:.6f} "+r'\\')
    rows.extend([r'\bottomrule',r'\end{tabular}',r'\end{table}'])
    (OUT/'nonrotation_table.tex').write_text('\n'.join(rows)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
