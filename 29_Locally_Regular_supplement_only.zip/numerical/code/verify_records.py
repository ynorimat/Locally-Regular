"""Verify stored decisions and summaries against every saved sufficient statistic."""
from pathlib import Path
import re,json
import numpy as np
import pandas as pd
from example_model import profile_loglik
from local_sequence_experiments import llr,metrics
BASE=Path(__file__).resolve().parents[1]

def main():
    out=BASE/'results';s=pd.read_csv(out/'local_summary.csv');count=0;max_llr=0.
    for p in sorted((out/'local_raw').glob('evaluation_*.npz')):
        ma=re.fullmatch(r'evaluation_(.+)_n(\d+)_truth(\d+)\.npz',p.name)
        regime,n,truth=ma[1],int(ma[2]),int(ma[3])
        q=s[(s.regime==regime)&(s.n==n)&(s.true_branch==truth)]
        eps=q.epsilon.iloc[0];a=np.load(p,allow_pickle=False)
        z,st,su=a['initial'],a['training_scatter'],a['test_scatter'];r=len(z)
        score=llr(z,st+su,n,eps)
        max_llr=max(max_llr,float(np.max(abs(score-a['positive_log_likelihood_ratio']))))
        qt=st/(n//2);nt=n-n//2
        ref=-.5*(nt*np.linalg.slogdet(qt)[1]+np.trace(np.linalg.solve(qt,su),axis1=-2,axis2=-1))
        prof=np.stack([profile_loglik(su/nt,nt,j) for j in range(3)],axis=1)
        keep=ref[:,None]-prof<=np.log(20.)
        assert np.array_equal(keep,a['split_keep'])
        cal=np.load(out/'local_raw'/f'calibration_{regime}_n{n}.npz',allow_pickle=False)
        M=len(cal['negative'])
        kn=(1+M-np.searchsorted(cal['negative'],score,side='left'))/(M+1)>.05
        kp=(1+np.searchsorted(cal['positive'],score,side='right'))/(M+1)>.05
        assert np.array_equal(kn,a['calibrated_negative']) and np.array_equal(kp,a['calibrated_positive'])
        for method,neg,pos in [('split_three_branch',keep[:,2],keep[:,:2].any(axis=1)),('calibrated_two_simple',kn,kp)]:
            row=q[q.method==method].iloc[0]
            mm=metrics(neg,pos,truth)
            for key,vals in mm.items(): assert int(vals.sum())==int(row[key+'_count'])
            assert np.all(mm['effect_covered']==~(mm['wrong_sign']|mm['empty']))
            assert np.all(mm['both_signs'].astype(int)+mm['sign_declared'].astype(int)+mm['empty'].astype(int)==1)
        count+=r
    metadata=json.loads((out/'local_metadata.json').read_text())
    assert count==metadata['total_evaluation_replications'] and max_llr<1e-9
    record={'evaluation_records_verified':count,'summary_rows_verified':len(s),
            'max_saved_vs_recomputed_LLR_error':max_llr,'status':'all stored decisions and summary counts reproduced'}
    (out/'verification_records.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))

if __name__=='__main__':main()
