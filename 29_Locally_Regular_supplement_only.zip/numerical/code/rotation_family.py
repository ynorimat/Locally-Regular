"""Gaussian VAR rotation families and global/local identification diagnostics.

All candidate fine innovation variances are unknown unless a function explicitly
specifies a fully-known simple hypothesis. Coordinate order for Fisher information:
(A11,A12,A21,A22,d1,d2). Numerical routines use float64, not interval arithmetic.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.linalg import solve_discrete_lyapunov


def rotation(angle: float) -> np.ndarray:
    c, s = np.cos(angle), np.sin(angle)
    return np.array([[c, -s], [s, c]])


def traceless(z: complex) -> np.ndarray:
    return np.array([[np.real(z), np.imag(z)], [np.imag(z), -np.real(z)]], dtype=float)


def coarsen(a: np.ndarray, d: np.ndarray, k: int) -> tuple[np.ndarray, np.ndarray]:
    p = np.eye(2); q = np.zeros((2, 2))
    for _ in range(k):
        q += p @ d @ p.T
        p = p @ a
    return p, (q + q.T)/2


@dataclass(frozen=True)
class RotationFamily:
    k: int = 3
    r: float = .5
    theta: float = np.pi/6

    def __post_init__(self):
        if not isinstance(self.k, (int, np.integer)) or self.k < 2:
            raise ValueError('k must be an integer >=2')
        if not 0 < self.r < 1 or not np.isfinite(self.theta):
            raise ValueError('require 0<r<1 and finite theta')

    @property
    def angles(self):
        return self.theta + 2*np.pi*np.arange(self.k)/self.k

    @property
    def roots(self):
        return np.stack([self.r*rotation(t) for t in self.angles])

    @property
    def B(self):
        return self.r**self.k*rotation(self.k*self.theta)

    @property
    def w(self):
        return 1/(1-self.r**2*np.exp(2j*self.angles))

    @property
    def multiplier(self):
        return 1-self.r**(2*self.k)*np.exp(2j*self.k*self.theta)

    @property
    def gamma_scale(self):
        return 1/(1-self.r**2)

    @property
    def q_scale(self):
        return (1-self.r**(2*self.k))/(1-self.r**2)

    def covariance(self, branch: int, anisotropy: float, mean: float = 1.):
        if branch not in range(self.k) or not abs(anisotropy) < mean:
            raise ValueError('invalid branch or nonpositive diagonal innovation')
        gamma = mean*self.gamma_scale*np.eye(2) + anisotropy*traceless(self.w[branch])
        q = mean*self.q_scale*np.eye(2) + anisotropy*traceless(self.multiplier*self.w[branch])
        return gamma, q

    def beta(self, source: int, target: int) -> float:
        ws, wt = self.w[source], self.w[target]
        return float(np.real(ws*np.conj(wt))/abs(wt)**2)

    def profile_kl(self, epsilon, n: int, source: int, target: int):
        """Exact minimum KL(P_source,epsilon || P_target,D) for small enough epsilon.

        The target transition matrix (and hence sampled B) is FIXED. Only D ranges
        over all positive diagonal covariances; this is not an infimum over A.
        The same D*=diag(1+beta*epsilon,1-beta*epsilon) separately minimizes the
        initial-state and transition divergences. Returns total, initial, transition.
        """
        epsilon = np.asarray(epsilon, dtype=float)
        beta = self.beta(source, target)
        if n < 0 or np.any(abs(epsilon) >= 1) or np.any(abs(beta*epsilon) >= 1):
            raise ValueError('require n>=0, |epsilon|<1, |beta*epsilon|<1')
        ws, wt = self.w[source], self.w[target]
        a = abs(ws)**2
        # Determinant form avoids cancellation in a - beta^2 |wt|^2.
        residual = float(np.imag(ws*np.conj(wt))**2/abs(wt)**2)
        xx = epsilon**2
        kg = .5*np.log1p(residual*xx/(self.gamma_scale**2-a*xx))
        cmag = abs(self.multiplier)**2
        kq = .5*np.log1p(cmag*residual*xx/(self.q_scale**2-cmag*a*xx))
        return kg+n*kq, kg, kq

    def collinearity_margin(self):
        w = self.w
        return min(abs(np.imag(w[m]*np.conj(w[l])))/(abs(w[m])*abs(w[l]))
                   for m in range(self.k) for l in range(m))

    def power_derivative_determinant(self, branch):
        t = self.angles[branch]
        if abs(np.sin(t)) < 1e-13:
            # Removable singularity. This case is excluded by the main theorem.
            return (self.k*self.r**(self.k-1))**4
        return self.k**2*self.r**(4*(self.k-1))*(np.sin(self.k*t)/np.sin(t))**2


def gaussian_kl(g0, g1):
    return float(.5*(np.trace(np.linalg.solve(g1, g0))-2+
                       np.linalg.slogdet(g1)[1]-np.linalg.slogdet(g0)[1]))


def derivatives(a, d, k):
    """Exact analytic first derivatives of (A^k,Q) in all six structural directions."""
    p = [np.eye(2)]
    for _ in range(k):
        p.append(p[-1] @ a)
    db, dq = [], []
    for idx in range(6):
        da = np.zeros((2,2)); dd = np.zeros((2,2))
        if idx < 4: da.flat[idx] = 1.
        else: dd[idx-4, idx-4] = 1.
        dp = np.zeros((2,2)); qprime = np.zeros((2,2))
        for l in range(k):
            qprime += dp@d@p[l].T+p[l]@dd@p[l].T+p[l]@d@dp.T
            dp = dp@a+p[l]@da
        db.append(dp); dq.append(qprime)
    return np.array(db), np.array(dq)


def local_information(a, d, k):
    """Per-transition conditional Gaussian Fisher information, stationary expectation."""
    _, q = coarsen(a,d,k)
    gamma = solve_discrete_lyapunov(a,d)
    qi = np.linalg.inv(q)
    db, dq = derivatives(a,d,k)
    information = np.empty((6,6))
    for i in range(6):
        for j in range(6):
            information[i,j] = (np.trace(qi@db[i]@gamma@db[j].T)
                               +.5*np.trace(qi@dq[i]@qi@dq[j]))
    return (information+information.T)/2
