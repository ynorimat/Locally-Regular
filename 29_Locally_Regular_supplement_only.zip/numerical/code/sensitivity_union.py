"""Apply the screened union to all sensitivity records.

No simulation, optimization or threshold tuning occurs. The input files must
match the SHA-256 hashes in the input record manifest. All 24 cells and
all 12,000 attempted paths are retained. NumPy and the standard library suffice.
"""
from pathlib import Path
from statistics import NormalDist
import csv
import hashlib
import json
import time
import numpy as np
from gaussian_var import observed, fisher_standard_error, tangent
from branch_union import wilson, union_metrics

BASE = Path(__file__).resolve().parents[1]
OUT = BASE/'results/sensitivity_union'


def read_csv(path):
    with path.open(encoding='utf-8', newline='') as stream:
        return list(csv.DictReader(stream))


def analyze():
    started = time.perf_counter()
    protocol_path = BASE/'sensitivity_union_protocol.json'
    protocol = json.loads(protocol_path.read_text())
    z = NormalDist().inv_cdf(1-protocol['alpha_interval']/2)
    critical = NormalDist().inv_cdf(1-protocol['alpha_screen']/2)**2
    zsel = NormalDist().inv_cdf(.975)
    manifest = json.loads((BASE/'sensitivity_inputs.json').read_text())
    original_hashes = {r['path']: r['sha256'] for r in manifest['files']}
    original_summary = read_csv(BASE/'results/robustness/sensitivity_summary.csv')
    records, summaries, hashes = [], [], {}
    maxima = dict(objective=0., standard_error=0., score_difference=0., score=0., finite_difference_se=0.)
    candidate_count = 0
    paths = sorted((BASE/'results/robustness/sensitivity_raw').glob('*.npz'))
    assert len(paths) == 24
    for path in paths:
        relative = path.relative_to(BASE).as_posix()
        hashes[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
        assert hashes[relative] == original_hashes[relative]
        with np.load(path, allow_pickle=False) as d:
            fit = d['fits']; n = int(d['n']); truth = int(d['truth']); k = int(d['k'])
            r, theta = float(d['r']), float(d['theta'])
            regime, setting = str(d['regime']), str(d['setting'])
            xx, yx, yy = [d[key] for key in ['s00','s10','s11']]
        reps = len(fit)
        assert fit.shape == (500,k,12) and np.all(fit[:,:,5] == 1)
        target = r*np.sin(theta+2*np.pi*truth/k)
        parameters = fit[:,:,[6,7,0,8,9,10]].reshape(-1,6)
        a, dv, _, b, q = observed(parameters,k)
        assert abs(np.linalg.eigvals(a)).max()<1 and parameters[:,4:].min()>0
        angles = theta+2*np.pi*np.arange(k)/k
        roots = np.array([r*np.array([[np.cos(t),-np.sin(t)],[np.sin(t),np.cos(t)]]) for t in angles])
        nearest = np.linalg.norm(a[:,None]-roots[None],axis=(2,3)).argmin(axis=1)
        assert np.array_equal(nearest,np.tile(np.arange(k),reps))
        rx, ry, rz = [np.repeat(v,k,axis=0) for v in (xx,yx,yy)]
        res = rz-b@ry.transpose(0,2,1)-ry@b.transpose(0,2,1)+b@rx@b.transpose(0,2,1)
        qi = np.linalg.inv(q)
        obj = (.5*(np.linalg.slogdet(q)[1]+np.trace(qi@res,axis1=1,axis2=2))).reshape(reps,k)
        se = fisher_standard_error(parameters,n,k).reshape(reps,k)
        maxima['objective'] = max(maxima['objective'],float(abs(obj-fit[:,:,2]).max()))
        maxima['standard_error'] = max(maxima['standard_error'],float(abs(se-fit[:,:,1]).max()))
        db,dq = tangent(parameters,k)
        bg = qi@(b@rx-ry); qg = .5*(qi-qi@res@qi)
        grad = np.column_stack([np.sum(bg*db[j]+qg*dq[j],axis=(1,2)) for j in range(6)])
        grad[:,4:] *= parameters[:,4:]
        scores = abs(grad).max(axis=1).reshape(reps,k)
        maxima['score'] = max(maxima['score'],float(scores.max()))
        maxima['score_difference'] = max(maxima['score_difference'],float(abs(scores-fit[:,:,3]).max()))
        fd_indices = np.array([i*k+j for i in (0,249,499) for j in range(k)])
        fd = fisher_standard_error(parameters[fd_indices],n,k,finite_difference=True)
        maxima['finite_difference_se'] = max(maxima['finite_difference_se'],float(abs(fd-se.ravel()[fd_indices]).max()))
        bh = np.linalg.solve(xx,yx.transpose(0,2,1)).transpose(0,2,1)
        qh = yy-bh@yx.transpose(0,2,1); qh = (qh+qh.transpose(0,2,1))/2
        eig = np.linalg.eigvals(bh)
        assert abs(eig).max()<1 and abs(eig.imag).min()>0 and np.linalg.eigvalsh(qh).min()>0
        unrestricted = .5*(np.linalg.slogdet(qh)[1]+2)
        lr = 2*n*(obj-unrestricted[:,None])
        assert lr.min()>-1e-7
        keep = lr<=critical
        lo,hi = fit[:,:,0]-z*se,fit[:,:,0]+z*se
        choice = obj.argmin(axis=1)
        selected = fit[np.arange(reps),choice,0]
        selected_se = se[np.arange(reps),choice]
        selected_covered = abs(selected-target)<=zsel*selected_se
        # Preserve every originally reported sensitivity event count and width.
        for method,est,err in [('selected',selected,selected_se),('true_branch_oracle',fit[:,truth,0],se[:,truth])]:
            row = next(s for s in original_summary if s['setting']==setting and s['regime']==regime
                       and int(s['n'])==n and int(s['truth'])==truth and s['method']==method)
            low,high = est-zsel*err,est+zsel*err
            assert int(row['coverage_count'])==int(((low<=target)&(target<=high)).sum())
            assert int(row['wrong_count'])==int(((low>0) if target<0 else (high<0)).sum())
            assert abs(float(row['median_width'])-float(np.median(high-low)))<1e-9
        local=[]
        for i in range(reps):
            for method,mask in [('screened_union',keep[i]),('all_branch_union',np.ones(k,dtype=bool))]:
                intervals=[(float(lo[i,j]),float(hi[i,j])) for j in range(k) if mask[j]]
                covered,both,declared,wrong,empty,diameter,length=union_metrics(intervals,target)
                row=dict(setting=setting,k=k,source_file=path.name,record=i,n=n,truth=truth,target=target,regime=regime,
                         method=method,covered=int(covered),both=int(both),declared=int(declared),wrong=int(wrong),empty=int(empty),
                         diameter=diameter,total_length=length,branches=int(mask.sum()),fallback=0,
                         true_retained=int(mask[truth]),selected_covered=int(selected_covered[i]))
                for j in range(5):
                    row.update({f'lr{j}':float(lr[i,j]) if j<k else '',f'lower{j}':float(lo[i,j]) if j<k else '',
                                f'upper{j}':float(hi[i,j]) if j<k else '',f'keep{j}':int(mask[j]) if j<k else ''})
                records.append(row);local.append(row)
        for method in ['screened_union','all_branch_union']:
            rr=[v for v in local if v['method']==method]
            summary=dict(setting=setting,k=k,regime=regime,n=n,truth=truth,target=target,method=method,reps=reps)
            for metric in ['covered','both','declared','wrong','empty','fallback','true_retained']:
                count=sum(v[metric] for v in rr)
                summary[metric+'_count']=count;summary[metric+'_rate']=count/reps
            summary['coverage_lo'],summary['coverage_hi']=wilson(summary['covered_count'],reps)
            summary['median_diameter']=float(np.median([v['diameter'] for v in rr]))
            summary['median_total_length']=float(np.median([v['total_length'] for v in rr]))
            summary['mean_branches']=float(np.mean([v['branches'] for v in rr]))
            for j in range(k+1):summary[f'branches_{j}_count']=sum(v['branches']==j for v in rr)
            for j in range(k+1,6):summary[f'branches_{j}_count']=0
            gain=np.array([v['covered']-v['selected_covered'] for v in rr],float)
            summary['selected_coverage']=float(selected_covered.mean())
            summary['paired_coverage_gain']=float(gain.mean())
            summary['paired_gain_mcse']=float(gain.std(ddof=1)/np.sqrt(reps))
            summaries.append(summary)
        candidate_count+=reps*k
        print(setting,regime,n,truth,'screened',summaries[-2]['covered_rate'],'both',summaries[-2]['both_rate'],flush=True)
    assert len(records)==24000 and len(summaries)==48 and candidate_count==44000
    assert maxima['objective']<1e-11 and maxima['standard_error']<1e-9 and maxima['score']<1e-6
    assert maxima['finite_difference_se']<1e-8
    OUT.mkdir(parents=True,exist_ok=True)
    for filename,rows in [('records.csv',records),('summary.csv',summaries)]:
        with (OUT/filename).open('w',encoding='utf-8',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    report=dict(status='passed',paths=12000,candidate_fits=candidate_count,finite_difference_fits=264,
                method_records=len(records),summary_rows=len(summaries),max_errors=maxima,
                input_sha256=hashes,protocol_sha256=hashlib.sha256(protocol_path.read_bytes()).hexdigest(),
                elapsed_seconds=time.perf_counter()-started,
                scope='All sensitivity paths checked against input hashes. Statistics use the supplied sufficient statistics and fits.')
    (OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report|{'input_sha256':'24 verified original files'},indent=2))


if __name__=='__main__':
    analyze()
