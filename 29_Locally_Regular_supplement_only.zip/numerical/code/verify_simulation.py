"""Independent recurrence/likelihood and Wishart distribution checks."""
from pathlib import Path
import json
import numpy as np
from rotation_family import RotationFamily
from local_sequence_experiments import wishart,llr
BASE=Path(__file__).resolve().parents[1]

def main():
    rng=np.random.default_rng(20260924);f=RotationFamily()
    checks={};maxerr=0.
    for branch in [0,2]:
        eps=.3;N=23;R=200; t=eps if branch==2 else .7*eps
        g,q=f.covariance(branch,t)
        z=np.empty((R,N+1,2));z[:,0]=rng.normal(size=(R,2))@np.linalg.cholesky(g).T
        noise=rng.normal(size=(R,N,2))@np.linalg.cholesky(q).T
        for i in range(N):z[:,i+1]=z[:,i]@f.B.T+noise[:,i]
        scatter=np.einsum('rti,rtj->rij',noise,noise)
        fast=llr(z[:,0],scatter,N,eps)
        logs=[]
        for m,tt in [(0,.7*eps),(2,eps)]:
            gm,qm=f.covariance(m,tt)
            res=z[:,1:]-z[:,:-1]@f.B.T
            v=-.5*(np.linalg.slogdet(gm)[1]+np.einsum('ri,ij,rj->r',z[:,0],np.linalg.inv(gm),z[:,0])
                    +N*np.linalg.slogdet(qm)[1]+np.einsum('rti,ij,rtj->r',res,np.linalg.inv(qm),res))
            logs.append(v)
        maxerr=max(maxerr,float(np.max(abs(fast-(logs[0]-logs[1])))))
    assert maxerr<1e-10
    checks['explicit_path_vs_sufficient_statistic_LLR_max_error']=maxerr
    q=np.array([[1.3,.2],[.2,.9]]);df=37;reps=100000
    w=wishart(df,q,reps,rng)
    mean=w.mean(axis=0);se=np.sqrt(df*(q*q+np.diag(q)[:,None]*np.diag(q)[None,:])/reps)
    zscore=(mean-df*q)/se
    assert np.max(abs(zscore))<6
    checks['Wishart_mean_z_scores']=zscore.tolist()
    # Marginal W11 / Q11 must have exact chi-square(df) mean and variance.
    scaled=w[:,0,0]/q[0,0]
    checks['Wishart_marginal_mean']=float(scaled.mean())
    checks['Wishart_marginal_variance']=float(scaled.var(ddof=1))
    checks['Wishart_marginal_targets']={'mean':df,'variance':2*df}
    checks['status']='all assertions passed; stochastic moment checks use six-SE tolerance'
    (BASE/'results'/'verification_simulation.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
