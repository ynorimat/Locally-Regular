# Numerical supplement

The unknown-transition experiments comprise 18 principal conditions (18,000 paths), four nonrotation conditions (2,000 paths), and 24 rotation-sensitivity conditions (12,000 paths). The 46 NPZ files contain path-level sufficient statistics, structural fits, and design information. The CSV files report estimates and interval events. RESULT_MAP.md links the tables to these records.

## Verify from the distributed records

Run the following commands in this directory, with Python and NumPy. Run the integrity check first. Some checks write reports to results/.

    python reproduce.py check
    python reproduce.py verify-submission
    python reproduce.py verify-branch-union
    python reproduce.py verify-sensitivity-union
    python reproduce.py verify-method-comparisons
    python reproduce.py verify-finite-bounds
    python reproduce.py verify-varying-grid
    python verify_table4.py
    python verify_table4_medians.py

These commands verify the reported summaries and interval events, or check analytical calculations against numerical evaluations. No optimizer or simulation is needed for the commands above.

## Use the estimators

The function confidence_union in code/screened_union.py takes the observed moments, number of transitions, sampling interval and local structural fits. The function confidence_set in code/one_step_union.py takes the moments, number of transitions and sampling interval, and computes its own one-step fits. Both return the component intervals and indicate whether they used the real-line fallback. Proposition 8 states coverage for the generating effect on the compact families studied in the paper.

## Regenerate estimates

The signed effects are compared on the same simulated paths. To recompute local-fit and one-step union summaries from the distributed sufficient statistics, run the following commands in order.

    python reproduce.py branch-union
    python reproduce.py sensitivity-union
    python reproduce.py method-comparisons

For full simulation use the packages listed in requirements.txt. The seeds and fitting settings are in IMPLEMENTATION_DETAILS.txt and the protocol files. The computing environment used for the numerical experiments is recorded in environment.json.

    python reproduce.py simulate-all
    python reproduce.py summarize
    python reproduce.py verify

Full simulation and refitting can take substantially longer than verification. OMITTED_RESULTS.csv lists regenerable auxiliary arrays, including the calibration runs for known-transition benchmarks. Run computational commands on a working copy if the supplied records are needed for subsequent comparison.
