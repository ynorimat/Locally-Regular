"""Equal-information known-B comparison; exact uncentered-correlation pivot.

Full and test-half correlation sets use the same fixed three roots and unknown
positive diagonal D as the split likelihood set. They ignore the eigenvalue-ratio
constraint. No sample centering, estimated B, or data-estimated eigenbasis is used.
Local-sequence records are re-used; fixed-epsilon control records are new.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from example_model import U, profile_loglik
from local_sequence_experiments import sample_stats, metrics, wilson
BASE=Path(__file__).resolve().parents[1]
ALPHA=.05


def correlation_keep(scatter: np.ndarray, n: int, alpha: float=ALPHA) -> np.ndarray:
    """Return (...,3) candidate-retention mask from exact t_(n-1) tests."""
    s=np.asarray(scatter,dtype=float)
    if n<2 or s.shape[-2:]!=(2,2) or not 0<alpha<1:
        raise ValueError('Require n>=2, (...,2,2) scatter and 0<alpha<1')
    threshold=student_t.ppf(1-alpha/2,n-1)
    # Compare rho^2 to the equivalent critical value; avoids infinite t near |rho|=1.
    r2crit=threshold**2/(n-1+threshold**2)
    keep=[]
    for u in U:
        rotated=np.swapaxes(u,-1,-2)@s@u
        denom=rotated[...,0,0]*rotated[...,1,1]
        if np.any(denom<=0): raise ValueError('Positive marginal scatter required')
        r2=rotated[...,0,1]**2/denom
        if np.any(r2>1+1e-10): raise ValueError('Scatter is not positive semidefinite')
        keep.append(r2<=r2crit)
    return np.stack(keep,axis=-1)


def split_keep(st,su,n,alpha=ALPHA):
    n1=n//2; n2=n-n1; qt=st/n1
    ref=-.5*(n2*np.linalg.slogdet(qt)[1]+np.trace(np.linalg.solve(qt,su),axis1=-2,axis2=-1))
    prof=np.stack([profile_loglik(su/n2,n2,j) for j in range(3)],axis=1)
    return ref[:,None]-prof<=np.log(1/alpha)


def summarize(negative,positive,truth,info,method,branch_keep=None):
    met=metrics(negative,positive,truth); reps=len(negative)
    row={**info,'true_branch':truth,'method':method,'reps':reps,'alpha':ALPHA}
    for key,value in met.items():
        count=int(value.sum()); row[key+'_count']=count;row[key+'_rate']=count/reps
        row[key+'_wilson_low'],row[key+'_wilson_high']=wilson(count,reps)
    row['true_branch_count']=int(branch_keep[:,truth].sum()) if branch_keep is not None else int(met['effect_covered'].sum())
    row['true_branch_retention']=row['true_branch_count']/reps
    row['mean_diameter']=.75*met['both_signs'].mean()
    nd=row['sign_declared_count']; nw=row['wrong_sign_count']
    row['wrong_given_declared']=nw/nd if nd else np.nan
    row['conditional_wrong_low'],row['conditional_wrong_high']=wilson(nw,nd) if nd else (np.nan,np.nan)
    return row,met


def evaluate_record(st,su,truth,info,old=None):
    n=info['n']; ksplit=split_keep(st,su,n)
    if old is not None and 'split_keep' in old:
        if not np.array_equal(ksplit,old['split_keep']): raise AssertionError('Split decisions differ')
    masks={'split_three_branch':ksplit,
           'correlation_full':correlation_keep(st+su,n),
           'correlation_test_half':correlation_keep(su,n-n//2)}
    rows=[]; events={}
    for name,k in masks.items():
        row,met=summarize(k[:,2],k[:,:2].any(axis=1),truth,info,name,k)
        rows.append(row);events[name]=met
    if old is not None and 'calibrated_negative' in old:
        row,_=summarize(old['calibrated_negative'],old['calibrated_positive'],truth,info,'calibrated_two_simple')
        rows.append(row)
    paired=[]
    for left,right in [('correlation_full','split_three_branch'),('correlation_full','correlation_test_half')]:
        for event in ['effect_covered','both_signs','sign_declared','wrong_sign','empty']:
            x=events[left][event].astype(int)-events[right][event].astype(int)
            se=float(x.std(ddof=1)/np.sqrt(len(x)))
            paired.append({**info,'true_branch':truth,'left':left,'right':right,'event':event,
                           'reps':len(x),'mean_difference':float(x.mean()),'paired_mc_se':se,
                           'normal_low':float(x.mean()-1.95996398454*se),'normal_high':float(x.mean()+1.95996398454*se)})
    return rows,paired,masks


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--fixed-reps',type=int,default=10000)
    ap.add_argument('--seed',type=int,default=20260924)
    ap.add_argument('--regenerate-fixed',action='store_true')
    args=ap.parse_args()
    out=BASE/'results';raw=out/'fixed_raw';raw.mkdir(exist_ok=True)
    summaries=[];paired=[];new_count=0;old_count=0
    for path in sorted((out/'local_raw').glob('evaluation_*.npz')):
        match=re.match(r'evaluation_(.+)_n(\d+)_truth(\d+)\.npz',path.name)
        regime,n,truth=match.groups();n=int(n);truth=int(truth)
        eps=1/n if regime=='inverse_n' else int(regime.replace('local_c',''))/np.sqrt(n)
        info=dict(design='local',regime=regime,n=n,epsilon=eps)
        with np.load(path) as z:
            rows,pp,ms=evaluate_record(z['training_scatter'],z['test_scatter'],truth,info,z)
            old_count+=len(z['initial'])
        summaries.extend(rows);paired.extend(pp)
    # Fixed nonzero anisotropy is specified before inspecting the new results.
    eps=.2
    for i,n in enumerate((500,2000,8000,32000)):
        for truth in (2,0):
            path=raw/f'evaluation_fixed_e02_n{n}_truth{truth}.npz'
            info=dict(design='fixed',regime='fixed_e02',n=n,epsilon=eps)
            if args.regenerate_fixed or not path.exists():
                rng=np.random.default_rng(np.random.SeedSequence([args.seed,i,truth]))
                z0,st,su=sample_stats(n,eps,truth,args.fixed_reps,rng,split=True)
                rows,pp,ms=evaluate_record(st,su,truth,info)
                np.savez_compressed(path,initial=z0,training_scatter=st,test_scatter=su,
                                    **{name+'_keep':value for name,value in ms.items()})
                new_count+=args.fixed_reps
            else:
                with np.load(path) as z:
                    if len(z['initial'])!=args.fixed_reps:raise ValueError('fixed-reps differs; use --regenerate-fixed')
                    rows,pp,ms=evaluate_record(z['training_scatter'],z['test_scatter'],truth,info)
                    for name,value in ms.items(): assert np.array_equal(value,z[name+'_keep'])
            summaries.extend(rows);paired.extend(pp)
    pd.DataFrame(summaries).to_csv(out/'equal_information_summary.csv',index=False)
    pd.DataFrame(paired).to_csv(out/'paired_method_differences.csv',index=False)
    metadata=dict(alpha=ALPHA,seed_fixed=args.seed,fixed_epsilon=eps,fixed_reps_per_law_condition=args.fixed_reps,
                  local_records_reused=old_count,fixed_records_total=8*args.fixed_reps,
                  fixed_records_generated_this_run=new_count,
                  common_information='B and all three A roots known; positive diagonal D unknown; no empirical centering',
                  methods=['split_three_branch','correlation_full','correlation_test_half'],
                  extra_information_method='calibrated_two_simple knows both complete laws and uses initial state',
                  wrong_denominator='All evaluation replications; conditional wrong_given_declared additionally reported',
                  paired='Same sufficient statistics per replication; correlation full-vs-test-half isolates sample use within same test',
                  calibration_intervals='Conditional on saved calibration draws; correlation tests need no calibration draws')
    (out/'equal_information_metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(pd.DataFrame(summaries).query("true_branch==2 and (n==32000 or design=='fixed')")[[
        'design','regime','n','method','true_branch_retention','both_signs_rate','sign_declared_rate','wrong_sign_rate','empty_rate','wrong_given_declared']].to_string(index=False))
    print('Reused local records:',old_count,'; new fixed records this run:',new_count)

if __name__=='__main__': main()
