"""Independent audit of paired on/off-grid inference from saved moments.

Does not import grid_contrast or any structural fitting/summary implementation.
Checks all original records, observed-VAR information indexing, equivalent
least-squares data, all counts/widths, Monte Carlo intervals, and input hashes.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.stats import norm, binomtest

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'results/grid_contrast'


def main():
    saved=pd.read_csv(OUT/'records.csv')
    summary=pd.read_csv(OUT/'summary.csv')
    paired=pd.read_csv(OUT/'paired_coverage.csv')
    original=pd.read_csv(BASE/'results/unknown_B_summary.csv')
    metadata=json.loads((OUT/'metadata.json').read_text())
    z=float(norm.ppf(.975))
    checked=0; equivalent_data=0
    errors={'ols_estimate':0.,'on_grid_se':0.,'full_information_se':0.,
            'least_squares_estimate':0.,'least_squares_residual':0.}
    for path in sorted((BASE/'results/unknown_B_raw').glob('*.npz')):
        assert hashlib.sha256(path.read_bytes()).hexdigest()==metadata['raw_input_sha256'][path.name]
        with np.load(path) as raw:
            x=raw['s00']; yx=raw['s10']; yy=raw['s11']; fits=raw['fits']
            n=int(raw['n']); truth=int(raw['truth']); regime=str(raw['regime'])
        actual=saved[saved.source_file==path.name].sort_values('original_index')
        assert np.array_equal(actual.original_index,np.arange(len(fits)))
        assert actual.on_grid_valid.all() and actual.off_grid_valid.all()
        assert np.all(fits[:,:,5]==1)
        bt=np.linalg.solve(x,yx.transpose(0,2,1))
        b=bt.transpose(0,2,1)
        residual=yy-b@yx.transpose(0,2,1)-yx@bt+b@x@bt
        invx=np.linalg.solve(x,np.broadcast_to(np.eye(2),x.shape))
        v=residual[:,1,1]*invx[:,0,0]/n
        se=np.sqrt(v)
        errors['ols_estimate']=max(errors['ols_estimate'],float(np.max(abs(actual.ols_on_grid_estimate-b[:,1,0]))))
        errors['on_grid_se']=max(errors['on_grid_se'],float(np.max(abs(actual.ols_on_grid_se-se))))
        # Row-wise vec(B)=(B11,B12,B21,B22). All four coefficients are nuisance-aware.
        qinv=np.linalg.inv(residual)
        info=np.einsum('nij,nkl->nikjl',qinv,x).reshape(-1,4,4)
        info_se=np.sqrt(np.linalg.inv(info)[:,2,2]/n)
        errors['full_information_se']=max(errors['full_information_se'],float(np.max(abs(info_se-se))))
        for i in (0,len(fits)//2,len(fits)-1):
            joint=np.block([[x[i],yx[i].T],[yx[i],yy[i]]])
            artificial=np.sqrt(n)*np.linalg.cholesky(joint).T
            design,response=artificial[:,:2],artificial[:,2:]
            coefficient=np.linalg.lstsq(design,response,rcond=None)[0]
            err=response-design@coefficient
            errors['least_squares_estimate']=max(errors['least_squares_estimate'],float(np.max(abs(coefficient.T-b[i]))))
            errors['least_squares_residual']=max(errors['least_squares_residual'],float(np.max(abs(err.T@err/n-residual[i]))))
            equivalent_data+=1
        chosen=np.argmin(fits[:,:,2],axis=1); indices=np.arange(len(fits))
        assert np.array_equal(chosen,actual.selected_branch)
        method_data={'ols_on_grid':(b[:,1,0],se,.125),
                     'selected_off_grid':(fits[indices,chosen,0],fits[indices,chosen,1],-.5 if truth==2 else .25),
                     'oracle_off_grid':(fits[:,truth,0],fits[:,truth,1],-.5 if truth==2 else .25)}
        events={}
        for method,(estimate,standard_error,target) in method_data.items():
            lower,upper=estimate-z*standard_error,estimate+z*standard_error
            cover=(lower<=target)&(target<=upper)
            events[method]=cover
            for name,array in [('estimate',estimate),('se',standard_error),('lower',lower),('upper',upper)]:
                assert np.allclose(actual[method+'_'+name],array,rtol=1e-11,atol=1e-12)
            assert np.array_equal(actual[method+'_covered'],cover)
            row=summary[(summary.source_file==path.name)&(summary.method==method)].iloc[0]
            assert row.attempted==row.completed==len(fits) and row.failures==0
            count=int(cover.sum()); width=float(np.median(upper-lower))
            ci=binomtest(count,len(fits)).proportion_ci(method='wilson')
            assert row.coverage_count==count
            assert abs(row.coverage_rate-count/len(fits))<1e-14
            assert abs(row.median_width-width)<1e-12
            assert max(abs(row.coverage_lo-ci.low),abs(row.coverage_hi-ci.high))<1e-12
            if method!='ols_on_grid':
                oldmethod='selected' if method=='selected_off_grid' else 'true_branch_oracle'
                old=original[(original.regime==regime)&(original.n==n)&(original.truth==truth)&(original.method==oldmethod)].iloc[0]
                assert old.coverage_count==count and abs(old.median_width-width)<1e-12
        delta=events['ols_on_grid'].astype(int)-events['selected_off_grid'].astype(int)
        pair=paired[(paired.regime==regime)&(paired.n==n)&(paired.truth==truth)].iloc[0]
        assert pair.pairs==len(fits)
        assert abs(pair.on_minus_off_coverage-delta.mean())<1e-14
        assert abs(pair.paired_mc_se-np.std(delta,ddof=1)/np.sqrt(len(fits)))<1e-14
        checked+=len(fits)
    assert checked==18000 and len(summary)==54 and len(paired)==18
    assert max(errors.values())<1e-10
    grid=summary[summary.method=='ols_on_grid']
    report=dict(status='PASS',paths_checked=checked,conditions=18,method_rows=54,
                original_off_grid_summaries_matched=36,
                full_observed_information_checks=checked,
                equivalent_data_least_squares_checks=equivalent_data,
                input_hashes_matched=18,maximum_absolute_errors=errors,
                pooled_on_grid_coverage=float(grid.coverage_count.sum()/grid.completed.sum()),
                empirical_simulations_added=0,structural_refits_added=0)
    (OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
