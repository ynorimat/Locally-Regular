"""Independent recomputation of new record summaries and population distances."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import norm
from nonrotation_example import construction

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'results/branch_diagnostics'


def observed(a,d,k):
    p=np.eye(2);q=np.zeros((2,2))
    for _ in range(k):
        q+=p@d@p.T;p=p@a
    # Independent vectorized Lyapunov solution, not the package routine.
    gamma=np.linalg.solve(np.eye(4)-np.kron(a,a),d.ravel()).reshape(2,2)
    return p,q,gamma


def stable_covariance_kl(s0,s1):
    chol=np.linalg.cholesky(s1)
    whitened=np.linalg.solve(chol,np.linalg.solve(chol,s0).T).T
    eig=np.linalg.eigvalsh((whitened+whitened.T)/2)
    return float(.5*np.sum((eig-1)-np.log1p(eig-1)))


def verify_records():
    cells=pd.read_csv(OUT/'branch_cells.csv')
    branches=pd.read_csv(OUT/'branch_widths.csv')
    rows=pd.read_csv(OUT/'branch_records.csv')
    old=pd.read_csv(BASE/'results/unknown_B_summary.csv')
    total=0;max_gap_error=0.;max_width_error=0.
    for path in sorted((BASE/'results/unknown_B_raw').glob('*.npz')):
        with np.load(path) as z:
            fits=z['fits'];n=int(z['n']);truth=int(z['truth']);regime=str(z['regime'])
            complete=np.all(fits[:,:,5]==1,axis=1);indices=np.flatnonzero(complete);f=fits[complete]
            direct=np.empty(f.shape[:2])
            for i,index in enumerate(indices):
                for j in range(3):
                    t=f[i,j];a=np.array([[t[6],t[7]],[t[0],t[8]]]);d=np.diag(t[9:11])
                    b,q,_=observed(a,d,3)
                    residual=z['s11'][index]-b@z['s10'][index].T-z['s10'][index]@b.T+b@z['s00'][index]@b.T
                    direct[i,j]=.5*(np.linalg.slogdet(q)[1]+np.trace(np.linalg.solve(q,residual)))
        selected=direct.argmin(axis=1)
        expected=rows[(rows.regime==regime)&(rows.n==n)&(rows.truth==truth)].sort_values('original_index')
        assert np.array_equal(selected,expected.selected_branch.to_numpy())
        assert np.array_equal(indices,expected.original_index.to_numpy())
        gaps=n*np.diff(np.sort(direct,axis=1)[:,:2],axis=1)[:,0]
        max_gap_error=max(max_gap_error,float(np.max(abs(gaps-expected.loglik_gap.to_numpy()))))
        cell=cells[(cells.regime==regime)&(cells.n==n)&(cells.truth==truth)].iloc[0]
        assert len(indices)==cell.completed and len(fits)-len(indices)==cell.failures
        for j in range(3):
            assert np.count_nonzero(selected==j)==cell[f'branch{j}_count']
            width=float(np.median(2*norm.ppf(.975)*f[:,j,1]))
            b=branches[(branches.regime==regime)&(branches.n==n)&(branches.truth==truth)&(branches.fitted_branch==j)].iloc[0]
            max_width_error=max(max_width_error,abs(width-cell[f'branch{j}_width']),abs(width-b.median_width))
        stored_gaps=n*np.diff(np.sort(f[:,:,2],axis=1)[:,:2],axis=1)[:,0]
        for quantile,name in [(.25,'gap_q25'),(.5,'gap_median'),(.75,'gap_q75')]:
            assert abs(np.quantile(stored_gaps,quantile)-cell[name])<1e-10
        original=old[(old.regime==regime)&(old.n==n)&(old.truth==truth)&(old.method=='selected')].iloc[0]
        assert expected.covered.sum()==original.coverage_count
        total+=len(indices)
    assert total==18000 and len(cells)==18 and len(branches)==54
    assert max_gap_error<1e-8 and max_width_error<1e-12
    return dict(paths_recomputed=total,direct_candidate_likelihoods=3*total,
                maximum_direct_loglik_gap_error=max_gap_error,maximum_width_error=max_width_error)


def verify_distances():
    data=pd.read_csv(OUT/'setting_distances.csv');max_error=0.
    for _,row in data.iterrows():
        def a(m):
            t=row.theta+2*np.pi*m/int(row.k)
            return row.r*np.array([[np.cos(t),-np.sin(t)],[np.sin(t),np.cos(t)]])
        e=row.epsilon;_,qs,gs=observed(a(int(row.source)),np.diag([1+e,1-e]),int(row.k))
        t=row.beta*e;_,qt,gt=observed(a(int(row.competitor)),np.diag([1+t,1-t]),int(row.k))
        direct=stable_covariance_kl(gs,gt)+int(row.n)*stable_covariance_kl(qs,qt)
        max_error=max(max_error,abs(direct-row.exact_path_KL))
        assert abs(max(0.,.9-np.sqrt(direct/2))-row.diameter_lower_probability)<1e-9
    assert max_error<1e-9
    return dict(distance_rows_verified=len(data),maximum_direct_path_KL_error=max_error)


def verify_nonrotation():
    roots,g,ds,b,delta,checks=construction()
    roots=[np.array(a,dtype=float) for a in roots];g=np.array(g,dtype=float)
    ds=[np.array(d,dtype=float) for d in ds];b=np.array(b,dtype=float)
    max_identity=max_information=max_path_error=0.
    for m,mult in [(2,1.),(0,.7)]:
        for eps in [-.05,-.01,0.,.01,.05]:
            d=ds[m]+mult*eps*np.diag([1.,-1.])
            bb,qq,gg=observed(roots[m],d,3)
            max_identity=max(max_identity,float(np.max(abs(bb-b))),float(np.max(abs(qq-(gg-b@gg@b.T)))))
            assert np.linalg.eigvalsh(d).min()>0
            if eps!=0:
                for j,a in enumerate(roots):
                    off=(gg-a@gg@a.T)[0,1]
                    assert abs(off)<1e-12 if j==m else abs(off)>1e-5
        # Finite-difference information in the original six coordinates.
        x=np.r_[roots[m].ravel(),np.diag(ds[m])];db=[];dq=[]
        for direction in np.eye(6):
            xp=x+1e-5*direction;xm=x-1e-5*direction
            bp,qp,_=observed(xp[:4].reshape(2,2),np.diag(xp[4:]),3)
            bm,qm,_=observed(xm[:4].reshape(2,2),np.diag(xm[4:]),3)
            db.append((bp-bm)/2e-5);dq.append((qp-qm)/2e-5)
        _,q,gamma=observed(roots[m],ds[m],3);qi=np.linalg.inv(q)
        info=np.array([[np.trace(qi@db[i]@gamma@db[j].T)+.5*np.trace(qi@dq[i]@qi@dq[j]) for j in range(6)] for i in range(6)])
        minimum=np.linalg.eigvalsh((info+info.T)/2).min()
        max_information=max(max_information,abs(minimum-checks[str(m)]['local_information_minimum']))
    for _,row in pd.read_csv(OUT/'nonrotation_distances.csv').iterrows():
        e=row.epsilon
        _,qm,gm=observed(roots[2],ds[2]+e*np.diag([1.,-1.]),3)
        _,qp,gp=observed(roots[0],ds[0]+.7*e*np.diag([1.,-1.]),3)
        direct=stable_covariance_kl(gm,gp)+int(row.n)*stable_covariance_kl(qm,qp)
        max_path_error=max(max_path_error,abs(direct-row.path_KL))
    assert max_identity<1e-12 and max_information<1e-8 and max_path_error<1e-10
    return dict(nonrotation_symbolic_checks=True,nonrotation_identity_max_error=max_identity,
                nonrotation_finite_difference_information_max_error=max_information,
                nonrotation_direct_path_KL_max_error=max_path_error)


def main():
    checks=verify_records();checks.update(verify_distances());checks.update(verify_nonrotation())
    checks['status']='all checks passed'
    (OUT/'verification.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))


if __name__=='__main__':main()
