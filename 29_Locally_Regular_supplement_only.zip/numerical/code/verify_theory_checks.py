"""Independent calculations auditing the new theory formulas and implementation.

The interval implementation is the object under test; reference calculations
use finite differences, residual products, and direct matrix equations.
Numerical neighborhood checks do not certify a radius or replace the proof.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import sympy as sp
from scipy.linalg import solve_discrete_lyapunov
from scipy.stats import norm
from uniform_grid import effect_gradient, interval_from_moments

BASE = Path(__file__).resolve().parents[1]
OUT = BASE/'results/theory_checks'


def finite_gradient(matrix, q):
    p = len(matrix)
    result = np.empty(p*p)
    step = 1e-6
    for column in range(p):
        for row in range(p):
            direction = np.zeros_like(matrix)
            direction[row, column] = step
            result[row+p*column] = (np.linalg.matrix_power(matrix+direction, q)[1, 0]
                                    - np.linalg.matrix_power(matrix-direction, q)[1, 0])/(2*step)
    return result


def grid_checks():
    rng = np.random.default_rng(20261001)
    max_gradient_error = 0.
    count = 0
    matrices = [.125*np.array([[0., -1.], [1., 0.]])]
    matrices += [rng.normal(size=(p, p))*.15 for p in (2, 3) for _ in range(12)]
    for matrix in matrices:
        for q in (1, 2, 3, 4, 6):
            value, gradient = effect_gradient(matrix, q)
            reference = finite_gradient(matrix, q)
            error = np.linalg.norm(gradient-reference)/max(np.linalg.norm(gradient), 1e-12)
            max_gradient_error = max(max_gradient_error, float(error))
            assert error < 2e-7
            assert value == np.linalg.matrix_power(matrix, q)[1, 0] or np.isclose(value, np.linalg.matrix_power(matrix, q)[1, 0])
            count += 1
    rows = pd.read_csv(OUT/'grid_population_checks.csv')
    for row in rows.itertuples():
        angle = np.pi/6+2*np.pi*row.branch/3
        a = .5*np.array([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])
        b = np.linalg.matrix_power(a, 3)
        gamma = solve_discrete_lyapunov(a, np.diag([1+row.t, 1-row.t]))
        covariance = gamma-b@gamma@b.T
        gradient = finite_gradient(b, row.q)
        variance = gradient@np.kron(np.linalg.inv(gamma), covariance)@gradient
        assert np.isclose(variance, row.asymptotic_variance, rtol=2e-7, atol=1e-18)
        assert row.gradient_norm > 0 and variance > 0
    saved = pd.read_csv(BASE/'results/grid_contrast/records.csv')
    maximum = 0.; paths = 0
    for path in sorted((BASE/'results/unknown_B_raw').glob('*.npz')):
        with np.load(path) as raw:
            expected = saved[saved.source_file == path.name].sort_values('original_index')
            for i, (x, yx, yy) in enumerate(zip(raw['s00'], raw['s10'], raw['s11'])):
                n = int(raw['n'])
                actual = interval_from_moments(x, yx, yy, n)
                b = np.linalg.solve(x, yx.T).T
                residual = yy-b@yx.T-yx@b.T+b@x@b.T
                se = np.sqrt(residual[1, 1]*np.linalg.solve(x, np.eye(2))[0, 0]/n)
                row = expected.iloc[i]
                assert actual['valid']
                differences = [actual['se']-se, actual['estimate']-b[1, 0],
                               actual['lower']-row.ols_on_grid_lower,
                               actual['upper']-row.ols_on_grid_upper]
                maximum = max(maximum, max(abs(float(v)) for v in differences))
                paths += 1
    assert maximum < 2e-12 and paths == 18000
    bad = interval_from_moments(np.zeros((2, 2)), np.eye(2), np.eye(2), 100)
    assert not bad['valid'] and bad['lower'] == -np.inf and bad['upper'] == np.inf
    return dict(gradient_comparisons=count, maximum_relative_gradient_error=max_gradient_error,
                population_variance_rows=len(rows), saved_paths_checked=paths,
                maximum_saved_interval_error=maximum, exceptional_event_checked=True)


def roots_at(b):
    values, vectors = np.linalg.eig(b.astype(complex))
    index = int(np.argmax(values.imag))
    lam = values[index]; v = vectors[:, index]
    basis = np.column_stack([v, v.conj()])
    roots = []
    for branch in range(3):
        mu = abs(lam)**(1/3)*np.exp(1j*(np.angle(lam)+2*np.pi*branch)/3)
        matrix = basis@np.diag([mu, mu.conjugate()])@np.linalg.inv(basis)
        assert abs(matrix.imag).max() < 1e-12
        roots.append(matrix.real)
    return roots


def information(a, d):
    gamma = solve_discrete_lyapunov(a, d)
    b = a@a@a
    q = sum(np.linalg.matrix_power(a, j)@d@np.linalg.matrix_power(a.T, j) for j in range(3))
    inverse = np.linalg.inv(q)
    derivatives = []
    for coordinate in range(6):
        h = np.zeros((2, 2)); k = np.zeros((2, 2))
        if coordinate < 4:
            h.flat[coordinate] = 1
        else:
            k[coordinate-4, coordinate-4] = 1
        db = h@a@a+a@h@a+a@a@h
        dq = np.zeros((2, 2))
        for j in range(3):
            power = np.linalg.matrix_power(a, j)
            derivative = sum((np.linalg.matrix_power(a, u)@h@np.linalg.matrix_power(a, j-1-u)
                              for u in range(j)), np.zeros((2, 2)))
            dq += derivative@d@power.T+power@d@derivative.T+power@k@power.T
        derivatives.append((db, dq))
    return np.array([[np.trace(inverse@dbi@gamma@dbj.T)+.5*np.trace(inverse@dqi@inverse@dqj)
                      for dbj, dqj in derivatives] for dbi, dqi in derivatives])


def persistence_checks():
    rational = sp.Rational; root = sp.sqrt(3)
    a0 = sp.Matrix([[root/4+rational(1, 20), -rational(13, 50)],
                    [rational(1, 4), root/4-rational(1, 20)]])
    a2 = sp.Matrix([[-rational(1, 10), rational(13, 25)],
                    [-rational(1, 2), rational(1, 10)]])
    x, y, z = sp.symbols('x y z'); g = sp.Matrix([[x, y], [y, z]])
    mapping = sp.Matrix([x+z, (g-a0*g*a0.T)[0, 1], (g-a2*g*a2.T)[0, 1]]).jacobian([x, y, z])
    determinant = sp.simplify(mapping.det())
    assert sp.simplify(determinant+6477*root/40000+rational(9, 8000)) == 0
    b0 = np.array(a0**3, dtype=float)
    transitions = [b0]
    for index in range(4):
        for step in (-.001, -.0001, .0001, .001):
            b = b0.copy(); b.flat[index] += step; transitions.append(b)
    basis = [np.array([[1., 0], [0, 0]]), np.array([[0., 1], [1, 0]]), np.array([[0., 0], [0, 1]])]
    min_information = np.inf; min_gap = np.inf; max_cube_error = 0.
    min_cross_slope = np.inf; min_other_intercept = np.inf; min_innovation = np.inf
    e = np.diag([1., -1.])
    for b in transitions:
        roots = roots_at(b)
        mapping = np.array([[np.trace(h) for h in basis]]+
                           [[(h-roots[j]@h@roots[j].T)[0, 1] for h in basis] for j in (0, 2)])
        values = np.linalg.solve(mapping, [8/3, 0, 0])
        gamma = sum(v*h for v, h in zip(values, basis))
        assert np.linalg.eigvalsh(gamma).min() > 0
        min_gap = min(min_gap, roots[0][1, 0]-roots[2][1, 0])
        assert roots[0][1, 0] > 0 > roots[2][1, 0]
        for j, scale in ((0, .7), (2, 1.)):
            a = roots[j]; d = gamma-a@gamma@a.T
            assert abs(d[0, 1]) < 1e-12 and abs(a[0, 0]-a[1, 1]) > .05
            max_cube_error = max(max_cube_error, float(abs(a@a@a-b).max()))
            v = solve_discrete_lyapunov(a, scale*e)
            other = roots[2-j]
            min_cross_slope = min(min_cross_slope, abs((v-other@v@other.T)[0, 1]))
            intercept = (gamma-roots[1]@gamma@roots[1].T)[0, 1]
            min_other_intercept = min(min_other_intercept, abs(intercept))
            for epsilon in (-.025, 0., .025):
                perturbed = d+scale*epsilon*e
                min_innovation = min(min_innovation, float(np.linalg.eigvalsh(perturbed).min()))
                eig = np.linalg.eigvalsh(information(a, perturbed)).min()
                min_information = min(min_information, float(eig))
                if epsilon:
                    stationary = gamma+epsilon*v
                    for candidate in range(3):
                        if candidate != j:
                            wrong = stationary-roots[candidate]@stationary@roots[candidate].T
                            assert abs(wrong[0, 1]) > 1e-4
    assert max_cube_error < 1e-12 and min_cross_slope > .1
    assert min_other_intercept > .1 and min_innovation > .5 and min_information > .01
    return dict(exact_linear_system_determinant=str(determinant), transitions_checked=len(transitions),
                maximum_cube_error=max_cube_error, minimum_sampled_effect_gap=float(min_gap),
                minimum_sampled_information_eigenvalue=min_information,
                minimum_sampled_cross_root_slope=float(min_cross_slope),
                minimum_sampled_root1_intercept=float(min_other_intercept),
                minimum_sampled_innovation_eigenvalue=min_innovation,
                scope='Finite deterministic checks of proof premises; no neighborhood radius is certified.')


def main():
    report = dict(status='passed', grid=grid_checks(), persistence=persistence_checks(),
                  empirical_paths_added=0, structural_optimizer_fits_added=0)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT/'verification.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
