"""Recompute the Angle-cell retention counts and median diameters in Table 4."""
from pathlib import Path
from statistics import median, NormalDist
import csv,json
BASE=Path(__file__).resolve().parent
def rows(path):
    with (BASE/path).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def match(r):return r['setting'].lower()=='angle' and r['regime']=='fixed_e02' and r['n']=='32000' and r['truth']=='2'
local=[r for r in rows('results/sensitivity_union/records.csv') if match(r) and r['method']=='screened_union']
one=[r for r in rows('results/method_comparisons/one_step_records.csv') if match(r)]
assert len(local)==len(one)==500
assert {(r['source_file'],r['record']) for r in local}=={(r['source_file'],r['record']) for r in one}
threshold=NormalDist().inv_cdf(.9875)**2
summary={};kept={}
for label,records in [('local_fit',local),('one_step',one)]:
    retained={};diameters=[];both=0;empty=0
    for r in records:
        assert int(r['fallback'])==0
        ids=tuple(j for j in range(3) if float(r[f'lr{j}'])<=threshold)
        retained[int(r['record'])]=ids
        intervals=[(float(r[f'lower{j}']),float(r[f'upper{j}'])) for j in ids]
        if intervals:
            lo=min(a for a,b in intervals);hi=max(b for a,b in intervals)
            d=hi-lo;both+=lo<0<hi
        else:d=0;empty+=1
        assert abs(d-float(r['diameter']))<1e-12
        diameters.append(d)
    summary[label]={'paths':len(records),'both_signs':both,'empty':empty,'median_diameter':median(diameters)}
    kept[label]=retained
changed=sorted(i for i in kept['local_fit'] if kept['local_fit'][i]!=kept['one_step'][i])
assert changed==[23,62]
assert summary['local_fit']['both_signs']==251 and summary['one_step']['both_signs']==249
assert summary['local_fit']['empty']==summary['one_step']['empty']==3
assert f"{summary['local_fit']['median_diameter']:.3f}"=='0.700'
assert f"{summary['one_step']['median_diameter']:.3f}"=='0.082'
report={'status':'passed','setting':'Angle','n':32000,'regime':'fixed_e02','truth':2,
        'summary':summary,'changed_retention_record_indices':changed,
        'scope':'Recomputed from saved per-path likelihood ratios and interval endpoints; no new simulation or optimization.'}
if __name__=='__main__':print(json.dumps(report,indent=2))
