"""Independent audit of all new fits, counts, generators, and exported table."""
from pathlib import Path
import csv
import hashlib
import json
import numpy as np
from scipy.linalg import solve_discrete_lyapunov
from scipy.stats import norm

BASE = Path(__file__).resolve().parents[1]
OUT = BASE/'results/nonrotation_mc'


def model(x):
    a=x[:4].reshape(2,2); d=np.diag(x[4:])
    b=np.linalg.matrix_power(a,3)
    q=sum(np.linalg.matrix_power(a,j)@d@np.linalg.matrix_power(a,j).T for j in range(3))
    return b,q


def se_fd(x,n):
    b,q=model(x); qi=np.linalg.inv(q)
    g=solve_discrete_lyapunov(x[:4].reshape(2,2),np.diag(x[4:]))
    db=[];dq=[]
    for e in np.eye(6):
        bp,qp=model(x+1e-5*e);bm,qm=model(x-1e-5*e)
        db.append((bp-bm)/2e-5);dq.append((qp-qm)/2e-5)
    info=np.array([[np.trace(qi@db[i]@g@db[j].T)+.5*np.trace(qi@dq[i]@qi@dq[j]) for j in range(6)] for i in range(6)])
    return np.sqrt(np.linalg.inv(info)[2,2]/n)


def main():
    protocol_bytes=(BASE/'nonrotation_mc_protocol.json').read_bytes(); protocol=json.loads(protocol_bytes)
    with (OUT/'summary.csv').open(newline='') as f: summary=list(csv.DictReader(f))
    with (OUT/'path_events.csv').open(newline='') as f: records=list(csv.DictReader(f))
    # Construct the matrices independently, then solve the three defining linear
    # equations in symmetric coordinates, rather than importing the generator.
    shear=np.array([[1.,.2],[0.,1.]])
    roots=[]
    for j in range(3):
        t=np.pi/6+2*np.pi*j/3
        roots.append(shear@(.5*np.array([[np.cos(t),-np.sin(t)],[np.sin(t),np.cos(t)]]))@np.linalg.inv(shear))
    roots=np.array(roots)
    basis=np.array([[[1.,0.],[0.,0.]],[[0.,1.],[1.,0.]],[[0.,0.],[0.,1.]]])
    coefficients=np.array([[1.,0.,1.]]+[[float((v-roots[j]@v@roots[j].T)[0,1]) for v in basis] for j in (0,2)])
    g0=np.einsum('i,ijk->jk',np.linalg.solve(coefficients,[8/3,0,0]),basis)
    maxima=dict(objective=0.,se=0.,ols=0.,moments=0.,score_fd=0.)
    total=0; failures=0; migrations=0; fd_count=0
    assert len(summary)==12 and len(records)==2000
    files=sorted((OUT/'raw').glob('*.npz')); assert len(files)==4
    table=(OUT/'table.tex').read_text()
    table_rows={}
    for line in table.splitlines():
        fields=[v.strip() for v in line.removesuffix(r'\\').split('&')]
        if len(fields)==6 and fields[0] in (r'$1/n$',r'$1/20$'):
            table_rows[(fields[0],fields[1])]=fields[2:]
    assert len(table_rows)==4
    for regime,label in [('inverse_n',r'$1/n$'),('fixed_e005',r'$1/20$')]:
        for truth,sign in [(2,'Negative'),(0,'Positive')]:
            cell={r['method']:r for r in summary if r['regime']==regime and int(r['truth'])==truth}
            sel=cell['selected'];p=int(sel['coverage_count'])/500;critical=norm.ppf(.975)
            den=1+critical**2/500;center=(p+critical**2/1000)/den
            half=critical*np.sqrt(p*(1-p)/500+critical**2/(4*500**2))/den
            expected=[f'{100*p:.1f} [{100*(center-half):.1f}, {100*(center+half):.1f}]',
                f"{100*int(cell['true_branch_oracle']['coverage_count'])/500:.1f}",
                f"{100*int(cell['on_grid']['coverage_count'])/500:.1f}",
                f"{100*int(sel['wrong_count'])/500:.1f}"]
            assert table_rows[(label,sign)]==expected
    for path in files:
        with np.load(path) as z:
            fits=z['fits'];n=int(z['n']);truth=int(z['truth']);ri=int(z['regime_index']);regime=str(z['regime']);epsilon=float(z['epsilon'])
            reps=len(fits);total+=reps
            assert n==32000 and reps==500 and regime==protocol['regimes'][ri] and epsilon==protocol['epsilon'][ri]
            assert str(z['protocol_sha256'])==hashlib.sha256(protocol_bytes).hexdigest()
            a=roots[truth];d=g0-a@g0@a.T+epsilon*(.7 if truth==0 else 1.)*np.diag([1.,-1.])
            assert np.allclose(a,z['a'],atol=1e-14) and np.allclose(d,z['d'],atol=1e-14)
            assert np.max(abs(d-np.diag(np.diag(d))))<1e-14 and np.linalg.eigvalsh(d).min()>0
            # Independently replay all stationary observed paths from the protocol,
            # with algebraically different covariance formulas; no fitting rerun.
            b=a@a@a;g=solve_discrete_lyapunov(a,d);q=g-b@g@b.T
            rng=np.random.default_rng(np.random.SeedSequence([protocol['base_seed'],n,ri,truth]))
            state=rng.standard_normal((reps,2))@np.linalg.cholesky(g).T
            accum=np.zeros((3,reps,2,2));chol=np.linalg.cholesky(q)
            for _ in range(n):
                nxt=state@b.T+rng.standard_normal((reps,2))@chol.T
                accum[0]+=np.einsum('ni,nj->nij',state,state)
                accum[1]+=np.einsum('ni,nj->nij',nxt,state)
                accum[2]+=np.einsum('ni,nj->nij',nxt,nxt)
                state=nxt
            for i,key in enumerate(['s00','s10','s11']):
                maxima['moments']=max(maxima['moments'],float(np.max(abs(accum[i]/n-z[key]))))
            chosen=np.argmin(fits[:,:,2],axis=1);valid=fits[:,:,5]==1;complete=valid.all(axis=1)
            nearest=np.empty((reps,3),int)
            grid_est=[];grid_se=[]
            for i in range(reps):
                s00,s10,s11=(z[k][i] for k in ['s00','s10','s11'])
                # A four-row equivalent data set realizes the full second moments.
                scatter=np.block([[s00,s10.T],[s10,s11]])
                pseudo=np.sqrt(n)*np.linalg.cholesky(scatter).T
                xx,yy=pseudo[:,:2],pseudo[:,2:]
                coeff=np.linalg.lstsq(xx,yy,rcond=None)[0];resid=yy-xx@coeff
                grid_est.append(coeff[0,1]);grid_se.append(np.sqrt((resid.T@resid/n)[1,1]*np.linalg.inv(xx.T@xx)[0,0]))
                maxima['ols']=max(maxima['ols'],float(np.max(abs(coeff.T-s10@np.linalg.inv(s00)))))
                for j in range(3):
                    f=fits[i,j];x=np.array([f[6],f[7],f[0],f[8],f[9],f[10]])
                    af=x[:4].reshape(2,2);bf,qf=model(x)
                    residual=s11-bf@s10.T-s10@bf.T+bf@s00@bf.T
                    obj=.5*(np.linalg.slogdet(qf)[1]+np.trace(np.linalg.solve(qf,residual)))
                    maxima['objective']=max(maxima['objective'],abs(obj-f[2]))
                    nearest[i,j]=np.argmin(np.linalg.norm(roots-af,axis=(1,2)))
                    if i<5:
                        maxima['se']=max(maxima['se'],abs(se_fd(x,n)-f[1]));fd_count+=1
                        def objective_log(v):
                            bb,qq=model(np.r_[v[:4],np.exp(v[4:])])
                            rr=s11-bb@s10.T-s10@bb.T+bb@s00@bb.T
                            return .5*(np.linalg.slogdet(qq)[1]+np.trace(np.linalg.solve(qq,rr)))
                        lx=np.r_[x[:4],np.log(x[4:])]
                        score=np.array([(objective_log(lx+1e-5*e)-objective_log(lx-1e-5*e))/2e-5 for e in np.eye(6)])
                        maxima['score_fd']=max(maxima['score_fd'],abs(np.max(abs(score))-f[3]))
                    assert np.linalg.eigvals(af).__abs__().max()<1 and np.min(x[4:])>0 and np.isfinite(f[1])
            ii=np.arange(reps); critical=norm.ppf(.975)
            specs=[('selected',fits[ii,chosen,0],fits[ii,chosen,1],complete,a[1,0]),
                   ('true_branch_oracle',fits[:,truth,0],fits[:,truth,1],valid[:,truth],a[1,0]),
                   ('on_grid',np.array(grid_est),np.array(grid_se),np.ones(reps,bool),b[1,0])]
            cellrecords=sorted([r for r in records if r['regime']==regime and int(r['truth'])==truth],key=lambda r:int(r['path']))
            assert len(cellrecords)==reps
            for method,est,se,ok,target in specs:
                low,high=est-critical*se,est+critical*se
                ev=dict(valid=ok,coverage=ok&(low<=target)&(target<=high),wrong=ok&((low>0) if target<0 else (high<0)))
                row=next(r for r in summary if r['regime']==regime and int(r['truth'])==truth and r['method']==method)
                assert int(row['valid'])==int(ok.sum()) and int(row['failures'])==int((~ok).sum())
                failures+=int((~ok).sum())
                assert abs(float(row['median_width'])-np.median(2*critical*se[ok]))<1e-10
                for name in ['coverage','wrong']:
                    count=int(ev[name].sum());assert count==int(row[name+'_count'])
                    phat=count/reps;den=1+critical**2/reps;center=(phat+critical**2/(2*reps))/den
                    half=critical*np.sqrt(phat*(1-phat)/reps+critical**2/(4*reps**2))/den
                    assert abs(float(row[name+'_lo'])-(center-half))<1e-12 and abs(float(row[name+'_hi'])-(center+half))<1e-12
                for i,r in enumerate(cellrecords):
                    for key,values in ev.items(): assert int(r[method+'_'+key])==int(values[i])
                    assert int(r['selected_start'])==chosen[i]
                    for j in range(3): assert int(r[f'nearest_root_start_{j}'])==nearest[i,j]
                for j in range(3): assert int(row[f'selected_start_{j}_count'])==int(((chosen==j)&complete).sum())
                assert int(row['start_label_migrations'])==int(((nearest!=np.arange(3))&valid).sum())
                assert int(row['oracle_migrations'])==int(((nearest[:,truth]!=truth)&valid[:,truth]).sum())
            migrations+=int(((nearest!=np.arange(3))&valid).sum())
            assert complete.all() and np.max(fits[:,:,3])<1e-6
    assert total==2000 and fd_count==60 and failures==0 and migrations==0
    assert maxima['objective']<1e-11 and maxima['se']<1e-8 and maxima['ols']<1e-12 and maxima['moments']<1e-11 and maxima['score_fd']<1e-7
    report=dict(status='all checks passed',paths=total,candidate_fits=3*total,finite_difference_audited_fits=fd_count,
        replayed_stationary_paths=total,summary_rows=len(summary),path_event_rows=len(records),
        interval_failures=failures,nearest_root_migrations=migrations,max_errors=maxima,
        exported_table_rows_verified=4,exported_table_percentages_verified=24,
        limitations='Numerical audit, not formal proof or a global optimization certificate.')
    (OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__': main()
