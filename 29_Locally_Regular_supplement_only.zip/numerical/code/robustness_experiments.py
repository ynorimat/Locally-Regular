"""Predefined optimizer audit and limited within-family sensitivity checks.

The optimizer audit uses unrestricted A and positive
diagonal D, with a known sampling interval and known zero mean. No global-optimum
or uniform-confidence guarantee is asserted by this diagnostic.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.linalg import solve_discrete_lyapunov
from scipy.optimize import minimize
from scipy.stats import norm
from rotation_family import RotationFamily,coarsen,local_information
from unknown_transition import objective as original_objective, wilson

BASE=Path(__file__).resolve().parents[1]
E=np.zeros((6,2,2))
for i in range(4):E[i].flat[i]=1.
SETTINGS=[dict(name='radius',k=3,r=.7,theta=np.pi/6,negative=2,positive=0),
          dict(name='angle',k=3,r=.5,theta=np.pi/5,negative=2,positive=0),
          dict(name='sampling',k=5,r=.7,theta=np.pi/10,negative=3,positive=0)]
PROTOCOL=dict(audit_seed=202609301,audit_per_cell=20,jitters_per_root=4,
              jitter_A_sd=.04,jitter_log_variance_sd=.15,
              alternate_method='L-BFGS-B without bounds, original OLS-root starts',
              likelihood_material_tolerance=1e-6,sensitivity_seed=202609302,
              sensitivity_reps=500,sizes=[8000,32000],regimes=['inverse_n','fixed_e02'],
              settings=SETTINGS,scope='Three specified rotation families; no unrestricted-VAR generalization')


def model(x,k):
    a=x[:4].reshape(2,2);d=np.diag(np.exp(x[4:]));dd=np.zeros_like(E)
    dd[4,0,0]=d[0,0];dd[5,1,1]=d[1,1]
    p=np.eye(2);dp=np.zeros_like(E);q=np.zeros((2,2));dq=np.zeros_like(E)
    for _ in range(k):
        q+=p@d@p.T
        dq+=dp@d@p.T+p@dd@p.T+p@d@dp.transpose(0,2,1)
        dp=dp@a+p@E
        p=p@a
    return p,q,dp,dq


def objective(x,s00,s10,s11,k):
    b,q,db,dq=model(x,k);qi=np.linalg.inv(q)
    res=s11-b@s10.T-s10@b.T+b@s00@b.T
    f=.5*(np.linalg.slogdet(q)[1]+np.trace(qi@res))
    gq=.5*(qi-qi@res@qi);gb=qi@(b@s00-s10)
    grad=np.einsum('ij,kij->k',gq,dq)+np.einsum('ij,kij->k',gb,db)
    return float(f),grad


def starts(s00,s10,s11,k):
    b=np.linalg.solve(s00,s10.T).T;q=s11-b@s10.T
    u=np.trace(b)/2;v2=np.linalg.det(b)-u*u
    if v2<=0:return []
    v=np.sqrt(v2);J=(b-u*np.eye(2))/v;rho=np.hypot(u,v)**(1/k);phi=np.arctan2(v,u)
    result=[]
    for j in range(k):
        a=rho*(np.cos((phi+2*np.pi*j)/k)*np.eye(2)+np.sin((phi+2*np.pi*j)/k)*J)
        basis=np.stack([coarsen(a,np.diag([1.,0.]),k)[1].ravel(),
                        coarsen(a,np.diag([0.,1.]),k)[1].ravel()],axis=1)
        dv=np.maximum(np.linalg.lstsq(basis,q.ravel(),rcond=None)[0],.05)
        result.append(np.r_[a.ravel(),np.log(dv)])
    return result


def fit(start,s00,s10,s11,n,k,method='BFGS'):
    opts=dict(gtol=1e-9,maxiter=500)
    if method=='L-BFGS-B':opts.update(ftol=1e-15,maxls=50,maxiter=1000)
    res=minimize(objective,start,args=(s00,s10,s11,k),jac=True,method=method,options=opts)
    score=np.linalg.norm(res.jac,ord=np.inf);a=res.x[:4].reshape(2,2);d=np.diag(np.exp(res.x[4:]))
    stable=np.max(np.abs(np.linalg.eigvals(a)))<1.;se=np.nan
    if stable:
        info=local_information(a,d,k)
        if np.linalg.eigvalsh(info).min()>1e-10:se=np.sqrt(np.linalg.inv(info)[2,2]/n)
    accepted=stable and score<1e-6 and np.isfinite(se)
    # The first eleven fields match the primary fits; optimizer evaluations form a twelfth field.
    return np.array([a[1,0],se,res.fun,score,stable,accepted,a[0,0],a[0,1],a[1,1],d[0,0],d[1,1],res.nfev])


def register_protocol():
    folder=BASE/'results/robustness';folder.mkdir(exist_ok=True)
    p=folder/'protocol.json';serialized=json.dumps(PROTOCOL,indent=2)+'\n'
    if p.exists():assert p.read_text()==serialized
    else:p.write_text(serialized)
    return folder


def audit():
    out=register_protocol();rng=np.random.default_rng(PROTOCOL['audit_seed']);selection=[]
    # Select every record before starting the audit; sampling is independent of its result.
    paths=sorted((BASE/'results/unknown_B_raw').glob('*.npz'))
    for path in paths:
        with np.load(path) as z:count=len(z['fits'])
        selection.append(dict(file=path.name,indices=sorted(rng.choice(count,20,replace=False).tolist())))
    (out/'audit_selection.json').write_text(json.dumps(selection,indent=2)+'\n')
    for cell_index,item in enumerate(selection):
        with np.load(BASE/'results/unknown_B_raw'/item['file']) as z:
            n=int(z['n']);truth=int(z['truth']);indices=np.array(item['indices']);regime=str(z['regime'])
            original=z['fits'][indices];s00=z['s00'][indices];s10=z['s10'][indices];s11=z['s11'][indices]
        jitters=np.empty((20,12,12));alternate=np.empty((20,3,12));initial=np.empty((20,12,6))
        for i in range(20):
            initials=starts(s00[i],s10[i],s11[i],3);assert len(initials)==3
            for branch,start in enumerate(initials):
                alternate[i,branch]=fit(start,s00[i],s10[i],s11[i],n,3,'L-BFGS-B')
                for j in range(4):
                    perturb=rng.normal(size=6)*np.array([.04]*4+[.15]*2)
                    x0=start+perturb;idx=branch*4+j;initial[i,idx]=x0
                    jitters[i,idx]=fit(x0,s00[i],s10[i],s11[i],n,3)
        np.savez_compressed(out/('audit_'+item['file']),indices=indices,original=original,jitter_fits=jitters,
                            alternate_fits=alternate,jitter_starts=initial,n=n,truth=truth,regime=regime,
                            s00=s00,s10=s10,s11=s11)
        print('audit',item['file'],'done',flush=True)
    summarize_audit()


def summarize_audit():
    out=BASE/'results/robustness';rows=[]
    roots=RotationFamily().roots
    for path in sorted(out.glob('audit_*.npz')):
        with np.load(path) as z:
            orig=z['original'];jit=z['jitter_fits'];alt=z['alternate_fits'];n=int(z['n']);truth=int(z['truth']);regime=str(z['regime']);indices=z['indices']
        for i in range(len(orig)):
            candidates=np.concatenate([orig[i],jit[i,:,:11],alt[i,:,:11]],axis=0)
            valid=candidates[:,5]==1
            assert valid[:3].all()
            old=orig[i,np.argmin(orig[i,:,2])];new=candidates[np.argmin(np.where(valid,candidates[:,2],np.inf))]
            av=alt[i,:,5]==1;altbest=alt[i,np.argmin(np.where(av,alt[i,:,2],np.inf))] if av.any() else np.full(12,np.nan)
            def classify(f):
                a=np.array([[f[6],f[7]],[f[0],f[8]]]);return int(np.argmin(np.linalg.norm(roots-a,axis=(1,2))))
            target=roots[truth,1,0]
            row=dict(file=path.name,replication=i,original_index=int(indices[i]),n=n,truth=truth,regime=regime,
                     loglik_improvement=float(n*(old[2]-new[2])),old_branch=classify(old),new_branch=classify(new),
                     endpoint_max_change=float(max(abs((old[0]-1.96*old[1])-(new[0]-1.96*new[1])),abs((old[0]+1.96*old[1])-(new[0]+1.96*new[1])))),
                     jitter_failed=int((jit[i,:,5]!=1).sum()),alternate_failed=int((alt[i,:,5]!=1).sum()),
                     alternate_loglik_difference=float(n*(old[2]-altbest[2])) if av.any() else np.nan)
            for name,f in [('original',old),('augmented',new),('alternate',altbest)]:
                low=f[0]-norm.ppf(.975)*f[1];high=f[0]+norm.ppf(.975)*f[1]
                row[name+'_covered']=bool(low<=target<=high)
                row[name+'_wrong']=bool(low>0) if target<0 else bool(high<0)
            rows.append(row)
    df=pd.DataFrame(rows);df.to_csv(out/'audit_records.csv',index=False)
    result=dict(audited_paths=len(df),extra_BFGS_fits=12*len(df),alternate_fits=3*len(df),
                max_loglik_improvement=float(df.loglik_improvement.max()),
                material_improvement_count=int((df.loglik_improvement>1e-6).sum()),
                changed_branch_count=int((df.old_branch!=df.new_branch).sum()),
                changed_coverage_count=int((df.original_covered!=df.augmented_covered).sum()),
                changed_wrong_sign_count=int((df.original_wrong!=df.augmented_wrong).sum()),
                alternate_changed_coverage_count=int((df.original_covered!=df.alternate_covered).sum()),
                alternate_changed_wrong_sign_count=int((df.original_wrong!=df.alternate_wrong).sum()),
                max_endpoint_change=float(df.endpoint_max_change.max()),
                max_abs_alternate_loglik_difference=float(df.alternate_loglik_difference.abs().max()),
                failed_jitter_fits=int(df.jitter_failed.sum()),failed_alternate_fits=int(df.alternate_failed.sum()),
                scope='Finite stratified audit; not a certificate of global optimization')
    (out/'audit_summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)


def simulate(family,branch,anisotropy,n,reps,seed):
    rng=np.random.default_rng(seed);gamma,q=family.covariance(branch,anisotropy)
    z=rng.standard_normal((reps,2))@np.linalg.cholesky(gamma).T;chol=np.linalg.cholesky(q)
    s00=np.zeros((reps,2,2));s10=s00.copy();s11=s00.copy()
    for _ in range(n):
        nxt=z@family.B.T+rng.standard_normal((reps,2))@chol.T
        s00+=z[:,:,None]*z[:,None,:];s10+=nxt[:,:,None]*z[:,None,:];s11+=nxt[:,:,None]*nxt[:,None,:];z=nxt
    return s00/n,s10/n,s11/n


def sensitivity():
    out=register_protocol();folder=out/'sensitivity_raw';folder.mkdir(exist_ok=True)
    for setting_index,s in enumerate(SETTINGS):
        fam=RotationFamily(s['k'],s['r'],s['theta']);beta=fam.beta(s['negative'],s['positive'])
        assert fam.collinearity_margin()>1e-5 and abs(np.sin(fam.k*fam.theta))>1e-5 and beta!=0
        for n in PROTOCOL['sizes']:
            for ri,regime in enumerate(PROTOCOL['regimes']):
                epsilon=1/n if regime=='inverse_n' else .2
                for truth in (s['negative'],s['positive']):
                    t=epsilon if truth==s['negative'] else beta*epsilon
                    seed=np.random.SeedSequence([PROTOCOL['sensitivity_seed'],setting_index,n,ri,truth])
                    reps=PROTOCOL['sensitivity_reps'];s00,s10,s11=simulate(fam,truth,t,n,reps,seed)
                    fits=np.full((reps,fam.k,12),np.nan)
                    for i in range(reps):
                        for j,x0 in enumerate(starts(s00[i],s10[i],s11[i],fam.k)):
                            fits[i,j]=fit(x0,s00[i],s10[i],s11[i],n,fam.k)
                    np.savez_compressed(folder/f'{s["name"]}_{regime}_n{n}_truth{truth}.npz',
                        s00=s00,s10=s10,s11=s11,fits=fits,n=n,truth=truth,regime=regime,epsilon=epsilon,
                        anisotropy=t,beta=beta,k=fam.k,r=fam.r,theta=fam.theta,setting=s['name'])
                    print('sensitivity',s['name'],regime,n,truth,'complete',int(np.all(fits[:,:,5]==1,axis=1).sum()),'/',reps,flush=True)
    summarize_sensitivity()


def summarize_sensitivity():
    out=BASE/'results/robustness';rows=[]
    for path in sorted((out/'sensitivity_raw').glob('*.npz')):
        with np.load(path) as z:
            fits=z['fits'];n=int(z['n']);truth=int(z['truth']);k=int(z['k']);r=float(z['r']);theta=float(z['theta'])
            regime=str(z['regime']);setting=str(z['setting']);t=float(z['anisotropy']);beta=float(z['beta'])
        complete=np.all(fits[:,:,5]==1,axis=1);valid=fits[complete];R=len(valid);assert R>0
        target=RotationFamily(k,r,theta).roots[truth,1,0];choice=valid[:,:,2].argmin(axis=1)
        for method,index in [('selected',choice),('true_branch_oracle',np.full(R,truth))]:
            f=valid[np.arange(R),index];lo=f[:,0]-norm.ppf(.975)*f[:,1];hi=f[:,0]+norm.ppf(.975)*f[:,1]
            row=dict(setting=setting,k=k,r=r,theta=theta,n=n,regime=regime,truth=truth,target=target,
                     anisotropy=t,beta=beta,method=method,attempted=len(fits),completed=R,failures=len(fits)-R,
                     median_width=float(np.median(hi-lo)))
            for name,v in [('coverage',(lo<=target)&(target<=hi)),('wrong',(lo>0) if target<0 else (hi<0)),('declare',(lo>0)|(hi<0))]:
                count=int(v.sum());lower,upper=wilson(count,R)
                row.update({name+'_count':count,name+'_rate':count/R,name+'_lo':lower,name+'_hi':upper})
            rows.append(row)
    df=pd.DataFrame(rows);df.to_csv(out/'sensitivity_summary.csv',index=False)
    print(df[['setting','regime','n','truth','method','completed','coverage_rate','wrong_rate','median_width']].to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['protocol','audit','sensitivity','summarize'])
    arg=parser.parse_args()
    if arg.mode=='protocol':print(register_protocol())
    elif arg.mode=='audit':audit()
    elif arg.mode=='sensitivity':sensitivity()
    else:summarize_audit();summarize_sensitivity()
