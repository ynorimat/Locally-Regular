"""Reproduce numerical results without a LaTeX installation."""
from pathlib import Path
import argparse
import csv
import hashlib
import subprocess
import sys

BASE = Path(__file__).resolve().parent
GROUPS = {
    'known': [('local_raw', 'calibration_*.npz', 16),
              ('local_raw', 'evaluation_*.npz', 32), ('fixed_raw', '*.npz', 8)],
    'unknown': [('unknown_B_raw', '*.npz', 18)],
    'robustness': [('robustness', 'audit_*.npz', 18),
                   ('robustness/sensitivity_raw', '*.npz', 24)],
    'nonrotation': [('nonrotation_mc/raw', '*.npz', 4)],
}
VERIFIERS = [
    'verify_generalization.py', 'verify_simulation.py', 'verify_kl_moments.py',
    'verify_records.py', 'verify_candidate.py', 'verify_unknown_transition.py',
    'verify_robustness.py', 'verify_branch_diagnostics.py',
    'verify_selection_diagnostics.py', 'verify_grid_contrast.py',
    'verify_theory_checks.py', 'verify_nonrotation_mc.py', 'verify_varying_grid.py',
]


def run(script, *args):
    print('Running', script, *args, flush=True)
    subprocess.run([sys.executable, str(BASE / 'code' / script), *args],
                   cwd=BASE, check=True)


def require_records(*groups):
    missing = []
    for group in groups:
        for folder, pattern, count in GROUPS[group]:
            found = len(list((BASE / 'results' / folder).glob(pattern)))
            if found != count:
                missing.append(f'{folder}/{pattern}: {found}/{count}')
    if missing:
        raise SystemExit('This workflow requires the following additional raw records.\n'
                         + '\n'.join(missing)
                         + '\nRun python reproduce.py simulate-all, or the relevant '
                         'simulate-known/unknown/robustness stages in README.md.')


def check():
    """Check the distributed files before any regeneration overwrites them."""
    count = 0
    for line in (BASE / 'MANIFEST.sha256').read_text(encoding='utf-8').splitlines():
        digest, name = line.split('  ', 1)
        path = BASE / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise SystemExit(f'Changed or missing packaged file: {name}\n'
                             'Use a fresh extraction for the original-package integrity check.')
        count += 1
    print(f'PASS: {count} packaged files match their SHA-256 hashes.')
    with (BASE / 'OMITTED_RESULTS.csv').open(encoding='utf-8', newline='') as stream:
        omitted = list(csv.DictReader(stream))
    print(f'{len(omitted)} reproducible result files omitted; see OMITTED_RESULTS.csv.')
    print('No LaTeX installation or network download is needed by this entry point.')


def known():
    run('local_sequence_experiments.py', '--reps', '10000', '--calibration', '39999',
        '--seed', '20260923')
    run('equal_information.py', '--fixed-reps', '10000', '--seed', '20260924',
        '--regenerate-fixed')
    run('make_tables.py')


def unknown_outputs():
    require_records('unknown')
    run('unknown_transition.py', '--summarize')
    for script in ['branch_diagnostics.py', 'selection_diagnostics.py', 'grid_contrast.py']:
        run(script)


def unknown():
    run('unknown_transition.py', '--reps', '1000', '--seed', '20260930', '--workers', '1')
    unknown_outputs()


def robustness():
    require_records('unknown')
    run('robustness_experiments.py', 'audit')
    run('robustness_experiments.py', 'sensitivity')


def deterministic():
    run('nonrotation_example.py')
    run('uniform_grid.py')


def nonrotation():
    run('nonrotation_mc.py')
    run('nonrotation_mc_outputs.py')


def summarize():
    require_records('known', 'unknown', 'robustness', 'nonrotation')
    run('equal_information.py')
    run('make_tables.py')
    unknown_outputs()
    run('robustness_experiments.py', 'summarize')
    deterministic()
    run('nonrotation_mc.py', '--summarize')
    run('nonrotation_mc_outputs.py')


def export():
    """Optional figure/table assets, without compiling a manuscript."""
    for script in ['candidate_tables.py', 'make_figures.py',
                   'unknown_transition_outputs.py', 'robustness_outputs.py', 'manuscript_text.py',
                   'nonrotation_mc_outputs.py']:
        run(script)


def verify():
    require_records('known', 'unknown', 'robustness', 'nonrotation')
    if not (BASE / 'results/grid_contrast/records.csv').is_file():
        raise SystemExit('Run python reproduce.py summarize before the full verification.')
    for script in VERIFIERS:
        run(script)
    run('verify_submission.py')
    run('finite_sample_bounds.py')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('workflow', nargs='?', default='check', choices=[
        'check', 'verify-light', 'verify', 'simulate-known', 'simulate-unknown',
        'simulate-robustness', 'simulate-all', 'summarize', 'export', 'verify-manuscript',
        'simulate-nonrotation', 'verify-nonrotation', 'verify-varying-grid',
        'verify-submission', 'verify-finite-bounds', 'branch-union', 'verify-branch-union',
        'sensitivity-union', 'verify-sensitivity-union', 'method-comparisons', 'verify-method-comparisons',
    ])
    choice = parser.parse_args().workflow
    if choice == 'check':
        check()
        return
    (BASE / 'results').mkdir(exist_ok=True)
    (BASE / 'figures').mkdir(exist_ok=True)
    if choice == 'verify-light':
        for script in VERIFIERS[:3]:
            run(script)
        deterministic()
        run('verify_varying_grid.py')
    elif choice == 'verify-varying-grid':
        run('verify_varying_grid.py')
    elif choice == 'verify-finite-bounds':
        run('finite_sample_bounds.py')
    elif choice == 'branch-union':
        run('branch_union.py')
        run('branch_union_outputs.py')
    elif choice == 'verify-branch-union':
        run('verify_branch_union.py')
    elif choice == 'sensitivity-union':
        run('sensitivity_union.py')
        run('sensitivity_union_outputs.py')
    elif choice == 'verify-sensitivity-union':
        run('verify_sensitivity_union.py')
    elif choice == 'method-comparisons':
        run('method_comparisons.py')
    elif choice == 'verify-method-comparisons':
        run('verify_method_comparisons.py')
    elif choice == 'verify-submission':
        run('verify_submission.py')
    elif choice == 'verify-manuscript':
        run('manuscript_text.py')
        run('verify_manuscript_outputs.py')
    elif choice == 'simulate-known':
        known()
    elif choice == 'simulate-unknown':
        unknown()
    elif choice == 'simulate-robustness':
        robustness()
    elif choice == 'simulate-nonrotation':
        nonrotation()
    elif choice == 'verify-nonrotation':
        require_records('nonrotation')
        run('nonrotation_mc_outputs.py')
        run('verify_nonrotation_mc.py')
    elif choice == 'simulate-all':
        known()
        unknown()
        robustness()
        deterministic()
        nonrotation()
    elif choice == 'summarize':
        summarize()
    elif choice == 'export':
        export()
    else:
        verify()


if __name__ == '__main__':
    main()
