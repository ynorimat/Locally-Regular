"""Independent identities and saved-fit audit for the unknown-B diagnostic."""
import json
from pathlib import Path
import numpy as np
from scipy.stats import norm
from scipy.linalg import solve_discrete_lyapunov
from unknown_transition import model_derivatives,objective,starting_points
from example_model import A,coarsen
from rotation_family import derivatives,local_information
import pandas as pd
BASE=Path(__file__).resolve().parents[1]


def main():
    rng=np.random.default_rng(20261001)
    checks={};maxgrad=maxderiv=maxpath=maxroot=maxsaved=maxse=0.
    for branch in (0,1,2):
        a=A[branch]+rng.normal(scale=.02,size=(2,2));d=np.diag([1.2,.8]);b,q=coarsen(a,d)
        n=37;z=np.empty((n+1,2));z[0]=rng.multivariate_normal(np.zeros(2),solve_discrete_lyapunov(a,d))
        for i in range(n):z[i+1]=b@z[i]+rng.multivariate_normal(np.zeros(2),q)
        s00=z[:-1].T@z[:-1]/n;s10=z[1:].T@z[:-1]/n;s11=z[1:].T@z[1:]/n
        x=np.r_[a.ravel(),np.log(np.diag(d))]
        f,grad=objective(x,s00,s10,s11)
        residual=z[1:]-z[:-1]@b.T
        direct=.5*(np.linalg.slogdet(q)[1]+np.einsum('ni,ij,nj->',residual,np.linalg.inv(q),residual)/n)
        maxpath=max(maxpath,abs(f-direct))
        fd=np.array([(objective(x+1e-5*e,s00,s10,s11)[0]-objective(x-1e-5*e,s00,s10,s11)[0])/2e-5 for e in np.eye(6)])
        maxgrad=max(maxgrad,float(np.max(abs(fd-grad))))
        _,_,db,dq=model_derivatives(x);db0,dq0=derivatives(a,d,3)
        db0[4:]*=np.diag(d)[:,None,None];dq0[4:]*=np.diag(d)[:,None,None]
        maxderiv=max(maxderiv,float(np.max(abs(db-db0))),float(np.max(abs(dq-dq0))))
        for start in starting_points(s00,s10,s11):
            maxroot=max(maxroot,float(np.max(abs(np.linalg.matrix_power(start[:4].reshape(2,2),3)-s10@np.linalg.inv(s00)))))
    assert maxpath<1e-12 and maxgrad<1e-7 and maxderiv<1e-12 and maxroot<1e-12
    summary=pd.read_csv(BASE/'results/unknown_B_summary.csv')
    total=0;failures=0;hessian_min=1e9
    for path in sorted((BASE/'results/unknown_B_raw').glob('*.npz')):
        with np.load(path) as z:
            fits=z['fits'];n=int(z['n']);truth=int(z['truth']);regime=str(z['regime'])
            total+=len(fits);failures+=int(np.sum(~np.all(fits[:,:,5]==1,axis=1)))
            assert np.all(fits[:,:,5]==1)
            # Every objective and reported score is recomputed; SE independently for 5 paths/cell.
            for i in range(len(fits)):
                for j in range(3):
                    fit=fits[i,j]
                    a=np.array([[fit[6],fit[7]],[fit[0],fit[8]]]);d=np.diag(fit[9:11])
                    x=np.r_[a.ravel(),np.log(np.diag(d))]
                    obj,gradient=objective(x,z['s00'][i],z['s10'][i],z['s11'][i])
                    maxsaved=max(maxsaved,abs(obj-fit[2]),abs(np.linalg.norm(gradient,ord=np.inf)-fit[3]))
                    if i<5:
                        # Independent finite-difference derivatives of (B,Q), in original d coordinates.
                        direct_x=np.r_[a.ravel(),np.diag(d)]; db=[];dq=[]
                        for e in np.eye(6):
                            xp=direct_x+1e-5*e;xm=direct_x-1e-5*e
                            bp,qp=coarsen(xp[:4].reshape(2,2),np.diag(xp[4:]))
                            bm,qm=coarsen(xm[:4].reshape(2,2),np.diag(xm[4:]))
                            db.append((bp-bm)/2e-5);dq.append((qp-qm)/2e-5)
                        gamma=solve_discrete_lyapunov(a,d);qi=np.linalg.inv(coarsen(a,d)[1])
                        info=np.array([[np.trace(qi@db[k]@gamma@db[l].T)+.5*np.trace(qi@dq[k]@qi@dq[l]) for l in range(6)]for k in range(6)])
                        se=np.sqrt(np.linalg.inv(info)[2,2]/n);maxse=max(maxse,abs(se-fit[1]))
                        hess=np.column_stack([(objective(x+1e-5*e,z['s00'][i],z['s10'][i],z['s11'][i])[1]-objective(x-1e-5*e,z['s00'][i],z['s10'][i],z['s11'][i])[1])/2e-5 for e in np.eye(6)])
                        hessian_min=min(hessian_min,float(np.linalg.eigvalsh((hess+hess.T)/2).min()))
            choice=fits[:,:,2].argmin(axis=1)
            for method,index in [('selected',choice),('true_branch_oracle',np.full(len(fits),truth))]:
                fit=fits[np.arange(len(fits)),index];low=fit[:,0]-norm.ppf(.975)*fit[:,1];high=fit[:,0]+norm.ppf(.975)*fit[:,1]
                target=A[truth,1,0];cover=(low<=target)&(target<=high);wrong=(low>0) if target<0 else (high<0)
                row=summary[(summary.regime==regime)&(summary.n==n)&(summary.truth==truth)&(summary.method==method)].iloc[0]
                assert cover.sum()==row.coverage_count and wrong.sum()==row.wrong_count
                assert abs(np.median(high-low)-row.median_width)<1e-12
    assert maxsaved<1e-11 and maxse<1e-8 and hessian_min>0
    checks.update(gradient_max_error=maxgrad,structural_derivative_max_error=maxderiv,
        path_vs_moment_objective_max_error=maxpath,cube_root_max_error=maxroot,
        saved_objective_and_score_max_error=maxsaved,independent_SE_max_error=maxse,
        observed_hessian_min_on_270_audited_fits=hessian_min,
        paths_verified=total,candidate_fits_verified=3*total,failures=failures,
        summary_rows_verified=len(summary),status='all checks passed')
    (BASE/'results/verification_unknown_B.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))


if __name__=='__main__':main()
