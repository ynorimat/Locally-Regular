"""Independent scalar-matrix audit of all extended union events and summaries.

Likelihood ratios use scalar 2x2 inverses, and union lengths use inclusion-
exclusion. No simulator, optimizer, analysis exporter or Gaussian batch helper
is imported. A final API check verifies the reusable k=3/k=5 procedure.
"""
from pathlib import Path
from statistics import NormalDist
from itertools import combinations
import csv
import hashlib
import json
import math
import numpy as np

BASE=Path(__file__).resolve().parents[1]
OUT=BASE/'results/sensitivity_union'


def read(path):
    with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))


def det(a):return a[0,0]*a[1,1]-a[0,1]*a[1,0]


def inv(a):return np.array([[a[1,1],-a[0,1]],[-a[1,0],a[0,0]]])/det(a)


def main():
    report=json.loads((OUT/'verification.json').read_text())
    protocol_path=BASE/'sensitivity_union_protocol.json'
    protocol=json.loads(protocol_path.read_text())
    assert hashlib.sha256(protocol_path.read_bytes()).hexdigest()==report['protocol_sha256']
    critical=NormalDist().inv_cdf(1-protocol['alpha_screen']/2)**2
    z=NormalDist().inv_cdf(1-protocol['alpha_interval']/2)
    records=read(OUT/'records.csv')
    lookup={(r['source_file'],int(r['record']),r['method']):r for r in records}
    assert len(records)==len(lookup)==24000
    maximum=0.;checked=0;api_cases=[]
    for relative,digest in report['input_sha256'].items():
        path=BASE/relative
        assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
        with np.load(path,allow_pickle=False) as data:
            n,k,truth=int(data['n']),int(data['k']),int(data['truth'])
            target=float(data['r'])*math.sin(float(data['theta'])+2*math.pi*truth/k)
            for i,fit in enumerate(data['fits']):
                xx,yx,yy=[data[v][i] for v in ['s00','s10','s11']]
                bh=yx@inv(xx);qh=yy-bh@yx.T;qh=(qh+qh.T)/2
                ratios=[];bounds=[]
                for j in range(k):
                    a=np.array([[fit[j,6],fit[j,7]],[fit[j,0],fit[j,8]]])
                    d=np.diag(fit[j,9:11]);power=np.eye(2);q=np.zeros((2,2))
                    for _ in range(k):q+=power@d@power.T;power=power@a
                    b=power;res=yy-b@yx.T-yx@b.T+b@xx@b.T
                    ratio=n*(math.log(det(q)/det(qh))+np.trace(inv(q)@res)-2)
                    ratios.append(ratio);bounds.append((fit[j,0]-z*fit[j,1],fit[j,0]+z*fit[j,1]))
                for method in ['screened_union','all_branch_union']:
                    row=lookup[path.name,i,method]
                    retained=[j for j in range(k) if method=='all_branch_union' or ratios[j]<=critical]
                    for j in range(k):
                        maximum=max(maximum,abs(float(row[f'lr{j}'])-ratios[j]))
                        assert int(row[f'keep{j}'])==int(j in retained)
                        assert abs(float(row[f'lower{j}'])-bounds[j][0])<1e-9
                        assert abs(float(row[f'upper{j}'])-bounds[j][1])<1e-9
                    intervals=[bounds[j] for j in retained]
                    covered=any(a<=target<=b for a,b in intervals)
                    if intervals:
                        low=min(a for a,b in intervals);high=max(b for a,b in intervals)
                        both=low<0<high;declared=low>0 or high<0
                        wrong=low>0 if target<0 else high<0;diameter=high-low
                    else:both=declared=wrong=False;diameter=0.
                    length=0.
                    for size in range(1,len(intervals)+1):
                        for group in combinations(intervals,size):
                            length+=(-1)**(size+1)*max(0.,min(v[1] for v in group)-max(v[0] for v in group))
                    for key,val in dict(covered=covered,both=both,declared=declared,wrong=wrong,empty=not intervals,true_retained=truth in retained).items():
                        assert int(row[key])==int(val),(path.name,i,method,key)
                    assert abs(float(row['diameter'])-diameter)<1e-9
                    assert abs(float(row['total_length'])-length)<1e-9
                    assert int(row['branches'])==len(retained) and int(row['fallback'])==0
                    checked+=1
                if i in (0,249,499):
                    api_cases.append((xx.copy(),yx.copy(),yy.copy(),fit.copy(),n,k,lookup[path.name,i,'screened_union']))
    summaries=read(OUT/'summary.csv')
    assert len(summaries)==48
    for s in summaries:
        rr=[r for r in records if all(r[key]==s[key] for key in ['setting','regime','n','truth','method'])]
        assert len(rr)==int(s['reps'])==500
        for key in ['covered','both','declared','wrong','empty','fallback','true_retained']:
            count=sum(int(r[key]) for r in rr)
            assert count==int(s[key+'_count']) and abs(count/500-float(s[key+'_rate']))<1e-12
        for key in ['diameter','total_length']:
            assert abs(np.median([float(r[key]) for r in rr])-float(s['median_'+key]))<1e-9
        mean=np.mean([int(r['branches']) for r in rr]);assert abs(mean-float(s['mean_branches']))<1e-12
        for j in range(6):assert sum(int(r['branches'])==j for r in rr)==int(s[f'branches_{j}_count'])
        gain=np.array([int(r['covered'])-int(r['selected_covered']) for r in rr])
        assert abs(gain.mean()-float(s['paired_coverage_gain']))<1e-12
        assert abs(gain.std(ddof=1)/np.sqrt(500)-float(s['paired_gain_mcse']))<1e-12
        p=float(s['covered_rate']);zz=NormalDist().inv_cdf(.975)
        center=(p+zz*zz/1000)/(1+zz*zz/500)
        half=zz*np.sqrt(p*(1-p)/500+zz*zz/(4*500**2))/(1+zz*zz/500)
        assert abs(center-half-float(s['coverage_lo']))<1e-12
        assert abs(center+half-float(s['coverage_hi']))<1e-12
    from screened_union import confidence_union
    for xx,yx,yy,fit,n,k,row in api_cases:
        ans=confidence_union(xx,yx,yy,fit,n,k=k)
        assert not ans['fallback']
        assert ans['retained']==[j for j in range(k) if int(row[f'keep{j}'])]
        assert max(abs(ans['statistics'][j]-float(row[f'lr{j}'])) for j in range(k))<1e-7
    for fits in [fit[:-1],fit.copy()]:
        if len(fits)==k:fits[0,5]=0
        assert confidence_union(xx,yx,yy,fits,n,k=k)['fallback']
    assert confidence_union(np.zeros((2,2)),yx,yy,fit,n,k=k)['fallback']
    # Optional TeX display checks; complete numerical checks above are unconditional.
    table_path=OUT/'coverage_table.tex'
    if table_path.is_file():
        table=table_path.read_text()
        for s in summaries:
            if s['method']=='screened_union':
                text=f"{100*float(s['covered_rate']):.1f} [{100*float(s['coverage_lo']):.1f}, {100*float(s['coverage_hi']):.1f}]"
                assert text in table
    ms=BASE/'exports/sensitivity_union'
    if ms.is_dir():
        for path in OUT.glob('*.tex'):
            assert path.read_bytes()==(ms/path.name).read_bytes()
    assert maximum<1e-7 and checked==24000
    output=dict(status='passed',record_method_pairs=checked,summary_rows=len(summaries),maximum_lr_difference=maximum,
                reusable_procedure_cases=len(api_cases),conservative_failure_cases=3,
                scope='Independent scalar likelihood and inclusion-exclusion audit; every original sensitivity cell and both methods')
    output['optional_tex_table_present']=table_path.is_file()
    (OUT/'independent_verification.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))


if __name__=='__main__':main()
