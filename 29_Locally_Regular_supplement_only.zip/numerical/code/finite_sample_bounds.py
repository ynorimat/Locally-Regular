"""Independent matrix-based audit and table export for finite-sample bounds.

The audit needs NumPy; table export uses only the standard library. It does
not import the rotation-family/profile implementation used for the CSV.
"""
from pathlib import Path
import csv
import json
import math

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'results' / 'branch_diagnostics'


def load_rows(folder=OUT):
    with (folder / 'setting_distances.csv').open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def table_text(rows):
    angles = {'Base': r'$\pi/6$', 'Radius': r'$\pi/6$',
              'Angle': r'$\pi/5$', 'Sampling': r'$\pi/10$'}
    selected = [r for r in rows if int(r['n']) == 32000 and r['regime'] == 'fixed_e02']
    assert len(selected) == 4
    lines = [r'\begin{table}[htbp]', r'\centering\small',
        r'\caption{Fixed-model comparison at $n=32000$ and $\varepsilon=.2$. The source branch is $m=2$ for $k=3$ and $m=3$ for $k=5$; the competitor is $\ell=0$ with variance profile \eqref{eq:dstar}. The last column is $[.9-\sqrt{K_n^\star/2}]_+$, a lower bound on the negative-source probability of $\diam(C_n)\ge\Delta_1$ if coverage is at least 95\% under both laws.}',
        r'\label{tab:setting_distances}', r'\begin{tabular}{lrrcrrr}', r'\toprule',
        r'Setting & $k$ & $r$ & $\theta$ & Effect gap $\Delta_1$ & Path KL & Bound \\', r'\midrule']
    for r in selected:
        lines.append(f"{r['setting']} & {int(r['k'])} & {float(r['r']):.1f} & "
            + angles[r['setting']] + ' & '
            + ' & '.join(f'{float(r[key]):.4f}' for key in
                ['effect_gap', 'exact_path_KL', 'diameter_lower_probability']) + r' \\')
    lines += [r'\bottomrule', r'\end{tabular}', r'\end{table}']
    return '\n'.join(lines) + '\n'


def export_table(folder=OUT):
    (folder / 'setting_distances_table.tex').write_text(
        table_text(load_rows(folder)), encoding='utf-8', newline='\n')


def main():
    import numpy as np

    def rotation(angle):
        return np.array([[math.cos(angle), -math.sin(angle)],
                         [math.sin(angle), math.cos(angle)]])

    def covariance(a, d, k):
        q = np.zeros((2, 2)); power = np.eye(2)
        for _ in range(k):
            q += power @ d @ power.T
            power = a @ power
        gamma = np.linalg.solve(np.eye(4) - np.kron(a, a), d.ravel()).reshape(2, 2)
        assert np.linalg.eigvalsh(gamma).min() > 0
        assert np.linalg.eigvalsh(q).min() > 0
        assert np.max(abs(gamma - power @ gamma @ power.T - q)) < 1e-12
        return power, q, gamma

    def gaussian_kl(source, competitor):
        # Eigenvalues of the whitened covariance DIFFERENCE keep tiny KL stable.
        chol = np.linalg.cholesky(competitor)
        whitened = np.linalg.solve(chol, source - competitor)
        whitened = np.linalg.solve(chol, whitened.T).T
        delta = np.linalg.eigvalsh((whitened + whitened.T) / 2)
        return .5 * sum(float(x) - math.log1p(float(x)) for x in delta)

    rows = load_rows()
    assert len(rows) == 16
    maxima = {'path_kl': 0., 'effect_gap': 0., 'diameter_bound': 0., 'common_transition': 0.}
    for row in rows:
        k, n, m, ell = [int(row[key]) for key in ['k', 'n', 'source', 'competitor']]
        r, theta, eps, beta = [float(row[key]) for key in ['r', 'theta', 'epsilon', 'beta']]
        roots = [r * rotation(theta + 2*math.pi*j/k) for j in range(k)]
        # Independent profile: match covariance in the competitor's eigenbasis.
        _, direction, _ = covariance(roots[ell], np.eye(2), k)
        assert np.max(abs(direction - np.eye(2)*np.trace(direction)/2)) < 1e-12
        def perturbation(a):
            p = np.eye(2); q = np.zeros((2, 2))
            for _ in range(k):
                q += p @ np.diag([1., -1.]) @ p.T
                p = a @ p
            return q
        tm, tl = perturbation(roots[m]), perturbation(roots[ell])
        independent_beta = np.sum(tm*tl)/np.sum(tl*tl)
        assert abs(independent_beta-beta) < 1e-12
        # All roots have distinct covariance directions in these settings.
        directions = [perturbation(a) for a in roots]
        for i in range(k):
            for j in range(i):
                assert abs(directions[i][0,0]*directions[j][0,1]
                           - directions[j][0,0]*directions[i][0,1]) > 1e-6
        bm, qm, gm = covariance(roots[m], np.diag([1+eps, 1-eps]), k)
        bl, ql, gl = covariance(roots[ell], np.diag([1+beta*eps, 1-beta*eps]), k)
        transition_error = float(abs(bm-bl).max())
        assert transition_error < 1e-12
        initial = gaussian_kl(gm, gl)
        transition = gaussian_kl(qm, ql)
        total = initial + n * transition
        gap = abs(roots[m][1,0] - roots[ell][1,0])
        bound = max(0., .9-math.sqrt(total/2))
        maxima['common_transition'] = max(maxima['common_transition'], transition_error)
        for key, value, column in [('path_kl', total, 'exact_path_KL'),
                                   ('effect_gap', gap, 'effect_gap'),
                                   ('diameter_bound', bound, 'diameter_lower_probability')]:
            maxima[key] = max(maxima[key], abs(float(value)-float(row[column])))
        assert abs(initial-float(row['initial_KL'])) < 1e-12
        assert abs(transition-float(row['per_transition_KL'])) < 1e-12
        assert abs(total-float(row['exact_path_KL'])) < 1e-9
        assert abs(bound-float(row['diameter_lower_probability'])) < 5e-8
    expected = table_text(rows)
    # TeX display sources are optional in the standalone numerical ZIP.
    # The complete numerical rows and direct Gaussian KL checks above always run.
    if (OUT/'setting_distances_table.tex').is_file():
        assert (OUT/'setting_distances_table.tex').read_text(encoding='utf-8') == expected
    manuscript = BASE/'exports/branch_diagnostics/setting_distances_table.tex'
    if manuscript.exists():
        assert manuscript.read_text(encoding='utf-8') == expected
    key_row = next(r for r in rows if r['setting']=='Sampling' and int(r['n'])==32000 and r['regime']=='fixed_e02')
    assert float(key_row['effect_gap']) >= .7826
    assert float(key_row['diameter_lower_probability']) >= .4272
    report = {'status': 'passed', 'rows_checked': len(rows), 'table_rows_checked': 4,
        'max_absolute_errors': maxima, 'fixed_model_example': key_row,
        'scope': 'Independent covariance recurrences, Lyapunov solves, Gaussian KL, profiled direction, root separation, and table audit; no simulation or optimization.'}
    path = BASE/'results/finite_bounds_audit/verification.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
