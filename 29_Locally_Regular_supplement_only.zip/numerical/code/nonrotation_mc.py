"""Fixed-protocol nonrotation diagnostic; reuses the unchanged estimator.

Run `python reproduce.py simulate-nonrotation`. Protocol is a distributed input,
never rewritten by this script. Every attempted path remains in denominators.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
from scipy.linalg import solve_discrete_lyapunov
from scipy.stats import norm
from nonrotation_example import construction
from rotation_family import coarsen
from unknown_transition import fit_record, wilson

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'results/nonrotation_mc'
RAW = OUT / 'raw'


def constants():
    roots, _, ds, _, _, _ = construction()
    return np.array(roots, dtype=float), np.array(ds, dtype=float)


def simulate(a, d, n, reps, seed):
    rng = np.random.default_rng(seed)
    b, q = coarsen(a, d, 3)
    g = solve_discrete_lyapunov(a, d)
    z = rng.standard_normal((reps, 2)) @ np.linalg.cholesky(g).T
    chol = np.linalg.cholesky(q)
    s00 = np.zeros((reps, 2, 2)); s10 = s00.copy(); s11 = s00.copy()
    for _ in range(n):
        nxt = z @ b.T + rng.standard_normal((reps, 2)) @ chol.T
        s00 += z[:, :, None] * z[:, None, :]
        s10 += nxt[:, :, None] * z[:, None, :]
        s11 += nxt[:, :, None] * nxt[:, None, :]
        z = nxt
    return s00/n, s10/n, s11/n


def events(z, roots):
    fits = z['fits']; reps = len(fits); truth = int(z['truth']); n = int(z['n'])
    valid = fits[:, :, 5] == 1
    complete = valid.all(axis=1)
    chosen = np.argmin(np.where(np.isfinite(fits[:, :, 2]), fits[:, :, 2], np.inf), axis=1)
    ii = np.arange(reps)
    # Audit initialization labels against nearest exact roots, without using
    # these roots in estimation or replacing the pre-specified oracle.
    matrices = fits[:, :, [6, 7, 0, 8]].reshape(reps, 3, 2, 2)
    dist = np.linalg.norm(matrices[:, :, None] - roots[None, None], axis=(-2, -1))
    nearest = np.argmin(np.where(np.isfinite(dist), dist, np.inf), axis=2)
    b = np.linalg.solve(z['s00'], z['s10'].transpose(0, 2, 1)).transpose(0, 2, 1)
    q = z['s11'] - b @ z['s10'].transpose(0, 2, 1)
    var = q[:, 1, 1] * np.linalg.inv(z['s00'])[:, 0, 0] / n
    grid_valid = np.isfinite(var) & (var > 0)
    specs = [('selected', fits[ii, chosen, 0], fits[ii, chosen, 1], complete, roots[truth, 1, 0]),
             ('true_branch_oracle', fits[:, truth, 0], fits[:, truth, 1], valid[:, truth], roots[truth, 1, 0]),
             ('on_grid', b[:, 1, 0], np.sqrt(np.maximum(var, 0)), grid_valid, np.linalg.matrix_power(roots[truth], 3)[1, 0])]
    result = {}
    for method, estimate, se, ok, target in specs:
        half = norm.ppf(.975) * se
        low, high = estimate-half, estimate+half
        result[method] = dict(valid=ok, coverage=ok & (low <= target) & (target <= high),
            wrong=ok & ((low > 0) if target < 0 else (high < 0)),
            width=2*half, target=target)
    return result, chosen, nearest, complete


def summarize():
    roots, _ = constants()
    rows = []; details = []
    for path in sorted(RAW.glob('*.npz')):
        with np.load(path) as z:
            result, chosen, nearest, complete = events(z, roots)
            reps = len(chosen); truth = int(z['truth']); fits = z['fits']
            common = dict(regime=str(z['regime']), n=int(z['n']), epsilon=float(z['epsilon']),
                          truth=truth, reps=reps, all_fits_accepted=int(complete.sum()),
                          max_score=float(np.nanmax(fits[:, :, 3])),
                          start_label_migrations=int(((nearest != np.arange(3)) & (fits[:, :, 5] == 1)).sum()),
                          oracle_migrations=int(((nearest[:, truth] != truth) & (fits[:, truth, 5] == 1)).sum()))
            for j in range(3):
                common[f'selected_start_{j}_count'] = int(((chosen == j) & complete).sum())
            for method, ev in result.items():
                row = dict(common, method=method, target=float(ev['target']),
                           valid=int(ev['valid'].sum()), failures=int((~ev['valid']).sum()),
                           median_width=float(np.median(ev['width'][ev['valid']])) if ev['valid'].any() else float('nan'))
                for name in ['coverage', 'wrong']:
                    count = int(ev[name].sum()); lo, hi = wilson(count, reps)
                    row.update({name+'_count':count, name+'_rate':count/reps, name+'_lo':lo, name+'_hi':hi})
                rows.append(row)
            for i in range(reps):
                row = dict(regime=common['regime'], truth=truth, path=i, selected_start=int(chosen[i]),
                           complete=int(complete[i]))
                for j in range(3): row[f'nearest_root_start_{j}'] = int(nearest[i, j])
                for method, ev in result.items():
                    for key in ['valid', 'coverage', 'wrong']: row[f'{method}_{key}'] = int(ev[key][i])
                details.append(row)
    frame = pd.DataFrame(rows)
    frame.to_csv(OUT/'summary.csv', index=False)
    pd.DataFrame(details).to_csv(OUT/'path_events.csv', index=False)
    print(frame[['regime','truth','method','valid','coverage_count','wrong_count','start_label_migrations']].to_string(index=False), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--summarize', action='store_true')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if args.summarize:
        summarize(); return
    protocol_bytes = (BASE/'nonrotation_mc_protocol.json').read_bytes()
    p = json.loads(protocol_bytes)
    roots, ds = constants(); n = p['n']; reps = p['reps_per_cell']
    RAW.mkdir(exist_ok=True)
    for ri, regime in enumerate(p['regimes']):
        for truth in p['truth_branches']:
            epsilon = p['epsilon'][ri]
            d = ds[truth] + epsilon*(.7 if truth == 0 else 1.)*np.diag([1., -1.])
            seed = np.random.SeedSequence([p['base_seed'], n, ri, truth])
            s00, s10, s11 = simulate(roots[truth], d, n, reps, seed)
            fits = []; exceptions = []
            for i in range(reps):
                try: fits.append(fit_record((s00[i], s10[i], s11[i], n)))
                except (ValueError, FloatingPointError, np.linalg.LinAlgError) as exc:
                    fits.append(np.full((3, 11), np.nan))
                    exceptions.append(dict(path=i, error=type(exc).__name__, message=str(exc)))
            fits = np.array(fits)
            np.savez_compressed(RAW/f'{regime}_truth{truth}.npz', s00=s00, s10=s10, s11=s11,
                fits=fits, n=n, truth=truth, regime=regime, epsilon=epsilon, base_seed=p['base_seed'],
                regime_index=ri, a=roots[truth], d=d,
                protocol_sha256=hashlib.sha256(protocol_bytes).hexdigest())
            (OUT/f'{regime}_truth{truth}_exceptions.json').write_text(json.dumps(exceptions, indent=2)+'\n')
            print(f'{regime} truth={truth}: {np.all(fits[:,:,5] == 1, axis=1).sum()}/{reps} complete', flush=True)
    summarize()


if __name__ == '__main__': main()
